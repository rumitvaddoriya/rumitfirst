package com.example.api_geeve_account_getx

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
