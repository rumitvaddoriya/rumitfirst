class EndPoint{

  ///----------------------------------------------login Base url ----------------------------------------------
  static const baseUrl = 'http://34.132.113.32:4073/';

  ///---------------------------------------------- End points ----------------------------------------------
  static const login = baseUrl + "login";
  static const home = baseUrl + "treatmentTypeList";


}