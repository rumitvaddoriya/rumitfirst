import 'dart:ui';

import 'package:flutter/material.dart';

class ColorRes{

  static const white  = Colors.white;
  static const backgroundColor = Color(0xFFffffff);
  static const textfieldcolor  = Color(0xfff6f6f6);
  static const logincolor = Color(0xfffa7914);
  static const rememberme = Color(0xff7d7f86);
  static const black  = Colors.black;
  static const grey  = Colors.grey;
  static const black26  = Colors.black26;
  static const white10  = Colors.white10;


}