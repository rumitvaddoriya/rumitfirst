class Strings{

  ///---------------------------------------- login screen ----------------------------------------
  static const email = 'Email';
  static const password = 'Password';
  static const rememberme = "Remember me";
  static const validationerror = "Error";
  static const login = "Login";
  static const forgetpassword =  "Forget Password?";
  static const dontaccount =  "Don't have an account?";
  static const signup = "Sign Up";
  static const AppBarTitle = "Non profit";
  static const Suggestions = "Suggestions";

  static const validationemail = 'Enter Email';
  static const validemail = 'Enter Valid email';
  static const validationpassword = 'Please Enter Password';
  static const validpasswordchar = 'At Least 6 char required';

}