import 'package:flutter/material.dart';

class AssetRes{

  static const images = 'images/';

  ///--------------------------------------------- icon ---------------------------------------------
  static const email_outlined = Icons.email_outlined;
  static const key = Icons.vpn_key;
  static const lock = Icons.lock;
  static const error = Icons.error;

  ///--------------------------------------------- images ---------------------------------------------
  static const logo = images + 'logo.png';
  static const shedo = images + 'shedo.png';
  static const menuicon = images + 'icn menu.png';

}