import 'package:api_geeve_account_getx/common/tost.dart';
import 'package:api_geeve_account_getx/model/home_model.dart';
import 'package:api_geeve_account_getx/service/http_service.dart';
import 'package:api_geeve_account_getx/utils/EndPoints.dart';
import 'package:http/http.dart' as http;

class HomeApi{

  static Future<HomeData?> getAllHomeData() async {

      try{
        String url = EndPoint.home;

        http.Response? response = await HttpService.getApi(url: url);

        print(response!.body);

        if(response != null && response.statusCode == 200){
            return homeDataFromJson(response.body);
        }
        return null;
      }catch(e){
        showToast(e.toString());
        return null;
      }
  }

}