import 'package:api_geeve_account_getx/common/loaders.dart';
import 'package:api_geeve_account_getx/screens/home/home_controller.dart';
import 'package:api_geeve_account_getx/screens/home/widgets/home_center.dart';
import 'package:api_geeve_account_getx/screens/home/widgets/home_end.dart';
import 'package:api_geeve_account_getx/screens/home/widgets/home_top.dart';
import 'package:api_geeve_account_getx/utils/assets_res.dart';
import 'package:api_geeve_account_getx/utils/colors_res.dart';
import 'package:api_geeve_account_getx/utils/strings_res.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class homeScreen extends StatelessWidget {
  const homeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final HomeController controller = Get.put(HomeController());
    return Scaffold(
          appBar:PreferredSize(
            preferredSize: Size.fromHeight(80),
            child:AppBar(
              automaticallyImplyLeading: false,
              elevation: 0,
              leading: GestureDetector(
                onTap: () {},
                child: Image.asset(AssetRes.menuicon),
              ),
              backgroundColor:ColorRes.logincolor,
              shape: const RoundedRectangleBorder(
                borderRadius: BorderRadius.only(
                    bottomRight: Radius.circular(25),
                    topLeft: Radius.circular(25),
                    topRight: Radius.circular(25)),
              ),
              centerTitle: true,
              title: Padding(
                padding: EdgeInsets.only(top:5),
                child: Container(
                  height: 50,
                  width: 250,
                  decoration: BoxDecoration(
                      color:ColorRes.white,
                      borderRadius: BorderRadius.all(Radius.circular(15))
                  ),
                  child: TextField(
                    // onChanged: (value) =>_runFilter(value),
                    controller: controller.serchController,
                    decoration: InputDecoration(
                      prefixIcon:Icon(Icons.search_rounded),
                      border: InputBorder.none,
                      hintText:Strings.AppBarTitle,
                    ),
                  ),
                ),
              ),
            ),
          ),
          body: SingleChildScrollView(
            child: Column(
              children: [
                homeTop(),
                homeCenter(),
                homeEnd(),
              ],
            ),
          ),
        );
  }
}
