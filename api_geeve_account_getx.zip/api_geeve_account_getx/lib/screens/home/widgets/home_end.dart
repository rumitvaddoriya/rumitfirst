import 'package:api_geeve_account_getx/utils/assets_res.dart';
import 'package:flutter/cupertino.dart';

class homeEnd extends StatelessWidget {
  const homeEnd({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          height:50,
          width: double.infinity,
          decoration: BoxDecoration(image: DecorationImage(image: AssetImage(AssetRes.shedo),fit: BoxFit.fill)),
        ),
      ],
    );
  }
}
