import 'package:api_geeve_account_getx/common/styles.dart';
import 'package:api_geeve_account_getx/utils/colors_res.dart';
import 'package:api_geeve_account_getx/utils/strings_res.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class homeTop extends StatelessWidget {
  const homeTop({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(height: 10,),
        Center(
          child: GestureDetector(
            onTap: () {},
            child: Container(
              height: 50,
              width: 320,
              margin: EdgeInsets.only(left: 10,right: 10),
              decoration: BoxDecoration(
                  border: Border(
                    bottom: BorderSide(
                        width: 0.5, color: ColorRes.black26),
                  )),
              child:Padding(
                padding:  EdgeInsets.only(left: 3,top: 10),
                child: Text(Strings.Suggestions,style:hometitle),
              ),
            ),
          ),
        ),
        SizedBox(height: 5,),
      ],
    );
  }
}
