import 'package:api_geeve_account_getx/common/loaders.dart';
import 'package:api_geeve_account_getx/screens/home/home_controller.dart';
import 'package:api_geeve_account_getx/utils/assets_res.dart';
import 'package:api_geeve_account_getx/utils/colors_res.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:get/get.dart';

class homeCenter extends StatelessWidget {
  const homeCenter({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final HomeController controller = Get.find();
    return SizedBox(
      height: 500,
      width: Get.width,
      child: GetBuilder<HomeController>(
        id: 'list',
        builder: (controller) {
          if(controller.loader.isTrue){
            return SmallLoader();
          }else{
            return ListView.builder(
              itemCount: controller.homeData?.body?.length ?? 0,
              itemBuilder: (context, index) {
                return Container(
                  height: 70,
                  margin: EdgeInsets.only(left: 10, right: 10),
                  decoration: BoxDecoration(
                      border: Border(
                        top: BorderSide(width: 0.5, color: ColorRes.white10),
                        bottom: BorderSide(width: 0.5, color: ColorRes.black26),
                      )),
                  child: ListTile(
                    leading: CircleAvatar(
                      backgroundColor: Colors.white,
                      child:  CachedNetworkImage(
                        height: 103,
                        width: Get.width > 400
                            ? Get.width * 0.25060
                            : Get.width * 0.2620,
                        imageUrl: 'http://34.132.113.32:4073${controller.homeData?.body?[index].image}',
                        fit: BoxFit.fill,
                        placeholder: (context, url) => CircularProgressIndicator(),
                      ),
                    ),
                    title: Text(controller.homeData!.body![index].name ?? ''),
                    subtitle: Text(
                        controller.homeData?.body?[index].id.toString() ?? '0'),
                  ),
                );
              },
            );
          }
        },
      ),
    );
  }
}
