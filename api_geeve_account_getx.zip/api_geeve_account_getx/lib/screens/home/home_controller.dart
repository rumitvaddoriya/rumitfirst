import 'package:api_geeve_account_getx/common/tost.dart';
import 'package:api_geeve_account_getx/model/home_model.dart';
import 'package:api_geeve_account_getx/screens/home/api/home_api.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class HomeController extends GetxController{

  TextEditingController serchController = TextEditingController();
  HomeData? homeData = HomeData();
  RxBool loader = false.obs;

  Future<void> onInit() async {
   await getHomeData();
  }

  Future<void> getHomeData() async {
    loader.value = true;
    homeData = await HomeApi.getAllHomeData();
    loader.value = false;
    update(['list']);
  }

}