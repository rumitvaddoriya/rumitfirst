import 'package:api_geeve_account_getx/common/styles.dart';
import 'package:api_geeve_account_getx/screens/login/loginscreen_controller.dart';
import 'package:api_geeve_account_getx/utils/assets_res.dart';
import 'package:api_geeve_account_getx/utils/colors_res.dart';
import 'package:api_geeve_account_getx/utils/strings_res.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class loginCenter extends StatelessWidget {
  const loginCenter({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final LoginControoler controller = Get.find();
    return Form(
      key: controller.formkey,
      child: Column(
        children: [
          Padding(
            padding:  EdgeInsets.only(left: 45,right: 45),
            child: TextFormField(
              controller:controller.namecontroller,
              style:textfeild,
              decoration: InputDecoration(
                border: InputBorder.none,
                hintText:Strings.email,
                filled: true,
                prefixIcon:Icon(AssetRes.email_outlined,color:ColorRes.grey),
                fillColor: ColorRes.textfieldcolor,
                enabledBorder: OutlineInputBorder(
                  borderSide:BorderSide(color:ColorRes.textfieldcolor,),
                  borderRadius: BorderRadius.circular(50),
                ),
              ),
            ),
          ),
          SizedBox(height:15,),
          Padding(
            padding:  EdgeInsets.only(left: 45,right: 45),
            child: TextFormField(
              controller:controller.passwordcontroller,
              style:textfeild,
              decoration: InputDecoration(
                border: InputBorder.none,
                hintText:Strings.password,
                filled: true,
                prefixIcon: Icon(AssetRes.key,color:ColorRes.grey),
                fillColor:ColorRes.textfieldcolor,
                enabledBorder: OutlineInputBorder(
                  borderSide:
                  BorderSide(color:ColorRes.textfieldcolor,),
                  borderRadius: BorderRadius.circular(50),
                ),
              ),
              validator: (value){
                if(value == null || value.isEmpty)
                {
                  return Strings.validationpassword;
                }else if(value.length < 6)
                {
                  return Strings.validpasswordchar;
                }
                return null;
              },
            ),
          ),
          SizedBox(height: 20,),
          Row(
            children: [
              Container(
                margin: EdgeInsets.only(left: 50),
                height: 20,
                width: 20,
                decoration: BoxDecoration(color:ColorRes.textfieldcolor,borderRadius: BorderRadius.all(Radius.circular(5))),
              ),
              SizedBox(width: 15,),
              Text(Strings.rememberme,style:rememberme,),
            ],
          ),
          SizedBox(height: 25,),
          GestureDetector(
            onTap: () {
              if(controller.formkey.currentState!.validate()){
                  controller.getlogindata();
              }else{
                print(Strings.validationerror);
              }
            },
            child: Container(
              height: 50,
              width: 270,
              child: Center(child: Text(Strings.login,style:Login),),
              decoration: BoxDecoration(color:ColorRes.logincolor,borderRadius: BorderRadius.all(Radius.circular(50),),
                  boxShadow: [BoxShadow(color:ColorRes.black.withOpacity(0.40),blurRadius:5,offset: const Offset(1, 0)),]),
            ),
          ),
          SizedBox(height: 20,),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Icon(AssetRes.lock,color:ColorRes.logincolor,size: 15,),
              SizedBox(width: 5,),
              Padding(
                padding:EdgeInsets.only(right:40),
                child: Text(Strings.forgetpassword,style:forget,),
              )
            ],
          ),
          SizedBox(height: 50  ,),
          InkWell(
              onTap: () {},
              child: Text(Strings.dontaccount,style:donthaveaccount,),
          ),
          SizedBox(height: 10,),
          InkWell(
            onTap: () {

            },
            child:Text(Strings.signup,style:signup),
          ),
        ],
      ),
    );
  }
}
