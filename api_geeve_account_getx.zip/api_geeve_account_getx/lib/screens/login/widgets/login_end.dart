import 'package:api_geeve_account_getx/utils/assets_res.dart';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';

class loginEnd extends StatelessWidget {
  const loginEnd({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          height:Get.height * 0.15,
          width: double.infinity,
          decoration: BoxDecoration(image: DecorationImage(image: AssetImage(AssetRes.shedo),fit: BoxFit.fill)),
        ),
      ],
    );
  }
}
