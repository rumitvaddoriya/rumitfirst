import 'package:api_geeve_account_getx/model/login_model.dart';
import 'package:api_geeve_account_getx/service/http_service.dart';
import 'package:api_geeve_account_getx/utils/EndPoints.dart';
import 'package:http/http.dart' as http;


class LoginApi{

  static Future<LoginData?> getAllLoginData(username,password) async {
    try {
      String url = EndPoint.login;

      http.Response? response = await HttpService.postApi(url: url,body:
      ({'username':username, 'password':password,'device_type':'IPHONE','device_token':'ABCDEFGg123'})
      );

      print(url);
      print(username);
      print(password);
      print(response!.body);

      if (response != null && response.statusCode == 200) {
        return loginDataFromJson(response.body);
      }
      return null;
    } catch (e) {
      return null;
    }
  }
}