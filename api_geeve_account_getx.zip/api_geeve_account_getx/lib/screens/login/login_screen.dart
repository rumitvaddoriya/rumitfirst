import 'package:api_geeve_account_getx/screens/login/loginscreen_controller.dart';
import 'package:api_geeve_account_getx/screens/login/widgets/login_center.dart';
import 'package:api_geeve_account_getx/screens/login/widgets/login_end.dart';
import 'package:api_geeve_account_getx/screens/login/widgets/login_top.dart';
import 'package:api_geeve_account_getx/utils/colors_res.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class loginScreen extends StatelessWidget {
  const loginScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final LoginControoler controoler = Get.put(LoginControoler());
    return Scaffold(
      backgroundColor: ColorRes.backgroundColor,
      body: SingleChildScrollView(
        child: Column(
          children: [
            loginTop(),
            loginCenter(),
            loginEnd(),
          ],
        ),
      ),
    );
  }
}
