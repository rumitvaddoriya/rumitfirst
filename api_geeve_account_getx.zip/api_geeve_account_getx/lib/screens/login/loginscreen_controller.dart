import 'package:api_geeve_account_getx/common/tost.dart';
import 'package:api_geeve_account_getx/model/login_model.dart';
import 'package:api_geeve_account_getx/screens/home/home_screen.dart';
import 'package:api_geeve_account_getx/screens/login/api/login_api.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class LoginControoler extends GetxController{

  final TextEditingController namecontroller = TextEditingController();
  final TextEditingController passwordcontroller = TextEditingController();
  GlobalKey<FormState> formkey = GlobalKey<FormState>();
  LoginData loginData = LoginData();

  Future<void> getlogindata() async {
    LoginData? model = await LoginApi.getAllLoginData(namecontroller.text,passwordcontroller.text);
    if(namecontroller.text.isNotEmpty && passwordcontroller.text.isNotEmpty){
        if(model!.success==true){
            Get.to(homeScreen());
        }else{
            showToast('please enter current value');
        }
    }
   else{
      Text("not allowed");
    }
  }

}
