import 'package:api_geeve_account_getx/common/tost.dart';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

class HttpService{

  static Future<http.Response?> getApi({
    required String url,
  }) async {
    try {
      if (kDebugMode) {
        print("Url => $url");
      }
      return http.get(
        Uri.parse(url),
      );
    } catch (e) {
      showToast(e.toString());
      return null;
    }
  }

  static Future<http.Response?> postApi({
    required String url,
    Map<String, dynamic>? body,
    Map<String, String>? header,
  }) async {
    try {
      if (kDebugMode) {
        print("Url => $url");
        print("Header => $header");
        print("Body => $body");
      }
      return http.post(
        Uri.parse(url),
        headers: header,
        body: body,
      );
    } catch (e) {
      showToast(e.toString());
      return null;
    }
  }
}