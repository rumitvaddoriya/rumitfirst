// To parse this JSON data, do
//
//     final homeData = homeDataFromJson(jsonString);

import 'dart:convert';

HomeData homeDataFromJson(String str) => HomeData.fromJson(json.decode(str));

String homeDataToJson(HomeData data) => json.encode(data.toJson());

class HomeData {
  HomeData({
    this.success,
    this.code,
    this.message,
    this.body,
  });

  bool? success;
  int? code;
  String? message;
  List<Body>? body;

  factory HomeData.fromJson(Map<String, dynamic> json) => HomeData(
    success: json["success"],
    code: json["code"],
    message: json["message"],
    body: json["body"] == null ? [] : List<Body>.from(json["body"]!.map((x) => Body.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "success": success,
    "code": code,
    "message": message,
    "body": body == null ? [] : List<dynamic>.from(body!.map((x) => x.toJson())),
  };
}

class Body {
  Body({
    this.id,
    this.image,
    this.name,
  });

  int? id;
  String? image;
  String? name;

  factory Body.fromJson(Map<String, dynamic> json) => Body(
    id: json["id"],
    image: json["image"],
    name: json["name"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "image": image,
    "name": name,
  };
}
