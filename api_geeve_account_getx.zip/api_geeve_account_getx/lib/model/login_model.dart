// To parse this JSON data, do
//
//     final loginData = loginDataFromJson(jsonString);

import 'dart:convert';

LoginData loginDataFromJson(String str) => LoginData.fromJson(json.decode(str));

String loginDataToJson(LoginData data) => json.encode(data.toJson());

class LoginData {
  LoginData({
    this.success,
    this.code,
    this.message,
    this.body,
  });

  bool? success;
  int? code;
  String? message;
  Body? body;

  factory LoginData.fromJson(Map<String, dynamic> json) => LoginData(
    success: json["success"],
    code: json["code"],
    message: json["message"],
    body: json["body"] == null ? null : Body.fromJson(json["body"]),
  );

  Map<String, dynamic> toJson() => {
    "success": success,
    "code": code,
    "message": message,
    "body": body?.toJson(),
  };
}

class Body {
  Body({
    this.token,
    this.user,
  });

  String? token;
  User? user;

  factory Body.fromJson(Map<String, dynamic> json) => Body(
    token: json["token"],
    user: json["user"] == null ? null : User.fromJson(json["user"]),
  );

  Map<String, dynamic> toJson() => {
    "token": token,
    "user": user?.toJson(),
  };
}

class User {
  User({
    this.id,
    this.username,
    this.uniqueid,
    this.password,
    this.profilePic,
    this.isNewuser,
    this.language,
    this.deviceType,
    this.deviceToken,
    this.updatedAt,
    this.createdAt,
  });

  int? id;
  String? username;
  String? uniqueid;
  String? password;
  dynamic profilePic;
  int? isNewuser;
  int? language;
  String? deviceType;
  String? deviceToken;
  DateTime? updatedAt;
  DateTime? createdAt;

  factory User.fromJson(Map<String, dynamic> json) => User(
    id: json["id"],
    username: json["username"],
    uniqueid: json["uniqueid"],
    password: json["password"],
    profilePic: json["profile_pic"],
    isNewuser: json["is_newuser"],
    language: json["language"],
    deviceType: json["device_type"],
    deviceToken: json["device_token"],
    updatedAt: json["updated_at"] == null ? null : DateTime.parse(json["updated_at"]),
    createdAt: json["created_at"] == null ? null : DateTime.parse(json["created_at"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "username": username,
    "uniqueid": uniqueid,
    "password": password,
    "profile_pic": profilePic,
    "is_newuser": isNewuser,
    "language": language,
    "device_type": deviceType,
    "device_token": deviceToken,
    "updated_at": updatedAt?.toIso8601String(),
    "created_at": createdAt?.toIso8601String(),
  };
}
