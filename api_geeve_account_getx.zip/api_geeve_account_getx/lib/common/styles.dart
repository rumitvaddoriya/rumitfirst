import 'package:api_geeve_account_getx/utils/colors_res.dart';
import 'package:flutter/cupertino.dart';

TextStyle textfeild = const TextStyle(
  fontSize: 15,
  color: ColorRes.black,
);

TextStyle rememberme = const TextStyle(
  fontSize: 15,
  color: ColorRes.rememberme,
);

TextStyle Login = const TextStyle(
  fontSize: 20,
  color: ColorRes.white,
);

TextStyle forget = const TextStyle(
  fontSize: 13,
  color: ColorRes.logincolor,
);

TextStyle donthaveaccount = const TextStyle(
  fontSize: 13,
  color: ColorRes.rememberme,
);

TextStyle signup = const TextStyle(
  fontSize: 16,
  color: ColorRes.logincolor,
);

TextStyle hometitle = const TextStyle(
  fontSize: 17,
  color: ColorRes.logincolor,
);

