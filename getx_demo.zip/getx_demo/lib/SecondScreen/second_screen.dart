import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:getx_demo/SecondScreen/second_screen_controller.dart';

class SecondScreen extends StatelessWidget {
   SecondScreen({Key? key}) : super(key: key);

  final SecondScreenController secondScreenController = Get.put(SecondScreenController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Second"),
      ),
      body: Container(
        color: Colors.orange,
        width: double.infinity,
        height: 300.0,
      ),
    );
  }
}
