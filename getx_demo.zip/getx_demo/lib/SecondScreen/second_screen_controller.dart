import 'package:get/get.dart';

class SecondScreenController extends GetxController{

  @override
  void onClose() {
    // TODO: implement onClose
    print("call on close method ----->");
    super.onClose();
  }


  @override
  void onInit() {
    // TODO: implement onInit
    print("call on init ====>");
    super.onInit();
  }

  @override
  void onReady() {
    // TODO: implement onReady
    print("call on ready ====>");
    super.onReady();
  }

  @override
  void dispose() {
    // TODO: implement dispose
    print("on dispose call ----->");
    super.dispose();
  }


}