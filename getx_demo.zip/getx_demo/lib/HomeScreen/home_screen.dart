import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:getx_demo/HomeScreen/home_screen_controller.dart';

class HomeScreen extends StatelessWidget {
  HomeScreen({Key? key}) : super(key: key);

  final HomeScreenController homeScreenController = Get.put(HomeScreenController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Home"),
      ),
      body: Column(
        children: [
          Container(
            alignment: Alignment.center,
            height: 250.0,
            width: double.infinity,
            color: Colors.deepOrangeAccent,
            child: Text(
                "${homeScreenController.simpleInt}",
              style: const TextStyle(
                fontSize: 30.0
              ),
            ),
          ),
          Container(
            height: 250.0,
            alignment: Alignment.center,
            width: double.infinity,
            color: Colors.amberAccent,
            child: Obx(()=> Text(
              "${homeScreenController.rxInt.value}",
              style: const TextStyle(
                  fontSize: 30.0
              ),
            )),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          homeScreenController.navigateSecondScreen();
      },),
    );
  }
}
