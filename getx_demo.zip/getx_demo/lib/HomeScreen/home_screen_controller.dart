import 'package:get/get.dart';
import 'package:getx_demo/Routes/routes.dart';

class HomeScreenController extends GetxController{

  int simpleInt = 0;
  RxInt rxInt = 0.obs;
  RxString rxString = "".obs;
  RxDouble rxDouble = 0.0.obs;
  RxList rxList = RxList();
  RxList rxList1 = [1,2,3,4,5,6].obs;

  @override
  void onInit() {
    // TODO: implement onInit
    rxList.value = ["vapi", "surat", "Vadodara"];
    super.onInit();
  }

  navigateSecondScreen(){
    Get.toNamed(AppRoutes.secondScreen);
    // Get.offAllNamed(AppRoutes.secondScreen);     pachal ni badhi screen bandh(kill) ane new screen open
    // Get.offAndToNamed(AppRoutes.secondScreen);   chalu screen bandh(kill) and new screen open
    // Get.back();   pachal ni screen ma java mate
  }

  increment(){
    simpleInt ++;
    rxInt.value ++;
    print("simple int ----> $simpleInt");
    print("rx int ----> ${rxInt.value}");
  }


}