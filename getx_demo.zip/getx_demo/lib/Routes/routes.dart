import 'package:get/get.dart';
import 'package:getx_demo/HomeScreen/home_screen.dart';
import 'package:getx_demo/SecondScreen/second_screen.dart';

class AppRoutes{

  static const homeScreen = "/homeScreen";
  static const secondScreen = "/secondScreen";

  static List<GetPage> getPageList = [
    GetPage(name: homeScreen, page: ()=> HomeScreen(), transitionDuration: const Duration(milliseconds: 300), transition: Transition.leftToRight),
    GetPage(name: secondScreen, page: ()=> SecondScreen(), transitionDuration: const Duration(milliseconds: 300), transition: Transition.leftToRight),
  ];

}