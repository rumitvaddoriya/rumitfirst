import 'package:flutter/material.dart';

class first extends StatefulWidget {
  const first({Key? key}) : super(key: key);

  @override
  State<first> createState() => _firstState();
}

class _firstState extends State<first> {
  bool t1=false;
  bool t2=false;
  bool t3=false;
  int ans=0;
  String khali="";
  StringBuffer sp=StringBuffer();
  StringBuffer sp1=StringBuffer();
  StringBuffer sp2=StringBuffer();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("checkbox",style: TextStyle(fontSize: 20),)),
        body: Column(
          children: [
            CheckboxListTile( title: Text("KEYBORD=250/-",style: TextStyle(fontSize: 25)),value:t1,onChanged: (value) {
              setState(() {
                t1=value!;
                if(t1==true)
                {
                  ans=ans+250;
                  sp.write("250");
                }
                else
                {
                 ans=ans-250;
                 sp.clear();
                }
              });

            },),
            CheckboxListTile( title: Text("MOUCE=500/-",style: TextStyle(fontSize: 25)),value:t2,onChanged: (value) {
              setState(() {
                t2=value!;
                if(t2==true)
                {
                  ans=ans+500;
                  sp1.write("500");
                }
                else
                {
                  ans=ans-500;
                  sp1.clear();
                }
              });
            },),
            CheckboxListTile( title: Text("MONITOR=1000/-",style: TextStyle(fontSize: 25)),value:t3,onChanged: (value) {
              setState(() {
                t3=value!;
                if(t3==true)
                {
                  ans=ans+1000;
                  sp2.write("1000");
                }
                else
                {
                  ans=ans-1000;
                  sp2.clear();
                }
              });
            },),
            ElevatedButton(onPressed: () {
              setState(() {
                khali=ans.toString();
              });
            }, child: Text("sublit",style: TextStyle(fontSize: 20),)),
           Container(
                height: 100,
               width: 100,
               child: Text("${khali}")
           ),
            Container(
                height: 100,
                width: 150,
                child: Text("${sp.toString()} ${sp1.toString()}  ${sp2.toString()}")
            ),

          ],
        ),
    );
  }

}
