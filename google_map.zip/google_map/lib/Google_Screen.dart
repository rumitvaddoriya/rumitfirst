import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class MapScreen extends StatefulWidget {
  const MapScreen({Key? key}) : super(key: key);

  @override
  State<MapScreen> createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {

  late GoogleMapController mapController;

  Map<MarkerId, Marker> markers = <MarkerId, Marker>{};



  void _onMapCreated(GoogleMapController controller) {
    setState(() {
      mapController = controller;
    });
    dynamic Location = ModalRoute
        .of(context)!
        .settings
        .arguments;
    final marker = Marker(

      markerId: MarkerId('place_name'),
      position: Location,
      // icon: BitmapDescriptor.,
      infoWindow: InfoWindow(
        title: 'title',
        snippet: 'address',
      ),
    );
    setState(() {
      markers[MarkerId('place_name')] = marker;
    });
  }

  @override
  Widget build(BuildContext context) {
    dynamic Location = ModalRoute
        .of(context)!
        .settings
        .arguments;


    return Scaffold(
      body: GoogleMap(
        trafficEnabled: true,
        buildingsEnabled: true,
        onTap: (value){
          Location = value;
          print(value);
        },
        mapType: MapType.normal,
        markers: markers.values.toSet(),
        onMapCreated: _onMapCreated,
        initialCameraPosition: CameraPosition(
          target: Location,
          zoom: 14.0,
        ),
      ),);
  }
}


// import 'dart:async';
// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter/services.dart';
// import 'package:google_maps_flutter/google_maps_flutter.dart';
// import 'package:location/location.dart';
//
// class MapSample extends StatefulWidget {
//   const MapSample({Key? key}) : super(key: key);
//
//   @override
//   State<MapSample> createState() => MapSampleState();
// }
//
// class MapSampleState extends State<MapSample> {
//
//   final Completer<GoogleMapController> _controller =
//   Completer<GoogleMapController>();
//   LatLng? _latLang;
//
//   static  CameraPosition _kGooglePlex = CameraPosition(
//     target: LatLng(37.42796133580664, -122.085749655962),
//     zoom: 14.4746,
//   );
//
//   static const CameraPosition _kLake = CameraPosition(
//       bearing: 192.8334901395799,
//       target: LatLng(37.43296265331129, -122.08832357078792),
//       tilt: 59.440717697143555,
//       zoom: 19.151926040649414);
//
// Future<void> getCurrentlocation() async {
//   Location location =  Location();
//
//   bool _serviceEnabled;
//   PermissionStatus _permissionGranted;
//   LocationData _locationData;
//   try {
//     _serviceEnabled = await location.serviceEnabled();
//   } on PlatformException catch (err) {
//     print ("Platform exception calling serviceEnabled(): $err");
//     _serviceEnabled = false;
//   }
//   if (!_serviceEnabled) {
//     _serviceEnabled = await location.requestService();
//     if (!_serviceEnabled) {
//       return;
//     }
//   }
//
//   _permissionGranted = await location.hasPermission();
//   if (_permissionGranted == PermissionStatus.denied) {
//     _permissionGranted = await location.requestPermission();
//     if (_permissionGranted != PermissionStatus.granted) {
//       return;
//     }
//   }
//   _locationData = await location.getLocation();
//   _latLang = LatLng(_locationData.latitude!, _locationData.longitude!);
//   print(_latLang);
//   _kGooglePlex = CameraPosition(target: _latLang!,zoom: 14.4746);
//   setState(() {});
// }
//
//
//   @override
//   void initState() {
//   super.initState();
//     getCurrentlocation();
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(title: Text("Google Map"),),
//       body: GoogleMap(
//         mapType: MapType.normal ,
//         initialCameraPosition: _kGooglePlex,
//         markers: <Marker>{
//           _setMarker(),
//         },
//         myLocationButtonEnabled: true,
//         myLocationEnabled: true,
//         onMapCreated: (GoogleMapController controller) {
//           _controller.complete(controller);
//         },
//       ),
//       floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
//       floatingActionButton: FloatingActionButton.extended(
//         onPressed: _goToTheLake,
//         label: const Text('To the lake!'),
//         icon: const Icon(Icons.directions_boat),
//       ),
//     );
//   }
//
//   _setMarker(){
//     return Marker(
//         markerId: MarkerId("market_1"),
//         icon: BitmapDescriptor.defaultMarker,
//       position:LatLng(37.42796133580664, -122.085749655962),
//     );
//   }
//
//   Future<void> _goToTheLake() async {
//     final GoogleMapController controller = await _controller.future;
//     controller.animateCamera(CameraUpdate.newCameraPosition(_kLake));
//   }
// }
//
// // import 'package:flutter/material.dart';
// // import 'package:google_maps_flutter/google_maps_flutter.dart';
// // import 'package:search_map_place_updated/search_map_place_updated.dart';
// //
// //
// // class Google_Screen extends StatefulWidget {
// //   const Google_Screen({Key? key}) : super(key: key);
// //
// //   @override
// //   State<Google_Screen> createState() => _Google_ScreenState();
// // }
// //
// // class _Google_ScreenState extends State<Google_Screen> {
// //
// //   static const LatLng sourceLocation =  LatLng(37.33500926, - 122.03272188);
// //   static const LatLng destination =  LatLng(37.33429383, - 122.06600055);
// //
// //   GoogleMapController? Mapcontroller;
// //
// //   @override
// //   Widget build(BuildContext context) {
// //     return Scaffold(
// //       appBar: AppBar(centerTitle: true,title: Text("Google Map",style: TextStyle(fontSize: 20),),),
// //       body: SingleChildScrollView(
// //         child: Column(
// //           children: [
// //             SizedBox(height: 10,),
// //             SearchMapPlaceWidget(
// //               placeholder: "Enter the location",
// //                 placeType:PlaceType.address,
// //                  hasClearButton: true,
// //                 apiKey:"AIzaSyBv9r6W202MycwPJ_P8-fGILaUsq3vtleI",
// //               onSelected: (Place place) async {
// //                 Geolocation? geolocation = await place.geolocation;
// //                 Mapcontroller!.animateCamera(
// //                   CameraUpdate.newLatLng(geolocation!.coordinates),
// //                 );
// //                 Mapcontroller!.animateCamera(
// //                   CameraUpdate.newLatLngBounds(geolocation.bounds,0),
// //                 );
// //               },
// //             ),
// //             Padding(
// //               padding:EdgeInsets.only(top: 15),
// //               child: SizedBox(
// //                 height: 500,
// //                 child: GoogleMap(
// //                   onMapCreated: (GoogleMapController googleMapController) {
// //                       setState(() {
// //                         Mapcontroller = googleMapController;
// //                       });
// //                   },
// //                   mapType: MapType.normal,
// //                     initialCameraPosition: CameraPosition(target: sourceLocation,zoom: 15),
// //                   markers: {
// //                       Marker(
// //                         markerId: MarkerId("source"),
// //                         position: sourceLocation,
// //                       ),
// //                     Marker(
// //                       markerId: MarkerId("destination"),
// //                       position: destination,
// //                     ),
// //                   },
// //                 ),
// //               ),
// //             ),
// //           ],
// //         ),
// //       ),
// //     );
// //   }
// // }
