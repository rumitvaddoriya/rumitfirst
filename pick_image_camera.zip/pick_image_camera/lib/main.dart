import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:pick_image_camera/Pick_image_camera.dart';

void main(){
  runApp(MaterialApp(home: Pick_image_camera(),));
}