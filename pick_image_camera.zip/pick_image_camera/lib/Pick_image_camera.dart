import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';

class Pick_image_camera extends StatefulWidget {
  const Pick_image_camera({Key? key}) : super(key: key);

  @override
  State<Pick_image_camera> createState() => _Pick_image_cameraState();
}

class _Pick_image_cameraState extends State<Pick_image_camera> {
  ImagePicker _picker = ImagePicker();
  File? image;
  List<XFile> _imagelist =[];

  void pickGallery() async {
    final XFile? selectedimage = await _picker.pickImage(source: ImageSource.gallery);
    print(selectedimage!.path);
    if(selectedimage!.path.isNotEmpty){
      _imagelist.add(selectedimage);
    }
    setState(() {

    });
  }

  void pickCamera() async {
    final XFile? photo = await _picker.pickImage(source: ImageSource.camera);
    if(photo!.path.isNotEmpty){
      _imagelist.add(photo);
    }
    setState(() {

    });
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Pick image-camera"),
      ),
      floatingActionButton:FloatingActionButton(
        child: Icon(Icons.add),
        onPressed: () {
          showDialog(
            context: context,
            builder: (context) {
              return AlertDialog(
                title: Text("Select Camera and Gallery"),
                actions: [
                  ElevatedButton(
                      onPressed: () async {
                        pickCamera();
                        Navigator.pop(context);
                      }, child: Text("Camera")),
                  ElevatedButton(
                      onPressed: () {
                        pickGallery();
                        Navigator.pop(context);
                      }, child: Text("Gallery")),
                ],
              );
            },
          );
      },),
      body: Column(
        children: [
          SizedBox(
            height: 10,
          ),
          Expanded(
            child: GridView.builder(
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3),
                itemCount: _imagelist.length,
                itemBuilder: (context, index) {
                  return Image.file(File(_imagelist[index].path));
                },
            ),
          ),
        ],
      ),
    );
  }
}
