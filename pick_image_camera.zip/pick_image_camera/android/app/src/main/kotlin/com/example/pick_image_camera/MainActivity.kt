package com.example.pick_image_camera

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
