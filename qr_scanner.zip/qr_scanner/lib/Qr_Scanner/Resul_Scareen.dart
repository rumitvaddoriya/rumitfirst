import 'package:flutter/material.dart';

const bgcolor = Color(0xfffafafa);

class Result_Scareen extends StatefulWidget {
  const Result_Scareen({Key? key}) : super(key: key);

  @override
  State<Result_Scareen> createState() => _Result_ScareenState();
}

class _Result_ScareenState extends State<Result_Scareen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgcolor,
      appBar: AppBar(centerTitle: true,title: Text("QR Scanner",style: TextStyle(fontSize: 18,color: Colors.black87,letterSpacing: 1),),),
      body: Padding(
        padding: EdgeInsets.all(12),
        child: Column(
          children: [

            Text("Scanned Result",style: TextStyle(fontSize: 18,color: Colors.black54,letterSpacing: 1),),
            SizedBox(height: 10,),
            Text("Scanned Result",style: TextStyle(fontSize: 18,color: Colors.black87,letterSpacing: 1),),
            SizedBox(height: 10,),
            ElevatedButton(onPressed: () {

            }, child: Text("Scan",style: TextStyle(fontSize: 18,color: Colors.black54,letterSpacing: 1),))
          ],
        ),
      ),
    );
  }
}

