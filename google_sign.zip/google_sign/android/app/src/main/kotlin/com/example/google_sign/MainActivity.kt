package com.example.google_sign

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
