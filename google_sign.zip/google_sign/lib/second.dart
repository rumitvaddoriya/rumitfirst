import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_sign/first.dart';
import 'package:google_sign_in/google_sign_in.dart';

class second extends StatefulWidget {
  const second({Key? key}) : super(key: key);

  @override
  State<second> createState() => _secondState();
}

class _secondState extends State<second> {

  @override
  void initState() {
    user = FirebaseAuth.instance.currentUser;
    if(user==null)
      {
        print("Not login");
      }
    else
      {
        print(user!.email);
        print(user!.displayName);
        print(user!.uid);
      }
  }

  User ?user;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(title: Text("Log out"),
          actions: [
            IconButton(onPressed: () async {
              GoogleSignIn().signOut();
              await FirebaseAuth.instance.signOut();
              Navigator.push(context, MaterialPageRoute(builder: (context) {
                return first();
              },));
            }, icon: Icon(Icons.logout))
          ],
        ),
      body: Column(
        children: [
          Center(child: Text("${user!.displayName}")),
          Center(child: Text("${user!.email}")),
          Center(child: Text("${user!.uid}")),
        ],
      )

    );
  }
}
