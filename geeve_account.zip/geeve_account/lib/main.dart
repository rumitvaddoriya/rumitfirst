import 'package:flutter/material.dart';
import 'package:geeve_account/Login/Login_Screen.dart';


void main(){
  runApp(
      MaterialApp(
        debugShowCheckedModeBanner: false,
        home: Login_Screen(),
      ),
  );
}
