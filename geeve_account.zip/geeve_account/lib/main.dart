import 'package:flutter/material.dart';
import 'package:geeve_account/Splash/Splash_Screen.dart';

void main(){
  runApp(
      MaterialApp(
        debugShowCheckedModeBanner: false,
        home: Splash_Screen(),
      ),
  );
}
