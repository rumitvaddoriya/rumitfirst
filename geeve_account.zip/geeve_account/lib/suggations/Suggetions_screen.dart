import 'package:flutter/material.dart';
import 'package:geeve_account/Signup/Signup_Screen.dart';
import 'package:geeve_account/Splash/Splash_Screen.dart';
import 'package:geeve_account/model/model.dart';
import 'package:geeve_account/phone_verifications/phone_veridications.dart';

class Suggetions_screen extends StatefulWidget {
  const Suggetions_screen({Key? key}) : super(key: key);

  @override
  State<Suggetions_screen> createState() => _Suggetions_screenState();
}

class _Suggetions_screenState extends State<Suggetions_screen> {

  TextEditingController Nonprofitcontroller = TextEditingController();


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(80),
          child:AppBar(
            automaticallyImplyLeading: false,
            elevation: 0,
            leading: GestureDetector(
              onTap: () {
                Navigator.push(context, MaterialPageRoute(builder: (context) {
                  return Signup_Screen(null);
                },));
              },
                child: Image.asset("images/icn menu.png"),
            ),
            backgroundColor:Color(0xfffa7914),
            shape: const RoundedRectangleBorder(
              borderRadius: BorderRadius.only(
                  bottomRight: Radius.circular(25),
                  topLeft: Radius.circular(25),
                  topRight: Radius.circular(25)),
            ),
            centerTitle: true,
            title: Padding(
              padding: EdgeInsets.only(top:5),
              child: Container(
                height: 50,
                width: 250,
                decoration: BoxDecoration(
                    color:Colors.white,
                   borderRadius: BorderRadius.all(Radius.circular(15))
                ),
                child: TextField(
                  controller: Nonprofitcontroller,
                  decoration: InputDecoration(
                    prefixIcon:Icon(Icons.search_rounded),
                    border: InputBorder.none,
                    hintText: "Non profit",
                  ),
                ),
              ),
            ),
          ),
      ),
      body: Column(
        children: [
          SizedBox(height: 10,),
          Center(
            child: GestureDetector(
              onTap: () {
                Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) {
                  return phone_verifications();
                },));
              },
              child: Container(
                height: 50,
                width: 320,
                margin: EdgeInsets.only(left: 10,right: 10),
                decoration: BoxDecoration(
                    border: Border(
                      bottom: BorderSide(
                          width: 0.5, color: Colors.black26),
                    )),
                child:Padding(
                  padding:  EdgeInsets.only(left: 3,top: 10),
                  child: Text("Suggestions",style: TextStyle(fontSize: 17,color: Color(0xfffa7914),),),
                ),
              ),
            ),
          ),
          SizedBox(height: 5,),
          Expanded(
            child: ListView.builder(
              itemCount: listdata.length,
              itemBuilder: (context,index) {
                return Container(
                  height: 70,
                  margin: EdgeInsets.only(left: 10,right: 10),
                  decoration: BoxDecoration(
                      border: Border(
                        top: BorderSide(
                            width: 0.5, color: Colors.white10),
                        bottom: BorderSide(
                            width: 0.5, color: Colors.black26),
                      )),
                  alignment: Alignment.centerLeft,
                  child: Row(
                    mainAxisAlignment:
                    MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        height: MediaQuery.of(context).size.height * 0.8 / 8,
                        width: MediaQuery.of(context).size.height * 0.18,
                        alignment: Alignment.centerLeft,
                        child: Column(
                          crossAxisAlignment:
                          CrossAxisAlignment.start,
                          mainAxisAlignment:
                          MainAxisAlignment.center,
                          children: [
                            Text(
                               "${listdata[index].firstname} ",
                              style: TextStyle(
                                  fontSize: 16,
                                  fontFamily: 'FontsFree',
                                  fontWeight: FontWeight.bold),
                            ),
                            SizedBox(
                              height: 1,
                            ),
                            Text(
                              "${listdata[index].lastname} ",
                              style: TextStyle(
                                  fontSize: 13,
                                  color: Color(0xff7d7f86)),
                            ),
                            SizedBox(
                              height: 1,
                            ),
                            Text(
                              "${listdata[index].email} ",
                              style: TextStyle(
                                  fontSize: 13,
                                  color: Color(0xff7d7f86)),
                            ),
                          ],
                        ),
                      ),
                      Padding(
                        padding:  EdgeInsets.only(left: 20),
                        child: Container(
                            height: MediaQuery.of(context).size.height * 0.4 / 5,
                            width: MediaQuery.of(context).size.width * 0.23,
                            alignment: Alignment.center,
                            child: Text(
                              "${listdata[index].phone} ",
                              style: TextStyle(
                                  fontSize: 14,
                                  color: Color(0xff7d7f86)),
                            ),
                            ),
                      ),
                      Padding(
                        padding:  EdgeInsets.only(left:19),
                        child: IconButton(
                            onPressed: () {
                              Navigator.push(context,
                                  MaterialPageRoute(
                                      builder: (contextt) {
                                        return Signup_Screen(index);
                                      }));
                            },
                            icon: Icon(
                              Icons.edit,
                              size: 20,
                              color: Color(0xfffa7914),
                            )),
                      ),
                      IconButton(
                          onPressed: () {
                            listdata.removeAt(index);
                            Navigator.push(context, MaterialPageRoute(builder: (contextt) {
                              return Splash_Screen();
                            }));
                          },
                          icon: Icon(
                            Icons.delete,
                            size: 20,
                            color: Color(0xfffa7914),
                          )),
                    ],
                  ),
                );
            },),
          ),
          Container(
            height:100,
            width: double.infinity,
            decoration: BoxDecoration(image: DecorationImage(image: AssetImage("images/Layer 7.png"),fit: BoxFit.fill)),
          ),
        ],
      ),
    );
  }
}





// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// import 'package:sqf_database/database/sqflite_database.dart';
// import 'package:sqf_database/screens/signup_screen.dart';
//
// class NonprofitScreen extends StatefulWidget {
//   const NonprofitScreen({Key? key}) : super(key: key);
//
//   @override
//   State<NonprofitScreen> createState() => _NonprofitScreenState();
// }
//
// class _NonprofitScreenState extends State<NonprofitScreen> {
//
//   var db = DatabaseHelper();
//
//   @override
//   void initState() {
//     // TODO: implement initState
//     super.initState();
//     setState(() {
//       getData();
//     });
//   }
//
//   void getData() {
//     setState(() {
//       DatabaseHelper db = DatabaseHelper();
//       db.readData();
//     });
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return SafeArea(
//         child: Scaffold(
//           appBar: AppBar(
//             toolbarHeight: 100,
//             shape: RoundedRectangleBorder(
//                 borderRadius: BorderRadius.only(bottomRight: Radius.circular(30))),
//             backgroundColor: Color(0xfffa7914),
//             title: TextField(
//               decoration: InputDecoration(
//                 hintText: "Non Profit",
//                 hintStyle: TextStyle(color: Color(0xff7d7f86)),
//                 prefixIcon: Icon(
//                   Icons.search,
//                   color: Color(0xff7d7f86),
//                 ),
//                 filled: true,
//                 fillColor: Color(0xfff6f6f6),
//                 enabledBorder: OutlineInputBorder(
//                   borderSide: BorderSide(color: Color(0xfff6f6f6)),
//                   borderRadius: BorderRadius.circular(20),
//                 ),
//               ),
//             ),
//           ),
//           body: Stack(
//             children: [
//               Column(
//                 mainAxisAlignment: MainAxisAlignment.end,
//                 children: [
//                   Image.asset("assets/background.png"),
//                 ],
//               ),
//               FutureBuilder(
//                 future: db.readData(),
//                 builder: (context, snapshot) {
//                   if (snapshot.hasError) {
//                     return Text("${snapshot.error}");
//                   } else if (snapshot.hasData) {
//                     List newData = snapshot.data!;
//                     return Column(
//                       children: [
//                         Row(
//                           mainAxisAlignment: MainAxisAlignment.start,
//                           children: [
//                             Padding(
//                               padding: const EdgeInsets.only(top: 35, left: 35),
//                               child: Text(
//                                 "Suggestions",
//                                 style: TextStyle(
//                                     fontSize: 18, color: Color(0xfffa7914)),
//                               ),
//                             ),
//                           ],
//                         ),
//                         Expanded(
//                           child: Padding(
//                             padding:
//                             const EdgeInsets.only(top: 35, left: 35, right: 35),
//                             child: ListView.builder(
//                                 itemCount: newData.length,
//                                 itemBuilder: (context, index) {
//                                   return InkWell(
//                                     onDoubleTap: () {
//                                       showDialog(
//                                           context: context,
//                                           builder: (context) {
//                                             return AlertDialog(
//                                               title: Text("Are You Sure??"),
//                                               actions: [
//                                                 TextButton(
//                                                     onPressed: () {
//                                                       Navigator.pop(context);
//                                                     },
//                                                     child: Text(
//                                                       "Cancle",
//                                                       style: TextStyle(
//                                                           color: Colors.red),
//                                                     )),
//                                                 ElevatedButton(
//                                                     style: ElevatedButton.styleFrom(
//                                                       backgroundColor: Colors.red,
//                                                     ),
//                                                     onPressed: () {
//                                                       DatabaseHelper db =
//                                                       DatabaseHelper();
//                                                       db.deleteData(
//                                                           "${newData[index]["id"]}");
//                                                       getData();
//                                                       Navigator.pop(context);
//                                                     },
//                                                     child: Text("Delete")),
//                                               ],
//                                             );
//                                           });
//                                     },
//                                     child: Container(
//                                         height: 70,
//                                         decoration: BoxDecoration(
//                                             border: Border(
//                                               top: BorderSide(
//                                                   width: 0.5, color: Colors.black26),
//                                               bottom: BorderSide(
//                                                   width: 0.5, color: Colors.black26),
//                                             )),
//                                         alignment: Alignment.centerLeft,
//                                         child: Row(
//                                           mainAxisAlignment:
//                                           MainAxisAlignment.spaceBetween,
//                                           children: [
//                                             Container(
//                                               height: MediaQuery.of(context)
//                                                   .size
//                                                   .height *
//                                                   0.4 /
//                                                   5,
//                                               width: MediaQuery.of(context)
//                                                   .size
//                                                   .height *
//                                                   0.18,
//                                               alignment: Alignment.centerLeft,
//                                               child: Column(
//                                                 crossAxisAlignment:
//                                                 CrossAxisAlignment.start,
//                                                 mainAxisAlignment:
//                                                 MainAxisAlignment.center,
//                                                 children: [
//                                                   Text(
//                                                     "${newData[index]["firstname"]} ${newData[index]["lastname"]} ",
//                                                     style: TextStyle(
//                                                         fontSize: 16,
//                                                         fontWeight:
//                                                         FontWeight.bold),
//                                                   ),
//                                                   SizedBox(
//                                                     height: 5,
//                                                   ),
//                                                   Text(
//                                                     "${newData[index]["phone"]}",
//                                                     style: TextStyle(
//                                                         fontSize: 10,
//                                                         color: Color(0xff7d7f86)),
//                                                   ),
//                                                 ],
//                                               ),
//                                             ),
//                                             Container(
//                                                 height: MediaQuery.of(context)
//                                                     .size
//                                                     .height *
//                                                     0.4 /
//                                                     5,
//                                                 width: MediaQuery.of(context)
//                                                     .size
//                                                     .width *
//                                                     0.2,
//                                                 alignment: Alignment.centerLeft,
//                                                 child: Text(
//                                                   "${newData[index]["password"]}",
//                                                   style: TextStyle(
//                                                       fontSize: 14,
//                                                       color: Color(0xff7d7f86)),
//                                                 )),
//                                             IconButton(
//                                                 onPressed: () {
//                                                   Navigator.push(context,
//                                                       MaterialPageRoute(
//                                                           builder: (context) {
//                                                             return SignUpScreen(
//                                                               index: index,
//                                                             );
//                                                           }));
//                                                 },
//                                                 icon: Icon(
//                                                   Icons.edit,
//                                                   size: 30,
//                                                   color: Color(0xfffa7914),
//                                                 ))
//                                           ],
//                                         )),
//                                   );
//                                 }),
//                           ),
//                         ),
//                       ],
//                     );
//                   }
//                   return CircularProgressIndicator();
//                 },
//               ),
//             ],
//           ),
//         ));
//   }
// }