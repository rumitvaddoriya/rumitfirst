// import 'package:flutter/material.dart';
// import 'package:smooth_page_indicator/smooth_page_indicator.dart';
//
// import 'Login/Login_Screen.dart';
// import 'Signup/Signup_Screen.dart';
//
// class splashh extends StatefulWidget {
//   const splashh({Key? key}) : super(key: key);
//
//   @override
//   State<splashh> createState() => _splashhState();
// }
//
// class _splashhState extends State<splashh> {
//
//   PageController  pageController = PageController();
//   int currentpage = 0;
//
//   List<Map<String,dynamic>> nameList = [
//     {"imageurl":"images/Layer 11.png","title":"Let's getstarted","description":"Nemo enim ipsam voluptatem quia voluptas sit aspernature aut odit aut fugit, sed quia consequuntur magni dolores"},
//     {"imageurl":"images/Layer 11.png","title":"Let's getstarted","description":"Nemo enim ipsam voluptatem quia voluptas sit aspernature aut odit aut fugit, sed quia consequuntur magni dolores"},
//     {"imageurl":"images/Layer 11.png","title":"Let's getstarted","description":"Nemo enim ipsam voluptatem quia voluptas sit aspernature aut odit aut fugit, sed quia consequuntur magni dolores"},
//   ];
//
//   _onpagechanged(int index){
//     setState(() {
//       currentpage = index;
//     });
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     double width=MediaQuery.of(context).size.width;
//     double height=MediaQuery.of(context).size.height;
//     double appbarheight=kToolbarHeight;
//     double statusbarhright=MediaQuery.of(context).padding.top;
//     double bottombarhright=MediaQuery.of(context).padding.bottom;
//
//     double bodyheight=height-appbarheight-statusbarhright-bottombarhright;
//     return Scaffold(
//       body: Column(
//         children: [
//           Center(child: SizedBox(height: 50,)),
//           Container(
//             height: bodyheight*0.1,
//             width: width*0.5,
//             decoration: BoxDecoration(image: DecorationImage(image: AssetImage("images/Layer 8.png"),fit: BoxFit.fill)),
//           ),
//           Container(
//             height: bodyheight*0.49,
//             width: width*0.85,
//             color: Colors.green,
//             child: PageView.builder(
//               controller: pageController,
//               onPageChanged:_onpagechanged,
//               itemCount: nameList.length,itemBuilder: (context, index) {
//               return Column(
//                 children: [
//                   SizedBox(height: 15,),
//                   Container(
//                     height: bodyheight*0.25,
//                     width: width*0.70,
//                     decoration: BoxDecoration(image: DecorationImage(image: AssetImage(nameList[index]['imageurl']),fit: BoxFit.fill)),
//                   ),
//                   SizedBox(height: 20,),
//                   Text(nameList[index]['title'],style: TextStyle(color: Color(0xff121212),fontSize: 20, fontFamily: 'FontsFree',),),
//                   SizedBox(height: 10,),
//                   SizedBox(
//                     width: 300,
//                     child:  Text(
//                       textAlign: TextAlign.center,
//                       nameList[index]['description'].toString(),
//                       style: TextStyle(
//                         color: Color(0xff7d7f86),
//                         fontSize: 14,
//                         fontFamily: 'FontsFree',
//                       ),
//                     ),
//                   ),
//                 ],
//               );
//             },),
//           ),
//           SizedBox(height: 50,),
//           InkWell(
//             onTap: () {
//               Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) {
//                 return Signup_Screen();
//               },));
//             },
//             child: Container(
//               height: bodyheight*0.1,
//               width: width*0.75,
//               child: Center(child: Text("Create Account",style: TextStyle(fontSize: 16, fontFamily: 'FontsFree',color: Colors.white),),),
//               decoration: BoxDecoration(color: Color(0xfffa7914),borderRadius: BorderRadius.all(Radius.circular(50)),boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.40),blurRadius: 5,offset: const Offset(1, 0)),]),
//             ),
//           ),
//           SizedBox(height: 15,),
//           GestureDetector(
//             onTap: () {
//               Navigator.push(context, MaterialPageRoute(builder: (context) {
//                 return Login_Screen();
//               },));
//             },
//             child: Container(
//               height: bodyheight*0.1,
//               width: width*0.75,
//               child: Center(child: Text("Login",style: TextStyle(fontSize: 16,color: Color(0xfffa7914)),),),
//               decoration: BoxDecoration(color:Colors.white,borderRadius: BorderRadius.all(Radius.circular(50),),boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.1),blurRadius: 5,offset: const Offset(3, 0),),]),
//             ),
//           ),
//           SizedBox(height: 30,),
//           Container(
//             height:bodyheight*0.1,
//             width: double.infinity,
//             decoration: BoxDecoration(image: DecorationImage(image: AssetImage("images/Layer 7.png"),fit: BoxFit.fill)),
//           ),
//         ],
//       ),
//     );
//   }
// }
