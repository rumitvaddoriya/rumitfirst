import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:geeve_account/Login/Login_Screen.dart';
import 'package:geeve_account/model.dart';

class Signup_Screen extends StatefulWidget {
  const Signup_Screen({Key? key}) : super(key: key);

  @override
  State<Signup_Screen> createState() => _Signup_ScreenState();
}

class _Signup_ScreenState extends State<Signup_Screen> {

  TextEditingController fnamecontroller = TextEditingController();
  TextEditingController lnamecontroller = TextEditingController();
  TextEditingController phonecontroller = TextEditingController();
  TextEditingController emailcontroller = TextEditingController();
  TextEditingController passwordcontroller = TextEditingController();
  TextEditingController cpasswordcontroller = TextEditingController();
  GlobalKey<FormState> formkey = GlobalKey<FormState>();
  bool email = true;


  datadd(context){
    if(formkey.currentState!.validate()){
      for(int i=0; i< listdata.length; i++)
      {
        print("--------->${listdata.first.email}");
        if(listdata[i].email == emailcontroller.text){
          email = false;
          print("yes");
        }else
          {
            print("No");
          }
      }
      if(email){
        //print("------------> ${listdata.first.password}");
        listdata.add(
          User(
              firstname: fnamecontroller.text,
              lastname: lnamecontroller.text,
              phone: phonecontroller.text,
              email: emailcontroller.text,
              password:passwordcontroller.text,
              confirmpassword: cpasswordcontroller.text
          ),
        );
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) {
          return Login_Screen();
        },));
      }else{
        print("wrong value");
      }
    }else{
      print("Error");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor:Color(0xFFffffff),
      body: SingleChildScrollView(
        child: Form(
          key: formkey,
          child: Column(
            children: [
              Center(child: SizedBox(height: 60,)),
              Container(
                height: 70,
                width: 150,
                decoration: BoxDecoration(image: DecorationImage(image: AssetImage("images/Layer 8.png"),fit: BoxFit.fill)),
              ),
              SizedBox(height: 20,),
              Padding(
                padding:  EdgeInsets.only(left: 45,right: 45),
                child: TextFormField(
                  controller:fnamecontroller,
                  style: TextStyle(
                      fontSize: 15,
                      fontFamily: 'FontsFree',color: Colors.black),
                  decoration: InputDecoration(
                    border: InputBorder.none,
                    hintText: "First Name",
                    filled: true,
                    fillColor: Color(0xfff6f6f6),
                    enabledBorder: OutlineInputBorder(
                      borderSide:
                      BorderSide(color: Color(0xfff6f6f6)),
                      borderRadius: BorderRadius.circular(50),
                    ),
                  ),
                  validator:(value) {
                    if(value!.isEmpty)
                    {
                      return 'Enter First Name';
                    }
                  },
                ),
              ),
              // Container(
              //   height:50,
              //   width: 270,
              //   decoration: BoxDecoration(color: Color(0xfff6f6f6),borderRadius: BorderRadius.all(Radius.circular(20))),
              //   child: Padding(
              //     padding:  EdgeInsets.only(left: 25),
              //     child: Center(
              //       child: TextField(
              //         style: TextStyle( color: Color(0xff7d7f86),
              //           fontSize: 15,
              //           fontFamily: 'FontsFree',),
              //         controller: fnamecontroller,
              //         decoration: InputDecoration(
              //           border: InputBorder.none,
              //           hintText: "First Name",
              //         ),
              //       ),
              //     ),
              //   ),
              // ),

              SizedBox(height: 10,),
              Padding(
                padding:  EdgeInsets.only(left: 45,right: 45),
                child: TextFormField(
                  controller:lnamecontroller,
                  style: TextStyle(
                      fontSize: 15,
                      fontFamily: 'FontsFree',color: Colors.black),
                  decoration: InputDecoration(
                    border: InputBorder.none,
                    hintText: "Last Name",
                    filled: true,
                    fillColor: Color(0xfff6f6f6),
                    enabledBorder: OutlineInputBorder(
                      borderSide:
                      BorderSide(color: Color(0xfff6f6f6)),
                      borderRadius: BorderRadius.circular(50),
                    ),
                  ),
                  validator:(value) {
                    if(value!.isEmpty)
                    {
                      return 'Enter Last Name';
                    }
                  },
                ),
              ),
              // Container(
              //   height:50,
              //   width: 270,
              //   decoration: BoxDecoration(color: Color(0xfff6f6f6),borderRadius: BorderRadius.all(Radius.circular(20))),
              //   child: Padding(
              //     padding:  EdgeInsets.only(left: 25),
              //     child: Center(
              //       child: TextField(
              //         style: TextStyle( color: Color(0xff7d7f86),
              //           fontSize: 15,
              //           fontFamily: 'FontsFree',),
              //         controller: lnamecontroller,
              //         decoration: InputDecoration(
              //           border: InputBorder.none,
              //           hintText: "Last Name",
              //         ),
              //       ),
              //     ),
              //   ),
              // ),
              SizedBox(height: 10,),
              Padding(
                padding:  EdgeInsets.only(left: 45,right: 45),
                child: TextFormField(
                  controller:phonecontroller,
                  style: TextStyle(
                      fontSize: 15,
                      fontFamily: 'FontsFree',color: Colors.black),
                  decoration: InputDecoration(
                    border: InputBorder.none,
                    hintText: "Phone",
                    filled: true,
                    fillColor: Color(0xfff6f6f6),
                    enabledBorder: OutlineInputBorder(
                      borderSide:
                      BorderSide(color: Color(0xfff6f6f6)),
                      borderRadius: BorderRadius.circular(50),
                    ),
                  ),
                  validator:(value) {
                    if(value!.isEmpty)
                    {
                      return 'Enter Phone';
                    }
                  },
                ),
              ),
              // Container(
              //   height:50,
              //   width: 270,
              //   decoration: BoxDecoration(color: Color(0xfff6f6f6),borderRadius: BorderRadius.all(Radius.circular(20))),
              //   child: Padding(
              //     padding:  EdgeInsets.only(left: 25),
              //     child: Center(
              //       child: TextField(
              //         style: TextStyle( color: Color(0xff7d7f86),
              //           fontSize: 15,
              //           fontFamily: 'FontsFree',),
              //         controller: phonecontroller,
              //         decoration: InputDecoration(
              //           border: InputBorder.none,
              //           hintText: "Phone",
              //         ),
              //       ),
              //     ),
              //   ),
              // ),
              SizedBox(height: 10,),
              Padding(
                padding:  EdgeInsets.only(left: 45,right: 45),
                child: TextFormField(
                  controller:emailcontroller,
                  style: TextStyle(
                      fontSize: 15,
                      fontFamily: 'FontsFree',color: Colors.black),
                  decoration: InputDecoration(
                    border: InputBorder.none,
                    hintText: "Email",
                    filled: true,
                    fillColor: Color(0xfff6f6f6),
                    enabledBorder: OutlineInputBorder(
                      borderSide:
                      BorderSide(color: Color(0xfff6f6f6)),
                      borderRadius: BorderRadius.circular(50),
                    ),
                  ),
                  validator:(value) {
                    bool emailvalid = RegExp(r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`  {|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+").hasMatch(value!);
                    if(value!.isEmpty)
                    {
                      return 'Enter Email';
                    }else if(!emailvalid){
                      return "Enter Valid email";
                    }
                  },
                ),
              ),
                // Container(
              //   height:50,
              //   width: 270,
              //   decoration: BoxDecoration(color: Color(0xfff6f6f6),borderRadius: BorderRadius.all(Radius.circular(20))),
              //   child: Padding(
              //     padding:  EdgeInsets.only(left: 25),
              //     child: Center(
              //       child: TextField(
              //         style: TextStyle( color: Color(0xff7d7f86),
              //           fontSize: 15,
              //           fontFamily: 'FontsFree',),
              //         controller: emailcontroller,
              //         decoration: InputDecoration(
              //           border: InputBorder.none,
              //           hintText: "Email",
              //         ),
              //       ),
              //     ),
              //   ),
              // ),
              SizedBox(height: 10,),
              Padding(
                padding:  EdgeInsets.only(left: 45,right: 45),
                child: TextFormField(
                  keyboardType: TextInputType.number,
                  controller:passwordcontroller,
                  style: TextStyle(
                      fontSize: 15,
                      fontFamily: 'FontsFree',color: Colors.black),
                  decoration: InputDecoration(
                    border: InputBorder.none,
                    hintText: "Password",
                    filled: true,
                    fillColor: Color(0xfff6f6f6),
                    enabledBorder: OutlineInputBorder(
                      borderSide:
                      BorderSide(color: Color(0xfff6f6f6)),
                      borderRadius: BorderRadius.circular(50),
                    ),
                  ),
                  validator: (value){
                    if(value == null || value.isEmpty)
                    {
                      return 'Please Enter Password';
                    }else if(value.length < 6)
                    {
                      return 'At Least 6 char required';
                    }
                    return null;
                  },
                ),
              ),
              // Container(
              //   height:50,
              //   width: 270,
              //   decoration: BoxDecoration(color: Color(0xfff6f6f6),borderRadius: BorderRadius.all(Radius.circular(20))),
              //   child: Padding(
              //     padding:  EdgeInsets.only(left: 25),
              //     child: Center(
              //       child: TextField(
              //         style: TextStyle( color: Color(0xff7d7f86),
              //           fontSize: 15,
              //           fontFamily: 'FontsFree',),
              //         controller: passwordcontroller,
              //         decoration: InputDecoration(
              //           border: InputBorder.none,
              //           hintText: "password",
              //         ),
              //       ),
              //     ),
              //   ),
              // ),
              SizedBox(height: 10,),
              Padding(
                padding:  EdgeInsets.only(left: 45,right: 45),
                child: TextFormField(
                  keyboardType: TextInputType.number,
                  controller:cpasswordcontroller,
                  style: TextStyle(
                      fontSize: 15,
                      fontFamily: 'FontsFree',color: Colors.black),
                  decoration: InputDecoration(
                    border: InputBorder.none,
                    hintText: "Confirm Password",
                    filled: true,
                    fillColor: Color(0xfff6f6f6),
                    enabledBorder: OutlineInputBorder(
                      borderSide:
                      BorderSide(color: Color(0xfff6f6f6)),
                      borderRadius: BorderRadius.circular(50),
                    ),
                  ),
                  validator: (value){
                    if(value == null || value.isEmpty)
                    {
                      return 'Please Enter Password';
                    }else if(value.length < 6)
                    {
                      return 'At Least 6 char required';
                    }
                    return null;
                  },
                ),
              ),
              // Container(
              //   height:50,
              //   width: 270,
              //   decoration: BoxDecoration(color: Color(0xfff6f6f6),borderRadius: BorderRadius.all(Radius.circular(20))),
              //   child: Padding(
              //     padding:  EdgeInsets.only(left: 25),
              //     child: Center(
              //       child: TextField(
              //         style: TextStyle( color: Color(0xff7d7f86),
              //           fontSize: 15,
              //           fontFamily: 'FontsFree',),
              //         controller: cpasswordcontroller,
              //         decoration: InputDecoration(
              //           border: InputBorder.none,
              //           hintText: "Confirm password",
              //         ),
              //       ),
              //     ),
              //   ),
              // ),
              SizedBox(height: 20,),
              Row(
                children: [
                  Padding(
                    padding: EdgeInsets.only(left: 15),
                    child: Container(
                      margin: EdgeInsets.only(left: 30),
                      height: 30,
                      width: 30,
                      decoration: BoxDecoration(color: Color(0xfff6f6f6),borderRadius: BorderRadius.all(Radius.circular(10))),
                    ),
                  ),
                  SizedBox(width:10,),
                  Text("I agree to the geeve ",style: TextStyle(fontSize: 13, fontFamily: 'FontsFree', color: Color(0xff7d7f86),),),
                  Text("Terms and Conditions",style: TextStyle(fontSize: 13,color: Color(0xfffa7914),),),
                ],
              ),
              SizedBox(height: 25,),
              GestureDetector(
                onTap: () {
                  datadd(context);
                },
                child: Container(
                  height: 50,
                  width: 270,
                  child: Center(child: Text("Sign up",style: TextStyle(fontSize: 16, fontFamily: 'FontsFree',color: Colors.white),),),
                  decoration: BoxDecoration(color: Color(0xfffa7914),borderRadius: BorderRadius.all(Radius.circular(50),),boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.40),blurRadius:5,offset: const Offset(1, 0)),]),
                ),
              ),
              SizedBox(height: 30,),
              Text("Don't have an account?",style: TextStyle(fontSize: 14, color: Color(0xff7d7f86),fontFamily: 'FontsFree',),),
               SizedBox(height: 5,),
               InkWell(
                 onTap: () {
                   Navigator.push(context, MaterialPageRoute(builder: (context) {
                     return Login_Screen();
                   },));
                 },
                 child:Text("Sign in",style: TextStyle(fontSize: 17,color:Color(0xfffa7914),fontFamily: 'FontsFree',),),),
              Container(
                height:41,
                width: double.infinity,
                decoration: BoxDecoration(image: DecorationImage(image: AssetImage("images/Layer 7.png"),fit: BoxFit.fill)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
