import 'package:flutter/material.dart';

class demo extends StatefulWidget {
  const demo(String text, {Key? key}) : super(key: key);

  @override
  State<demo> createState() => _demoState();
}

class _demoState extends State<demo> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body:Column(
        children: [
          ListView.builder(itemBuilder: (context, index) {
            return ListTile(
              title: Text(""),
              subtitle: Text(""),
            );
          },)
        ],
      ),
    );
  }
}
