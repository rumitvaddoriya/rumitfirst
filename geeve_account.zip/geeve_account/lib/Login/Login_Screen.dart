import 'package:flutter/material.dart';
import 'package:geeve_account/Signup/Signup_Screen.dart';
import 'package:geeve_account/Splash/Splash_Screen.dart';
import 'package:geeve_account/model.dart';

class Login_Screen extends StatefulWidget {
  const Login_Screen({Key? key}) : super(key: key);

  @override
  State<Login_Screen> createState() => _Login_ScreenState();
}

class _Login_ScreenState extends State<Login_Screen> {

  TextEditingController emailcontroller = TextEditingController();
  TextEditingController passwordcontroller = TextEditingController();

  GlobalKey<FormState> formkey = GlobalKey<FormState>();
  bool passToggle = true;
  String password = "";
  bool name = false;
  bool pass = false;
  bool pass2 = false;
  int i = 0;


  login  (){
   // listdataa.add(listdataa);
    for(int i=0; i< listdata.length; i++){
      print("-----------> ${listdata.length}");
      print("-----------> ${listdata[i].email}");
      print("-----------> ${listdata[i].password}");
      print("Ok");
      //   }
      if(listdata[i].email==emailcontroller.text && listdata[i].password==passwordcontroller.text){
        Navigator.push(context, MaterialPageRoute(builder: (context) => Splash_Screen(),));
        emailcontroller.clear();
        passwordcontroller.clear();
      }
      else
        {
          //ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Enter Please match data")));
        }
    }

  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor:Color(0xFFffffff),
      body: SingleChildScrollView(
        child: Form(
          key: formkey,
          child: Column(
            children: [
              Center(child: SizedBox(height: 80,)),
              Container(
                height: 70,
                width: 150,
                decoration: BoxDecoration(image: DecorationImage(image: AssetImage("images/Layer 8.png"),fit: BoxFit.fill)),
              ),
              SizedBox(height: 50,),
              Padding(
                padding:  EdgeInsets.only(left: 45,right: 45),
                child: TextFormField(
                  controller:emailcontroller,
                  style: TextStyle(
                    fontSize: 15,
                    fontFamily: 'FontsFree',color: Colors.black),
                  decoration: InputDecoration(
                    border: InputBorder.none,
                    hintText: "Email",
                    filled: true,
                    prefixIcon: Icon(Icons.email_outlined,color:Colors.grey,),
                    fillColor: Color(0xfff6f6f6),
                    enabledBorder: OutlineInputBorder(
                      borderSide:
                      BorderSide(color: Color(0xfff6f6f6)),
                      borderRadius: BorderRadius.circular(50),
                    ),
                  ),
                  validator:(value) {
                    bool emailvalid = RegExp(r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`  {|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+").hasMatch(value!);
                    if(value!.isEmpty)
                    {
                      return 'Enter Email';
                    }else if(!emailvalid){
                       return "Enter Valid email";
                     }
                  },
                ),
              ),
             //  // Container(
             //  //   height:50,
             //  //   width: 270,
             //  //   decoration: BoxDecoration(color: Color(0xfff6f6f6),borderRadius: BorderRadius.all(Radius.circular(50))),
             //  // child: Padding(
             //  //   padding:  EdgeInsets.all(9),
             //  //   child: Center(
             //  //     child: TextFormField(
             //  //       style: TextStyle( color: Color(0xff7d7f86),
             //  //         fontSize: 15,
             //  //         fontFamily: 'FontsFree',),
             //  //       controller: firstnamecontroller,
             //  //       decoration: InputDecoration(
             //  //         border: InputBorder.none,
             //  //         hintText: "First Name",
             //  //         prefixIcon: Icon(Icons.email_outlined,color:Colors.grey,),
             //  //       ),
             //  //     ),
             //  //   ),
             //  // ),
             //  // ),
             // SizedBox(height: 3,),
             // name == true ? Padding(
             //   padding:EdgeInsets.only(right: 150),
             //   child: Text("Enter Please Name",style: TextStyle(color: Colors.red,fontSize: 12),),
             // ) : SizedBox(),
             //  SizedBox(height: 15,),
             //  Container(
             //    height:50,
             //    width: 270,
             //    decoration: BoxDecoration(color: Color(0xfff6f6f6),borderRadius: BorderRadius.all(Radius.circular(50))),
             //    child: Padding(
             //      padding:  EdgeInsets.all(9),
             //      child: Center(
             //        child: TextFormField(
             //          style: TextStyle( color: Color(0xff7d7f86),
             //            fontSize: 15,
             //            fontFamily: 'FontsFree',),
             //          controller: Passwordcontroller,
             //          decoration: InputDecoration(
             //            border: InputBorder.none,
             //            hintText: "Password",
             //            prefixIcon:Padding(padding:EdgeInsets.all(12),child:Image.asset("images/Layer 13.png",fit: BoxFit.fill,color: Colors.grey,filterQuality: FilterQuality.high,),)
             //          ),
             //          // validator: (value) {
             //          //   if(value == null || value.isEmpty)
             //          //   {
             //          //     return 'Please Enter Password';
             //          //   }else if(value.length <= 6)
             //          //   {
             //          //     return 'At Least 6 char required';
             //          //   }
             //          //   return null;
             //          // },
             //        ),
             //      ),
             //    ),
             //  ),
             //
             //
             //
             //  SizedBox(height: 3,),
             //  pass == true ? Padding(
             //    padding:EdgeInsets.only(right: 130),
             //    child: Text("Enter Please password",style: TextStyle(color: Colors.red,fontSize: 12),),
             //  ) : SizedBox()
              SizedBox(height:15,),
              Padding(
                padding:  EdgeInsets.only(left: 45,right: 45),
                child: TextFormField(
                  keyboardType: TextInputType.number,
                  controller:passwordcontroller,
                  style: TextStyle(
                    fontSize: 15,
                    fontFamily: 'FontsFree',color: Colors.black),
                  decoration: InputDecoration(
                    border: InputBorder.none,
                    hintText: "Password",
                    filled: true,
                    prefixIcon: Icon(Icons.key,color:Colors.grey,),
                    fillColor: Color(0xfff6f6f6),
                    enabledBorder: OutlineInputBorder(
                      borderSide:
                      BorderSide(color: Color(0xfff6f6f6)),
                      borderRadius: BorderRadius.circular(50),
                    ),
                  ),
                  validator: (value){
                    if(value == null || value.isEmpty)
                    {
                      return 'Please Enter Password';
                    }else if(value.length < 6)
                    {
                      return 'At Least 6 char required';
                    }
                    return null;
                  },
                ),
              ),
              SizedBox(height: 20,),
              Row(
                children: [
                  Container(
                     margin: EdgeInsets.only(left: 50),
                    height: 30,
                    width: 30,
                    decoration: BoxDecoration(color: Color(0xfff6f6f6),borderRadius: BorderRadius.all(Radius.circular(10))),
                  ),
                  SizedBox(width: 15,),
                  Text("Remember me",style: TextStyle(fontSize: 15,color: Color(0xff7d7f86),fontFamily: 'FontsFree',),),
                ],
              ),
              SizedBox(height: 25,),
              GestureDetector(
                onTap: () {
                  if(formkey.currentState!.validate()){
                    login();
                  }else{
                    print("Error");
                  }
                 // setState(() {
                 //   if(firstnamecontroller.text.isEmpty) {
                 //     name = true;
                 //     debugPrint("validation for user name$name");
                 //   }else if(Passwordcontroller.text.isEmpty){
                 //     pass = true;
                 //     debugPrint("validation for user name$pass");
                 //   }else if(Passwordcontroller.text.length <= 6){
                 //     pass2 = true;
                 //   }
                 //   if(name==true && pass==true){
                 //     Navigator.push(context, MaterialPageRoute(builder: (context) {
                 //       return Signup_Screen();
                 //     },));
                 //   }else{
                 //
                 //   }
                 //
                 // });
                },
                child: Container(
                  height: 50,
                  width: 270,
                  child: Center(child: Text("Login",style: TextStyle(fontSize: 20,color: Colors.white),),),
                  decoration: BoxDecoration(color: Color(0xfffa7914),borderRadius: BorderRadius.all(Radius.circular(50),),boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.40),blurRadius:5,offset: const Offset(1, 0)),]),
                ),
              ),
             SizedBox(height: 20,),
             Row(
               mainAxisAlignment: MainAxisAlignment.end,
               children: [
                 Icon(Icons.lock,color: Color(0xfffa7914),size: 15,),
                 SizedBox(width: 5,),
                 Padding(
                   padding:EdgeInsets.only(right:40),
                   child: Text("Forget Password?",style: TextStyle(fontSize: 13,color:Color(0xfffa7914),),),
                 )
               ],
             ),
             SizedBox(height: 50  ,),
             Text("Don't have an account?",style: TextStyle(fontSize: 13,color: Color(0xff7d7f86),fontFamily: 'FontsFree',),),
              SizedBox(height: 10,),
              InkWell(
                onTap: () {
                    Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) {
                      return Signup_Screen();
                    },));
                },
                child:Text("Sign Up",style: TextStyle(fontSize: 16,color:Color(0xfffa7914),fontFamily: 'FontsFree',),),),
              Container(
                height:108,
                width: double.infinity,
                decoration: BoxDecoration(image: DecorationImage(image: AssetImage("images/Layer 7.png"),fit: BoxFit.fill)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
