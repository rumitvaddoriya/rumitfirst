package com.example.geeve_account

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
