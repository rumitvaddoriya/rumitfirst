import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_facebook_auth/flutter_facebook_auth.dart';
import 'package:google_sign_firebase/email_password_loginscreen.dart';
import 'package:google_sign_firebase/email_password_sighup.dart';
import 'package:google_sign_firebase/phone_authontication.dart';
import 'package:google_sign_in/google_sign_in.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MaterialApp(home: Google_sign(),));
}

class Google_sign extends StatefulWidget {
  const Google_sign({Key? key}) : super(key: key);

  @override
  State<Google_sign> createState() => _Google_signState();
}

class _Google_signState extends State<Google_sign> {

  final FirebaseAuth _firebaseAuth = FirebaseAuth.instance;
  final Google_sign _googlesign = Google_sign();


  @override
  Widget build(BuildContext context) {
    return Scaffold(
          appBar: AppBar(title: Text("Authontication"),),
      body: Column(
        children: [
          SizedBox(height: 50,),
          Center(
            child: ElevatedButton(onPressed: () async{
              await signInWithGoogle();
            }, child: Text("Google_Sign")),
          ),
          SizedBox(height: 10,),
          Center(
            child: ElevatedButton(onPressed: () async{
                Navigator.push(context, MaterialPageRoute(builder: (context) => sighnup(),));
            }, child: Text("email Signup")),
          ),
          SizedBox(height: 10,),
          Center(
            child: ElevatedButton(onPressed: () async{
              Navigator.push(context, MaterialPageRoute(builder: (context) => login_screen(),));
            }, child: Text("email login")),
          ),
          SizedBox(height: 10,),
          Center(
            child: ElevatedButton(onPressed: () async{
              Navigator.push(context, MaterialPageRoute(builder: (context) => phone_otp(),));
            }, child: Text("phone otp")),
          ),
          SizedBox(height: 10,),
          Center(
            child: ElevatedButton(onPressed: () async{
              signInWithFacebook(context);
              //Navigator.push(context, MaterialPageRoute(builder: (context) => phone_otp(),));
            }, child: Text("Feshbook Login")),
          ),
        ],
      ),
    );
  }

  Future<void> signInWithGoogle() async {
    // Trigger the authentication flow
    final GoogleSignInAccount? googleUser = await GoogleSignIn().signIn();

    // Obtain the auth details from the request
    final GoogleSignInAuthentication? googleAuth = await googleUser?.authentication;

    if(googleAuth!.accessToken != null && googleAuth.idToken != null)
      {
        // Create a new credential
        final credential = GoogleAuthProvider.credential(
          accessToken: googleAuth?.accessToken,
          idToken: googleAuth?.idToken,
        );
         await FirebaseAuth.instance.signInWithCredential(credential);
      }
    // Once signed in, return the UserCredential

  }

  Future<void> signInWithFacebook(BuildContext context) async {
    try {
      final LoginResult loginResult = await FacebookAuth.instance.login();//------>instance ne login result name na variable ma store krYO

      final OAuthCredential facebookAuthCredential =
      FacebookAuthProvider.credential(loginResult.accessToken!.token);//------->TOKEN API SIGN IN

      await _firebaseAuth.signInWithCredential(facebookAuthCredential);

    } on FirebaseAuthException catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("sorry not success"))); // ------------->Displaying the error message
    }
  }


}
