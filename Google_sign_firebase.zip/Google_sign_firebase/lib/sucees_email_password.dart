import 'package:flutter/material.dart';
import 'package:google_sign_firebase/main.dart';

class success extends StatefulWidget {
  const success({Key? key}) : super(key: key);

  @override
  State<success> createState() => _successState();
}

class _successState extends State<success> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Welcome"),),
      body: Column(
        children: [
          Center(
            child: Text("signup",style: TextStyle(fontSize: 25),),
          ),
          Center(
            child: ElevatedButton(onPressed: () {
              Navigator.push(context, MaterialPageRoute(builder: (context) => Google_sign(),));
            }, child: Text("home Screen"))
          ),
        ],
      ),
    );
  }
}
