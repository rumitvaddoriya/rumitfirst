import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_sign_firebase/sucees_email_password.dart';

class login_screen extends StatefulWidget {
  const login_screen({Key? key}) : super(key: key);

  @override
  State<login_screen> createState() => _login_screenState();
}

class _login_screenState extends State<login_screen> {

  String email = "";
  String password = "";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Signup Screen"),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: 50,),
            TextField(
              onChanged: (value) {
                email = value;
              },
              decoration: InputDecoration(
                labelText: "Email",
                border:OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 20,),
            TextField(
              onChanged: (value) {
                password = value;
              },
              decoration: InputDecoration(
                labelText: "password",
                border:OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 30,),
            Center(
              child: ElevatedButton(onPressed: () async {
                try {
                  UserCredential credential = await FirebaseAuth.instance.signInWithEmailAndPassword(
                      email: email,
                      password: password
                  );
                  Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => success(),));
                } on FirebaseAuthException catch (e) {
                  if (e.code == 'user-not-found') {
                    showDialog(context: context, builder:  (context) {
                      return AlertDialog(title: Text("No user found for that email."),);
                    },);
                    print('No user found for that email.');
                  } else if (e.code == 'wrong-password') {
                           showDialog(context: context, builder:  (context) {
                            return AlertDialog(title: Text("Wrong password provided for that user."),);
                          },);
                    print('Wrong password provided for that user.');
                  }
                }
              }, child: Text("Signup")),
            )
          ],
        ),
      ),
    );
  }
}
