import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_sign_firebase/sucees_email_password.dart';

class sighnup extends StatefulWidget {
  const sighnup({Key? key}) : super(key: key);

  @override
  State<sighnup> createState() => _sighnupState();
}

class _sighnupState extends State<sighnup> {

  String email = "";
  String password = "";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Signup Screen"),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: 50,),
            TextField(
              onChanged: (value) {
                email = value;
              },
              decoration: InputDecoration(
                labelText: "Email",
                  border:OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 20,),
            TextField(
              onChanged: (value) {
                password = value;
              },
              decoration: InputDecoration(
                labelText: "password",
                border:OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 30,),
            Center(
              child: ElevatedButton(onPressed: () async {
                try {
                  UserCredential credential = await FirebaseAuth.instance.createUserWithEmailAndPassword(
                    email: email,
                    password: password,
                  );
                  Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => success(),));
                } on FirebaseAuthException catch (e) {
                  if (e.code == 'weak-password') {
                    showDialog(context: context, builder:  (context) {
                      return AlertDialog(title: Text("The password provided is too weak."),);
                    },);
                    print('The password provided is too weak.');
                  } else if (e.code == 'email-already-in-use') {
                    showDialog(context: context, builder:  (context) {
                      return AlertDialog(title: Text("he account already exists for that email."),);
                    },);
                    print('The account already exists for that email.');
                  }
                } catch (e) {
                  print(e);
                }
              }, child: Text("Signup")),
            )
          ],
        ),
      ),
    );
  }
}
