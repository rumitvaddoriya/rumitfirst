import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_otp_text_field/flutter_otp_text_field.dart';
import 'package:google_sign_firebase/main.dart';

class phone_otp extends StatefulWidget {
  const phone_otp({Key? key}) : super(key: key);

  @override
  State<phone_otp> createState() => _phone_otpState();
}

class _phone_otpState extends State<phone_otp> {

  FirebaseAuth auth = FirebaseAuth.instance;
  TextEditingController phoneNom = TextEditingController();
  String ?id;


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("phone Otp"),),
      body: Column(
        children: [
          SizedBox(height: 50,),
          TextField(
           controller: phoneNom,
            keyboardType: TextInputType.number,
            decoration: InputDecoration(
              labelText: "Enter Otp",
                border: OutlineInputBorder()
            ),
          ),
          SizedBox(height: 20,),
          Center(
            child: ElevatedButton(onPressed: () async {
              await FirebaseAuth.instance.verifyPhoneNumber(
                phoneNumber: '+91${phoneNom.text}',
                verificationCompleted: (PhoneAuthCredential credential) async {
                  await auth.signInWithCredential(credential);
                },
                verificationFailed: (FirebaseAuthException e) {
                  if (e.code == 'invalid-phone-number') {
                    print('The provided phone number is not valid.');
                  }
                },
                codeSent: (String verificationId, int? resendToken) {
                  id=verificationId;
                },
                codeAutoRetrievalTimeout: (String verificationId) {},
              );
            }, child: Text("otp")),
          ),
          SizedBox(height: 20,),
          OtpTextField(
            numberOfFields: 6,
            borderColor: Color(0xFF512DA8),
            //set to true to show as box or false to show as dash
            showFieldAsBox: true,
            //runs when a code is typed in
            onCodeChanged: (String code) {
              //handle validation or checks here
            },
            //runs when every textfield is filled
            onSubmit: (String verificationCode) async {
              String smsCode = verificationCode;

              // Create a PhoneAuthCredential with the code
              PhoneAuthCredential credential = PhoneAuthProvider.credential(verificationId: id!, smsCode: smsCode);

              // Sign the user in (or link) with the credential
              await auth.signInWithCredential(credential).then((value) {
                if(value!=null)
                {
                  Duration(seconds: 3);
                  Navigator.push(context, MaterialPageRoute(builder: (context) {
                    return Google_sign();
                  },));
                }
              });
            }, // end onSubmit
          ),

        ],
      ),
    );
  }
}
