import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:shared_prefrence_geeve_account/model/model.dart';
import 'package:shared_prefrence_geeve_account/suggations/Suggetions_screen.dart';

class Signup_Screen extends StatefulWidget {
  // final int? index;
  // Signup_Screen(this.index);
 const Signup_Screen({Key? key}) : super(key: key);

  @override
  State<Signup_Screen> createState() => _Signup_ScreenState();
}

class _Signup_ScreenState extends State<Signup_Screen> {

  TextEditingController fnamecontroller = TextEditingController();
  TextEditingController lnamecontroller = TextEditingController();
  TextEditingController phonecontroller = TextEditingController();
  TextEditingController emailcontroller = TextEditingController();
  TextEditingController passwordcontroller = TextEditingController();
  TextEditingController cpasswordcontroller = TextEditingController();
  GlobalKey<FormState> formkey = GlobalKey<FormState>();
  var data = [];
  bool value = false;
  bool emailvalue = true;


  @override
  void initState(){
    super.initState();
    getdata();
  }

  getdata() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    data = jsonDecode((await prefs.getString('action')) ?? '');
    print("----------->${data}");
  }

  setdata() async {
    if(formkey.currentState!.validate()){
      // Obtain shared preferences.
      SharedPreferences prefs = await SharedPreferences.getInstance();
      // Save an String value to 'action' key.
      //         emailvalue = true;
      //         for(int i=0; i< listdata.length; i++)
      //         {
      //           print("--------->${listdata.first.email}");
      //           if(listdata[i].email == emailcontroller.text){
      //             emailvalue = false;
      //             break;
      //           }else
      //           {
      //             print("No");
      //           }
      //         }
      listdata.add(
          User(
              firstname: fnamecontroller.text,
              lastname: lnamecontroller.text,
              phone: int.parse(phonecontroller.text),
              email: emailcontroller.text,
              password:passwordcontroller.text,
              confirmpassword: cpasswordcontroller.text
          )
      );
      if(listdata.length != 0){
        if(passwordcontroller.text == cpasswordcontroller.text){
          data.add(listdata);
          prefs.clear();
          await prefs.setString('action',listdata.toString());
          String name = "";
          name = await prefs.getString('action')!;
          print("------------->${name}");
          _dialogBuilder(context);
          Future.delayed(Duration(seconds: 5), () {
            Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) {
              return Suggetions_screen();
                },));
          });
        }else{
          showDialog(context: context, builder: (context) {
                return AlertDialog(
                    title: Text("Password is not Matched"),
                );
            },);
        }
      }else{
        print("not");
      }
    }else{
      print("Error");
    }
  }

  decode() async {
    // Obtain shared preferences.
    final prefs =await SharedPreferences.getInstance();
    // Save an String value to 'action' key.
    prefs.getStringList('action');
    print("------------->${jsonDecode(listdata.first.firstname.toString())}");
  }


  // @override
  // void initState() {
  //   if(widget.index != null)
  //     {
  //       fnamecontroller.text = listdata[widget.index!].firstname!;
  //       lnamecontroller.text = listdata[widget.index!].lastname!;
  //       phonecontroller.text = listdata[widget.index!].phone!.toString();
  //       emailcontroller.text = listdata[widget.index!].email!;
  //     }else{
  //         print("faild data");
  //   }
  // }


  //  datadd(context) async {
  //   if(formkey.currentState!.validate() ){
  //     if(value == true)
  //       {
  //         emailvalue = true;
  //         for(int i=0; i< listdata.length; i++)
  //         {
  //           print("--------->${listdata.first.email}");
  //           if(listdata[i].email == emailcontroller.text){
  //             emailvalue = false;
  //             break;
  //           }else
  //           {
  //             print("No");
  //           }
  //         }
  //         if(emailvalue){
  //           //print("------------> ${listdata.first.password}");
  //           listdata.add(
  //             User(
  //                 firstname: fnamecontroller.text,
  //                 lastname: lnamecontroller.text,
  //                 phone: int.parse(phonecontroller.text),
  //                 email: emailcontroller.text,
  //                 password:passwordcontroller.text,
  //                 confirmpassword: cpasswordcontroller.text
  //             ),
  //           );
  //           if(passwordcontroller.text == cpasswordcontroller.text){
  //             _dialogBuilder(context);
  //             Future.delayed(Duration(seconds: 5), () {
  //               Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) {
  //                 return Login_Screen();
  //               },));
  //             });
  //           }else{
  //             showDialog(context: context, builder: (context) {
  //               return AlertDialog(
  //                 title: Text("Password is not Matched"),
  //               );
  //             },);
  //           }
  //         }else{
  //           showDialog(context: context, builder: (context) {
  //             return AlertDialog(
  //               title: Text("Email is Alerdy used"),
  //             );
  //           },);
  //         }
  //       }else{
  //       ScaffoldMessenger.of(context).showSnackBar(SnackBar(duration: Duration(seconds: 2), content: Text("Please Accept Term And condition")));
  //     }
  //   }else{
  //     print("Error");
  //   }
  // }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor:Color(0xFFffffff),
      body: SingleChildScrollView(
        child: Form(
          key: formkey,
          child: Column(
            children: [
              Center(child: SizedBox(height: 60,)),
              Container(
                height: 70,
                width: 150,
                decoration: BoxDecoration(image: DecorationImage(image: AssetImage("images/Layer 8.png"),fit: BoxFit.fill)),
              ),
              SizedBox(height: 20,),
              Padding(
                padding:  EdgeInsets.only(left: 45,right: 45),
                child: TextFormField(
                  controller:fnamecontroller,
                  style: TextStyle(
                      fontSize: 15,
                      fontFamily: 'FontsFree',color: Colors.black),
                  decoration: InputDecoration(
                    border: InputBorder.none,
                    hintText: "First Name",
                    filled: true,
                    fillColor: Color(0xfff6f6f6),
                    enabledBorder: OutlineInputBorder(
                      borderSide:
                      BorderSide(color: Color(0xfff6f6f6)),
                      borderRadius: BorderRadius.circular(50),
                    ),
                  ),
                  validator:(value) {
                    if(value!.isEmpty)
                    {
                      return 'Enter First Name';
                    }
                  },
                ),
              ),
              SizedBox(height: 10,),
              Padding(
                padding:  EdgeInsets.only(left: 45,right: 45),
                child: TextFormField(
                  controller:lnamecontroller,
                  style: TextStyle(
                      fontSize: 15,
                      fontFamily: 'FontsFree',color: Colors.black),
                  decoration: InputDecoration(
                    border: InputBorder.none,
                    hintText: "Last Name",
                    filled: true,
                    fillColor: Color(0xfff6f6f6),
                    enabledBorder: OutlineInputBorder(
                      borderSide:
                      BorderSide(color: Color(0xfff6f6f6)),
                      borderRadius: BorderRadius.circular(50),
                    ),
                  ),
                  validator:(value) {
                    if(value!.isEmpty)
                    {
                      return 'Enter Last Name';
                    }
                  },
                ),
              ),
              SizedBox(height: 10,),
              Padding(
                padding:  EdgeInsets.only(left: 45,right: 45),
                child: TextFormField(
                  controller:phonecontroller,
                  style: TextStyle(
                      fontSize: 15,
                      fontFamily: 'FontsFree',color: Colors.black),
                  decoration: InputDecoration(
                    border: InputBorder.none,
                    hintText: "Phone",
                    filled: true,
                    fillColor: Color(0xfff6f6f6),
                    enabledBorder: OutlineInputBorder(
                      borderSide:
                      BorderSide(color: Color(0xfff6f6f6)),
                      borderRadius: BorderRadius.circular(50),
                    ),
                  ),
                  validator: (value){
                    if(value == null || value.isEmpty)
                    {
                      return 'Please Enter Password';
                    }else if(value.length < 10)
                    {
                      return 'At Least 10 char required';
                    }
                    return null;
                  },
                ),
              ),
              SizedBox(height: 10,),
              Padding(
                padding:  EdgeInsets.only(left: 45,right: 45),
                child: TextFormField(
                  //enabled: widget.index == null ? true : false,
                  controller:emailcontroller,
                  style: TextStyle(
                      fontSize: 15,
                      fontFamily: 'FontsFree',color: Colors.black),
                  decoration: InputDecoration(
                    border: InputBorder.none,
                    hintText: "Email",
                    filled: true,
                    fillColor: Color(0xfff6f6f6),
                    enabledBorder: OutlineInputBorder(
                      borderSide:
                      BorderSide(color: Color(0xfff6f6f6)),
                      borderRadius: BorderRadius.circular(50),
                    ),
                  ),
                  validator:(value) {
                    bool emailvalid = RegExp(r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`  {|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+").hasMatch(value!);
                    if(value!.isEmpty)
                    {
                      return 'Enter Email';
                    }else if(!emailvalid){
                      return "Enter Valid email";
                    }
                  },
                ),
              ),
              SizedBox(height: 10,),
              Padding(
                padding:  EdgeInsets.only(left: 45,right: 45),
                child: TextFormField(
                  keyboardType: TextInputType.number,
                  controller:passwordcontroller,
                  style: TextStyle(
                      fontSize: 15,
                      fontFamily: 'FontsFree',color: Colors.black),
                  decoration: InputDecoration(
                    border: InputBorder.none,
                    hintText: "Password",
                    filled: true,
                    fillColor: Color(0xfff6f6f6),
                    enabledBorder: OutlineInputBorder(
                      borderSide:
                      BorderSide(color: Color(0xfff6f6f6)),
                      borderRadius: BorderRadius.circular(50),
                    ),
                  ),
                  validator: (value){
                    if(value == null || value.isEmpty)
                    {
                      return 'Please Enter Password';
                    }else if(value.length < 6)
                    {
                      return 'At Least 6 char required';
                    }
                    return null;
                  },
                ),
              ),
              SizedBox(height: 10,),
              Padding(
                padding:  EdgeInsets.only(left: 45,right: 45),
                child: TextFormField(
                  keyboardType: TextInputType.number,
                  controller:cpasswordcontroller,
                  style: TextStyle(
                      fontSize: 15,
                      fontFamily: 'FontsFree',color: Colors.black),
                  decoration: InputDecoration(
                    border: InputBorder.none,
                    hintText: "Confirm Password",
                    filled: true,
                    fillColor: Color(0xfff6f6f6),
                    enabledBorder: OutlineInputBorder(
                      borderSide:
                      BorderSide(color: Color(0xfff6f6f6)),
                      borderRadius: BorderRadius.circular(50),
                    ),
                  ),
                  validator: (value){
                    if(value == null || value.isEmpty)
                    {
                      return 'Please Enter Password';
                    }else if(value.length < 6)
                    {
                      return 'At Least 6 char required';
                    }
                    return null;
                  },
                ),
              ),
              SizedBox(height: 20,),
              Row(
                children: [
                  GestureDetector(
                    onTap: () {
                      setState(() {
                        this.value = !this.value;
                        print(value);
                      });
                    },
                    child: Padding(
                      padding: EdgeInsets.only(left: 50),
                      child:value ? Container(
                        height:20,
                        width:20,
                        child: Icon(Icons.check,color: Colors.green,),
                        decoration: BoxDecoration(color: Color(0xfff6f6f6),borderRadius: BorderRadius.all(Radius.circular(5))),
                      )
                      : Container(
                        height:20,
                        width:20,
                        decoration: BoxDecoration(color: Color(0xfff6f6f6),borderRadius: BorderRadius.all(Radius.circular(5))),
                      )
                    ),
                  ),
                  SizedBox(width:10,),
                  Text("I agree to the geeve ",style: TextStyle(fontSize: 13, fontFamily: 'FontsFree', color: Color(0xff7d7f86),),),
                  Text("Terms and Conditions",style: TextStyle(fontSize: 13,color: Color(0xfffa7914),),),
                ],
              ),
              SizedBox(height: 25,),
              GestureDetector(
                onTap: () {
                  setdata();
                  // if(widget.index == null){
                  //   datadd(context);
                  // }else{
                  //   listdata[widget.index!].firstname = fnamecontroller.text;
                  //   listdata[widget.index!].lastname = lnamecontroller.text;
                  //   listdata[widget.index!].phone = int.parse(phonecontroller.text);
                  //   listdata[widget.index!].email = emailcontroller.text;
                  //
                  //   print("-------------->${listdata[widget.index!].firstname}");
                  //
                  //   if(passwordcontroller.text.isEmpty && cpasswordcontroller.text.isEmpty){
                  //       showDialog(context: context, builder: (context) {
                  //         return AlertDialog(
                  //           title: Text("Enter password"),
                  //         );
                  //       },);
                  //   }else{
                  //     Navigator.push(context, MaterialPageRoute(builder: (context) {
                  //       return Suggetions_screen();
                  //     },));
                  //   }
                  // }
                },
                child: Container(
                  height: 50,
                  width: 270,
                  child: Center(
                    child:Text(
                      "Sign up",
                      style: TextStyle(
                          fontSize: 16,
                          fontFamily: 'FontsFree',
                          color: Colors.white
                      ),
                    )
                  ),
                  decoration: BoxDecoration(color: Color(0xfffa7914),borderRadius: BorderRadius.all(Radius.circular(50),),boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.40),blurRadius:5,offset: const Offset(1, 0)),]),
                ),
              ),
              SizedBox(height: 30,),
              Text("Don't have an account?",style: TextStyle(fontSize: 14, color: Color(0xff7d7f86),fontFamily: 'FontsFree',),),
               SizedBox(height: 5,),
               InkWell(
                 // onTap: () {
                 //   Navigator.push(context, MaterialPageRoute(builder: (context) {
                 //     return Login_Screen();
                 //   },));
                 // },
                 child:Text("Sign in",style: TextStyle(fontSize: 17,color:Color(0xfffa7914),fontFamily: 'FontsFree',),),),
              Container(
                height:41,
                width: double.infinity,
                decoration: BoxDecoration(image: DecorationImage(image: AssetImage("images/Layer 7.png"),fit: BoxFit.fill)),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _dialogBuilder(BuildContext context) {
    return showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          actions: [
            SingleChildScrollView(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    height: 400,
                    width: 300,
                    decoration: BoxDecoration(color:  Color(0xFFffffff),borderRadius: BorderRadius.all(Radius.circular(40))),
                    child: Column(
                      children: [
                        const Center(child: SizedBox(height: 20,),),
                        Container(
                          height: 150,
                          width: 200,
                          child: Image.asset("images/Layer 23.png",fit: BoxFit.fill,),
                        ),
                        SizedBox(height: 15,),
                        Text("Congraulation",style: TextStyle(fontSize: 20,color:Color(0xfffa7914),fontFamily: 'FontsFree',),),
                        SizedBox(height: 10,),
                        Text("Now you are registred",style: TextStyle(fontSize: 22,fontFamily: 'FontsFree',fontWeight: FontWeight.bold),),
                        SizedBox(height: 10,),
                        Text("Getready with geeve",style: TextStyle(fontSize: 15,color: Color(0xff7d7f86),fontFamily: 'FontsFree',),),
                        SizedBox(height: 20,),
                        Container(
                          margin: EdgeInsets.all(20),
                          height: 50,
                          width: 250,
                          child: const Center(child: Text("Start Now",style: TextStyle(fontSize: 16,color: Colors.white,fontFamily: 'FontsFree',),),),
                          decoration: const BoxDecoration(color: Color(0xfffa7914),borderRadius: BorderRadius.all(Radius.circular(50),)),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        );
      },
    );
  }
}
