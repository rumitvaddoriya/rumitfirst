import 'package:flutter/material.dart';

import 'package:pinput/pinput.dart';

class phone_verifications extends StatefulWidget {
  const phone_verifications({Key? key}) : super(key: key);

  @override
  State<phone_verifications> createState() => _phone_verificationsState();
}

class _phone_verificationsState extends State<phone_verifications> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true,
      backgroundColor:const Color(0xFFffffff),
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(70),
        child:AppBar(
          backgroundColor:const Color(0xfffa7914),
          shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.only(
                bottomRight: Radius.circular(25),
                topLeft: Radius.circular(25),
                topRight: Radius.circular(25)),
          ),
          centerTitle: true,
          title:  Text("Verifications",style: TextStyle(fontSize: 20,fontFamily: 'FontsFree',),),
        ),
      ),
      body:SingleChildScrollView(
        child: Column(
          children: [
            const Center(child: SizedBox(height: 25,),),
            Container(
              height: MediaQuery.of(context).size.height * 0.4/2,
              width: MediaQuery.of(context).size.height * 0.25,
              child: Image.asset("images/Layer 21.png",fit: BoxFit.fill,),
            ),
             SizedBox(height: 20,),
             Text("We have sent SMS with a code the number below",style: TextStyle(fontSize: 13,),),
             Text("+12355645847",style: TextStyle(fontSize: 13),),
             SizedBox(height: 15,),
             Text("To Complate Phone Number Varifications",style: TextStyle(fontSize: 15,color: Color(0xff7d7f86),fontFamily: 'FontsFree',),),
             SizedBox(height: 30,),
            Pinput(
              length: 6,defaultPinTheme: defaultPinTheme,
              mainAxisAlignment: MainAxisAlignment.center,

            ),
             SizedBox(height: 40,),
            GestureDetector(
              onTap: () {
              _dialogBuilder(context);
              },
              child: Container(
                height: 50,
                width: 300,
                child: const Center(child: Text("Verify",style: TextStyle(fontSize: 17,color:Colors.white,fontFamily: 'FontsFree',),),),
                decoration:  BoxDecoration(color:Color(0xfffa7914),borderRadius: BorderRadius.all(Radius.circular(50),),boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.40),blurRadius:5,offset: const Offset(1, 0)),]),
              ),
            ),
             SizedBox(height:30,),
             Text("Resend code 0:30",style: TextStyle(color: Color(0xfffa7914),),),
             SizedBox(height:10,),
            Container(
              height:130,
              width: double.infinity,
              decoration: const BoxDecoration(image: DecorationImage(image: AssetImage("images/Layer 7.png"),fit: BoxFit.fill)),
            ),
          ],
        ),
      ),
    );
  }
  final defaultPinTheme = PinTheme(
    width: 40,
    height: 40,
    textStyle: const TextStyle(
      fontSize: 22,
      color: Color.fromRGBO(30, 60, 87, 1),
    ),
    decoration: BoxDecoration(
      color: Colors.black12,
      borderRadius: BorderRadius.circular(10),
    ),
  );
  Future<void> _dialogBuilder(BuildContext context) {
    return showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
         actions: [
          Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              height: 400,
              width: 300,
              decoration: BoxDecoration(color:  Color(0xFFffffff),borderRadius: BorderRadius.all(Radius.circular(40))),
              child: Column(
                children: [
                  const Center(child: SizedBox(height: 20,),),
                  Container(
                    height: 150,
                    width: 200,
                    child: Image.asset("images/Layer 23.png",fit: BoxFit.fill,),
                  ),
                   SizedBox(height: 20,),
                   Text("Congraulation",style: TextStyle(fontSize: 20,color:Color(0xfffa7914),fontFamily: 'FontsFree',),),
                   SizedBox(height: 15,),
                   Text("Now you are registred",style: TextStyle(fontSize: 22,fontFamily: 'FontsFree',fontWeight: FontWeight.bold),),
                   SizedBox(height: 10,),
                   Text("Getready with geeve",style: TextStyle(fontSize: 15,color: Color(0xff7d7f86),fontFamily: 'FontsFree',),),
                   SizedBox(height: 25,),
                  Container(
                    margin: EdgeInsets.all(20),
                    height: 50,
                    width: 250,
                    child: const Center(child: Text("Start Now",style: TextStyle(fontSize: 16,color: Colors.white,fontFamily: 'FontsFree',),),),
                    decoration: const BoxDecoration(color: Color(0xfffa7914),borderRadius: BorderRadius.all(Radius.circular(50),)),
                  ),
                ],
              ),
            ),
          ],
          ),
         ],
        );
      },
    );
  }
  }
