class User{
  String? firstname;
  String? lastname;
  int? phone;
  String? email;
  String? password;
  String? confirmpassword;

  User({ this.firstname, this.lastname,this.phone, this.email, this.password, this.confirmpassword});
}
List listdata =[];


