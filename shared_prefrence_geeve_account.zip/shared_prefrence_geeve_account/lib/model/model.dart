import 'dart:convert';

Useroflist useroflistFromJson(String str) => Useroflist.fromJson(json.decode(str));

String useroflistToJson(Useroflist data) => json.encode(data.toJson());

class Useroflist {
  Useroflist({
    this.listofmodel,
  });

  List<Listofmodel>? listofmodel;

  factory Useroflist.fromJson(Map<String, dynamic> json) => Useroflist(
    listofmodel: json["listofmodel"] == null ? [] : List<Listofmodel>.from(json["listofmodel"]!.map((x) => Listofmodel.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "listofmodel": listofmodel == null ? [] : List<dynamic>.from(listofmodel!.map((x) => x.toJson())),
  };
}

class Listofmodel {
  Listofmodel({
    this.firstname,
    this.lastname,
    this.phone,
    this.email,
    this.password,
    this.confirmpassword,
  });

  String? firstname;
  String? lastname;
  String? phone;
  String? email;
  String? password;
  String? confirmpassword;

  factory Listofmodel.fromJson(Map<String, dynamic> json) => Listofmodel(
    firstname: json["firstname"],
    lastname: json["lastname"],
    phone: json["phone"],
    email: json["email"],
    password: json["password"],
    confirmpassword: json["confirmpassword"],
  );

  Map<String, dynamic> toJson() => {
    "firstname": firstname,
    "lastname": lastname,
    "phone": phone,
    "email": email,
    "password": password,
    "confirmpassword": confirmpassword,
  };
}



// class User{
//   String? firstname;
//   String? lastname;
//   int? phone;
//   String? email;
//   String? password;
//   String? confirmpassword;
//
//   User({ this.firstname, this.lastname,this.phone, this.email, this.password, this.confirmpassword});
// }
// List<User> listdata =[];

