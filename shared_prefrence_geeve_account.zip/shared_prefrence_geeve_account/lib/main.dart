import 'package:flutter/material.dart';
import 'package:shared_prefrence_geeve_account/Signup/Signup_Screen.dart';

void main() async {
  runApp(
    MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Signup_Screen(),
    ),
  );
}
