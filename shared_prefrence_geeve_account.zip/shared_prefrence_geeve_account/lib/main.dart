import 'package:flutter/material.dart';
import 'package:shared_prefrence_geeve_account/Signup/Signup_Screen.dart';
import 'package:shared_prefrence_geeve_account/Splash/Splash_Screen.dart';

void main(){
  runApp(
    MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Signup_Screen(),
    ),
  );
}
