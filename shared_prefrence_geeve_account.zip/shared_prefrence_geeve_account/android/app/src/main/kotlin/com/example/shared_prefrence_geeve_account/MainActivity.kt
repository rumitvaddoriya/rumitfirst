package com.example.shared_prefrence_geeve_account

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
