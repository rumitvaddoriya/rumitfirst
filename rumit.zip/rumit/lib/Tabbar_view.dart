import 'package:flutter/material.dart';
import 'package:rumit/Form_validation.dart';
import 'package:rumit/Griadview_builder.dart';
import 'package:rumit/Home_Screen.dart';
import 'package:rumit/pageview_builder.dart';

class Tabbar extends StatefulWidget {
  const Tabbar({Key? key}) : super(key: key);

  @override
  State<Tabbar> createState() => _TabbarState();
}

class _TabbarState extends State<Tabbar> {

  List page =[
    Home_Screen(),
    Pageview_builder(),
    Form_validation(),
    MyApp(),
  ];

  int currenindex = 0;
  void onTap(int index){
    setState((  ) {
      currenindex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
       length: 3,
      child: Scaffold(
        appBar: AppBar(title: Text("TabBar",style: TextStyle(fontSize: 20,color: Colors.black,fontWeight:FontWeight.bold),),),
        body: Column(
          children: [
            TabBar(tabs: [
              Tab(

                icon: Icon(Icons.home,color: Colors.black,),
                child: Text("First"),
              ),
              Tab(
                icon: Icon(Icons.ac_unit_outlined,color: Colors.black,),
                child: Text("Second"),
              ),
              Tab(
                icon: Icon(Icons.access_alarm,color: Colors.black,),
                child: Text("Third"),
              ),
            ]),
            Expanded(
              child: TabBarView(
                  children: [
                    Container(
                      color: Colors.green,
                      child: Center(child: Text("First Tab"),),
                    ),
                    Container(
                      color: Colors.red,
                      child: Center(child: Text("Second Tab"),),
                    ),
                    Container(
                      color: Colors.blue,
                      child: Center(child: Text("Third Tab"),),
                    ),
                  ]
              ),
            )
          ],
        ),
        bottomNavigationBar: BottomNavigationBar(
          type: BottomNavigationBarType.shifting,
          backgroundColor: Colors.red,
          onTap: onTap,
          currentIndex: currenindex,
          selectedItemColor: Colors.black54,
            unselectedItemColor: Colors.grey,
            showSelectedLabels: false,
            showUnselectedLabels: false,
            elevation: 1,
            items: [
          BottomNavigationBarItem(label: "add",icon: Icon(Icons.add),),
          BottomNavigationBarItem(label: "unit",icon: Icon(Icons.ac_unit),),
          BottomNavigationBarItem(label: "yyy",icon: Icon(Icons.apple),),
          BottomNavigationBarItem(label: "add",icon: Icon(Icons.access_alarm_outlined),),
        ]),
      ),
    );
  }
}
