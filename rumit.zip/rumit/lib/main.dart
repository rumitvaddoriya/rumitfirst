import 'dart:io';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:rumit/Griadview_builder.dart';
import 'package:rumit/pageview_builder.dart';
import 'Form_validation.dart';
import 'Home_Screen.dart';
import 'Permissions_Handling.dart';
import 'Share_prefranse/Login_Screen.dart';
import 'Share_prefranse/Register_Screen.dart';
import 'Tabbar_view.dart';

void main(){
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitDown,]);

  if(Platform.isAndroid)
    {
      runApp(MaterialApp(
        theme: ThemeData.light(),
        debugShowCheckedModeBanner: false,
        initialRoute: 'seven',
        routes:{
          '/':(context) => Home_Screen(),
          'second':(context) => Form_validation(),
          'third':(context) => Pageview_builder(),
          'fourth':(context) => MyApp(),
          'fifth':(context) => Tabbar(),
          'six':(context) => Permissions_handling(),
          'seven':(context) => Share_Prefrense(),
          'eigth':(context) => Register_Screen(),
        },
      ),
      );
    }
  else if(Platform.isIOS)
    {
      runApp(MaterialApp(
        theme: ThemeData.dark(),
        debugShowCheckedModeBanner: false,
        initialRoute: 'six',
        routes:{
          '/':(context) => Home_Screen(),
          'second':(context) => Form_validation(),
          'third':(context) => Pageview_builder(),
          'fourth':(context) => MyApp(),
          'fifth':(context) => Tabbar(),
          'six':(context) => Permissions_handling(),
        },
      ),
      );
    }

}
