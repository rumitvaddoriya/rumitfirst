import 'package:flutter/material.dart';
import 'package:form_field_validator/form_field_validator.dart';

class Form_validation extends StatefulWidget {
  const Form_validation({Key? key}) : super(key: key);

  @override
  State<Form_validation> createState() => _Form_validationState();
}

class _Form_validationState extends State<Form_validation> {

  TextEditingController useremail = TextEditingController();
  TextEditingController userpassword = TextEditingController();

  GlobalKey<FormState> formkey = GlobalKey<FormState>();
  bool passToggle = true;


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("form Validations",style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),),),
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: 10,),
            Center(
              child: Container(
                height: 150,
                width: 150,
                decoration: BoxDecoration(image: DecorationImage(image: NetworkImage('https://static.vecteezy.com/system/resources/thumbnails/007/407/996/small/user-icon-person-icon-client-symbol-login-head-sign-icon-design-vector.jpg'),fit: BoxFit.fill)),
              ),
            ),
            SizedBox(height: 50,),
            Padding(
              padding:EdgeInsets.only(left: 15,right: 15),
              child:Form(
                key: formkey,
                  child:Column(
                    children: [
                      TextFormField(
                        controller: useremail,
                        decoration: InputDecoration(
                          labelText: "Email",
                          prefixIcon: Icon(Icons.email),
                          border: OutlineInputBorder()
                        ),
                         validator:(value) {
                           bool emailvalid = RegExp(r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`  {|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+").hasMatch(value!);

                           if(value.isEmpty)
                            {
                              return 'Enter Email';
                            }else if(!emailvalid){
                                  return "Enter Valid email";
                            }
                        },
                      ),
                      SizedBox(height: 20,),
                      TextFormField(
                        keyboardType: TextInputType.number ,
                        controller: userpassword,
                        obscureText: passToggle,
                        decoration: InputDecoration(
                            border: OutlineInputBorder(),
                            labelText: "Password",
                            prefixIcon: Icon(Icons.lock),
                            suffix: InkWell(
                              onTap: () {
                                setState(() {
                                  passToggle = !passToggle;
                                });
                              },
                              child: Icon(passToggle ? Icons.visibility : Icons.visibility_off),
                            ),
                        ),
                        validator: (value){
                          if(value == null || value.isEmpty)
                          {
                            return 'Please Enter Password';
                          }else if(value.length <= 6)
                          {
                            return 'At Least 6 char required';
                          }
                          return null;
                        },
                      ),
                      Padding(
                          padding:EdgeInsets.only(left: 15,right: 15,top: 10),
                        child:ElevatedButton(
                            onPressed: () {
                              if(formkey.currentState!.validate()){
                                useremail.clear();
                                userpassword.clear();
                                print("Ok");
                              }else{
                                print("Error");
                              }
                        }, child:Text("Login",style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),)),
                      ),
                    ],
                  )
              ),
            ),
          ],
        ),
      ),
    );
  }
}
