import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';

class Permissions_handling extends StatefulWidget {
  const Permissions_handling({Key? key}) : super(key: key);

  @override
  State<Permissions_handling> createState() => _Permissions_handlingState();
}

class _Permissions_handlingState extends State<Permissions_handling> {
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Permission"),),
      body: Column(
        children: [
          ListTile(
            leading: CircleAvatar(child: Icon(Icons.camera),),
            title: Text("camera permission"),
            onTap: () async {
              PermissionStatus camerastatus =await Permission.camera.request();
              if(camerastatus == PermissionStatus.granted)
              {
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Permission Ok")));
              }
              if(camerastatus == PermissionStatus.denied)
                {
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Permission is not succses")));
                }
              if(camerastatus == PermissionStatus.permanentlyDenied)
                {
                  openAppSettings();
                }
            },
          ),
        ],
      ),
    );
  }
}
