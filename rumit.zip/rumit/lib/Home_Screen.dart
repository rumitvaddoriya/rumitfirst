import 'package:flutter/material.dart';
import 'package:flutter_switch/flutter_switch.dart';
import 'package:rumit/Form_validation.dart';

class Home_Screen extends StatefulWidget {
  const Home_Screen({Key? key}) : super(key: key);

  @override
  State<Home_Screen> createState() => _Home_ScreenState();
}

class _Home_ScreenState extends State<Home_Screen> {

  int selectedRadioTile  = 0;
  double _value = 0;
  bool apple = false;
  bool banana = true;
  bool status1 = true;
  TextEditingController _username = TextEditingController();

  setSelectedRadioTile(int val) {
    setState(() {
      selectedRadioTile = val;
    });
  }

DateTime pickdate = DateTime.now();
  Selectdate(){
    showDatePicker(
      context: context,
        initialDate: DateTime.now(),
        firstDate: DateTime(2000),
        lastDate: DateTime(2025),
    ).then((value) =>{
      setState(() {
        pickdate = value!;
        print(pickdate);
      }),
    });
  }

  TimeOfDay pictime = TimeOfDay.now();
  SelectTime(){
    showTimePicker(
        context: context,
        initialTime: TimeOfDay.now(),
    ).then((value) => {
      setState((){
        pictime = value!;
      }),
    });
  }


  dynamic selectedIndex = 1;
  List _choicechipList =["Android", "Ios", "Python", "React",];

  List<String> _locations = ['A', 'B', 'C', 'D'];
  String? selecteditem;

  bool _isShow = true;
  String? selectedMenu;

  Future<dynamic> willpop(){
    return showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            title: Text("Do You alerdy Exit the app"),
            actions: [
              ElevatedButton(onPressed: () {
                Navigator.pop(context,true);
              }, child: Text("ok")),
              ElevatedButton(onPressed: () {
                Navigator.pop(context,false);
              }, child: Text("No")),
            ],
          );
        },
    );
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: ()async{
        final dialog = await showDialog(
          context: context,
          builder: (context) {
            return AlertDialog(
              title: Text("Do You alerdy Exit the app"),
              actions: [
                ElevatedButton(onPressed: () {
                  Navigator.pop(context,true);
                }, child: Text("ok")),
                ElevatedButton(onPressed: () {
                  Navigator.pop(context,false);
                }, child: Text("No")),
              ],
            );
          },);
        return dialog;
      },
      child: Scaffold(
        appBar: AppBar(
          title:Text("User Details"),
          actions: [
             IconButton(onPressed: () {
               Navigator.pushNamed(context, "second");
             }, icon: Icon(Icons.add)),
          ],
        ),
        body: SingleChildScrollView(
          child: Column(
            children: [
              SizedBox(height: 10,),
              TextFormField(
                controller: _username,
                decoration: InputDecoration(
                  focusColor: Colors.black,
                  prefixIcon: const Icon(
                    Icons.person_outline_rounded,
                    color: Colors.grey,
                  ),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius  .circular(10.0),
                  ),
                 errorText: "Enter username"
                ),
              ),
              SizedBox(height: 8,),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                 FlutterSwitch(
                    value: status1,
                    onToggle: (value) {
                      setState(() {
                        status1 = value;
                      });
                    },),
                  Expanded(
                    child: Container(
                      height: 50,
                      child: Text("${status1}"),
                    ),
                  ),
                ],
              ),
              RadioListTile(
               title: const Text('Name and Address'),
                value: 1,
                groupValue: selectedRadioTile,
                onChanged: (val) {
                setState(() {
                  selectedRadioTile = val!;
               });
              },
                activeColor: Colors.red,
                selected: true,
            ),
              RadioListTile(
                title: const Text('welcome'),
                value: 2,
                groupValue: selectedRadioTile,
                onChanged: (val) {
                  setState(() {
                    selectedRadioTile = val!;
                  });
                },
                activeColor: Colors.red,
                selected: false,
              ),
              CheckboxListTile(
                title:  Text('Apple'),
                  value: apple,
                  onChanged: (bool? value) {
                  setState(() {
                    apple = value!;
                  });
                    print(apple);
                  },
              ),
              CheckboxListTile(
                title:  Text('banana'),
                value: banana,
                onChanged: (bool? value) {
                 setState(() {
                   banana = value!;
                 });
                  print(banana);
                },
              ),
              Slider(
                min: 0,
                  max: 100,
                  value: _value,
                  onChanged: (value) {
                    setState(() {
                      _value = value;
                      print(_value);
                    });
                  },
              ),
              TextButton(
                  onPressed: () {
                final snakbar = SnackBar(content: Text("Hi I am snakBar"),
                  backgroundColor: Colors.amber,
                  action:SnackBarAction(
                    label: 'dismiss',
                      onPressed: () {},
                  ),
                );
                ScaffoldMessenger.of(context).showSnackBar(snakbar);
              }, child: Center(child: Text("Click Me Snackbar",style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold,color: Colors.black),)),
              ),
            ElevatedButton(onPressed: () {
              showDialog(context: context,builder:(context) {
                return  AlertDialog(
                  title: Text("I am Welcome"),
                  actions: [
                    ElevatedButton(onPressed: () {
                      Navigator.pop(context);
                    }, child: Text("Ok"))
                  ],
                );
              },
              );
            }, child: Text("showdialog")),
              SizedBox(height: 7,),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  InkWell(
                    onTap: () {
                      Selectdate();
                    },
                    child: Container(
                      height: 50,
                      width: 100,
                      child: Center(child: Text("Select Date")),
                    ),
                  ),
                  Container(
                    height: 50,
                    width: 100,
                    child:  Container(
                      height: 50,
                      width: 100,
                      child: Center(child: Text("${pickdate.toString()}")),
                    ),
                  ),
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  InkWell(
                    onTap: () {
                      SelectTime();
                    },
                    child: Container(
                      height: 50,
                      width: 100,
                      child: Center(child: Text("Select Time")),
                    ),
                  ),
                  Container(
                    height: 50,
                    width: 100,
                    child:  Container(
                      height: 50,
                      width: 200,
                      child: Center(child: Text("${pictime.toString()}")),
                    ),
                  ),
                ],
              ),
              Wrap(
                children:_choicechipList.map((e){
                  return Padding(
                      padding:EdgeInsets.all(5),
                    child: ChoiceChip(
                      selectedColor: Colors.blue,
                      label: Text("${e}"),
                      selected: selectedIndex == e,
                      onSelected: (bool selected){
                        setState(() {
                          selectedIndex = selected ? e : null;
                        });
                      },
                    ),
                  );
                }).toList(),
              ),
              Table(
                children: [
                  TableRow(children: [
                    Center(child: Text("1", style: TextStyle(fontSize: 15.0),)),
                    Center(child: Text("Mohit", style: TextStyle(fontSize: 15.0),)),
                    Center(child: Text("25", style: TextStyle(fontSize: 15.0),)),
                  ]),
                  TableRow(children: [
                    Center(child: Text("2", style: TextStyle(fontSize: 15.0),)),
                    Center(child: Text("Ankit", style: TextStyle(fontSize: 15.0),)),
                    Center(child: Text("27", style: TextStyle(fontSize: 15.0),)),
                  ]),
                  TableRow(children: [
                    Center(child: Text("3", style: TextStyle(fontSize: 15.0),)),
                    Center(child: Text("Rakhi", style: TextStyle(fontSize: 15.0),)),
                    Center(child: Text("26", style: TextStyle(fontSize: 15.0),)),
                  ]),
                ],
              ),
              DataTable(
                  columns:[
                    DataColumn(label: Text('ID'),),
                    DataColumn(label: Text('Name'),),
                    DataColumn(label: Text('LastName'),),
                    DataColumn(label: Text('Age'),),
                  ],
                  rows:[
                    DataRow(cells: [
                      DataCell(Text("1")),
                      DataCell(Text("Alex")),
                      DataCell(Text("Anderson")),
                      DataCell(Text("18")),
                    ]),
                    DataRow(cells: [
                      DataCell(Text("2")),
                      DataCell(Text("John")),
                      DataCell(Text("Anderson")),
                      DataCell(Text("24")),
                    ]),
                  ],
              ),
              DropdownButton<String>(
                items: <String>['A', 'B', 'C', 'D'].map((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value),
                  );
                }).toList(),
                value: selecteditem,
                onChanged: (value) {
                  setState(() {
                    selecteditem = value!;
                    print(selecteditem);
                  });
                },
              ),
              //flexible
              // Row(
              //   children: [
              //     Flexible(
              //       flex: 1,
              //       fit: FlexFit.tight,
              //       child: Container(
              //         height: 100,
              //         decoration: BoxDecoration(
              //           borderRadius: BorderRadius.circular(10),
              //           color: Colors.green,
              //         ),
              //       ),
              //     ),
              //     SizedBox(width: 10,),
              //     Flexible(
              //       flex: 1,
              //       fit: FlexFit.tight,
              //         child:Container(
              //           height: 100,
              //           decoration: BoxDecoration(
              //             borderRadius: BorderRadius.circular(10),
              //             color: Colors.green,
              //           ),
              //         ),
              //     ),
              //   ],
              // ),
              SizedBox(height: 5,),
              //align
              Align(
                alignment: Alignment.center,
                child: Text("Hello"),
              ),
            //AspectRatio
            Container(
            color: Colors.blue,
            alignment: Alignment.center,
            width: 100.0,
            height: 100.0,
            child: AspectRatio(
              aspectRatio: 0.5,
              child: Container(
                width: 100.0,
                height: 50.0,
                color: Colors.green,
              ),
            ),
          ),
              SizedBox(height: 5,),
              //visibilty
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                Visibility(
                  maintainSize: true, //NEW
                  maintainAnimation: true, //NEW
                  maintainState: true, //NEW
                  visible: _isShow,
                    child:Text("Welcome"),
                ),
                  ElevatedButton(onPressed: () {
                    setState(() {
                      _isShow = !_isShow;
                      print(_isShow);
                    });
                  }, child: Text(_isShow ? 'Hide' : 'Show', style: TextStyle(fontSize: 20),
                  ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
