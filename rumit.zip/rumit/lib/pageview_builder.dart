import 'package:flutter/material.dart';

class Pageview_builder extends StatefulWidget {
  const Pageview_builder({Key? key}) : super(key: key);

  @override
  State<Pageview_builder> createState() => _Pageview_builderState();
}

class _Pageview_builderState extends State<Pageview_builder> {

  var controller = PageController();
  List l = ['1','2','3','4'];
  List color = [Colors.green,Colors.yellow,Colors.blue,Colors.pink];
  int currentpage = 0;

  @override
  void initState() {
    super.initState();
    controller.addListener(() {
      setState(() {
        currentpage = controller.page!.toInt();
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Pageview"),),
      body: Column(
        children: [
          SizedBox(height: 10,),
          Text("$currentpage/"+l.length.toString(),style: TextStyle(fontSize: 20),),
          Expanded(
            child: PageView.builder(
                controller: controller  ,
               itemCount: l.length,
                itemBuilder: (context, index) {
              return Padding(
                padding: EdgeInsets.all(20),
                child: Card(
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(20))),
                  child: Container(
                    color: color[index],
                    child: Text("${l[index]}"),
                  ),
                ),
              );
            },),
          )
        ],
      ),
    );
  }
}
