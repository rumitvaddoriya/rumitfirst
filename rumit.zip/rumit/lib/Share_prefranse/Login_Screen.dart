import 'package:flutter/material.dart';
import 'package:rumit/Share_prefranse/Register_Screen.dart';
import 'package:rumit/Share_prefranse/Show_data.dart';
import 'package:shared_preferences/shared_preferences.dart';


class Share_Prefrense extends StatefulWidget {
  const Share_Prefrense({Key? key}) : super(key: key);

  @override
  State<Share_Prefrense> createState() => _Share_PrefrenseState();
}

class _Share_PrefrenseState extends State<Share_Prefrense> {

  TextEditingController useremail = TextEditingController();
  TextEditingController userpassword = TextEditingController();

  late SharedPreferences pref;
  bool? isLoggedIn = false;
  void initpref() async {
    pref =await SharedPreferences.getInstance();
    setState(() {
      isLoggedIn = pref.getBool("isLoggedIn");
    });
  }

  @override
  void initState() {
    super.initState();
    initpref();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey,
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: 60,),
            Text("Shareprefrense",style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),),
            SizedBox(height: 70,),
            Padding(
              padding:  EdgeInsets.all(10),
              child: TextField(
                controller: useremail,
                decoration: InputDecoration(
                    label: Text("Email"),
                    border: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(10)))
                ),
              ),
            ),
            SizedBox(height: 20,),
            Padding(
              padding: EdgeInsets.all(10),
              child: TextField(
                controller: userpassword,
                decoration: InputDecoration(
                    label: Text("password"),
                    border: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(10)))
                ),
              ),
            ),
            SizedBox(height: 50,),
            ElevatedButton(onPressed: () {
              Navigator.push(context, MaterialPageRoute(builder: (context) {
                return isLoggedIn == true ?  Share_Prefrense() : Show_data();
              },));
            }, child: Text("Login",style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),)),
            SizedBox(height: 10,),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text("Don't have an account?",style: TextStyle(fontSize: 15,),),
                GestureDetector(
                  onTap: () {
                    Navigator.push(context, MaterialPageRoute(builder: (context) {
                      return Register_Screen();
                    },));
                  },
                    child: Text("Register",style: TextStyle(fontSize: 20,color: Colors.yellow),),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
