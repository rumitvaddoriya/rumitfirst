import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:rumit/Share_prefranse/Login_Screen.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'model.dart';

class Show_data extends StatefulWidget {
  const Show_data({Key? key}) : super(key: key);

  @override
  State<Show_data> createState() => _Show_dataState();
}

class _Show_dataState extends State<Show_data> {

  late SharedPreferences pref;
  User? user=null;
  void initpref() async {
    pref =await SharedPreferences.getInstance();
    setState(() {
      user = User.fromJson(jsonDecode(pref.getString("userData")!));
    });
  }


  @override
  void initState() {
    super.initState();
    initpref();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: User!=null ?Text("Welcome ${user!.username}"): Text("welcome"),
        actions: [InkWell(onTap: () {
          pref.setBool("isLoggedIn", false);
          Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) {
            return Share_Prefrense();
          },));
        },child: Icon(Icons.logout))],
      ),
      body: User!=null ? Center(
        child: Column(
          children: [
            Text("username: ${user!.username}"),
            SizedBox(height: 16,),
            Text("useremail: ${user!.useremail}"),
            SizedBox(height: 16,),
            Text("userpassword: ${user!.userpassword}"),
            SizedBox(height: 16,),
          ],
        ),
      ) : SizedBox(),
    );
  }
}
