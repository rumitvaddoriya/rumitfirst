import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:rumit/Share_prefranse/Show_data.dart';
import 'package:rumit/Share_prefranse/model.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'Login_Screen.dart';

class Register_Screen extends StatefulWidget {
  const Register_Screen({Key? key}) : super(key: key);

  @override
  State<Register_Screen> createState() => _Register_ScreenState();
}

class _Register_ScreenState extends State<Register_Screen> {

  TextEditingController useremailController = TextEditingController();
  TextEditingController userpasswordController = TextEditingController();
  TextEditingController userphoneController = TextEditingController();
  TextEditingController usernameController = TextEditingController();

  late SharedPreferences pref;
  void initpref() async {
    pref =await SharedPreferences.getInstance();
  }


  @override
  void initState() {
    super.initState();
    initpref();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey,
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: 60,),
            Text("Shareprefrense",style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),),
            SizedBox(height: 70,),
            Padding(
              padding:  EdgeInsets.all(10),
              child: TextField(
                controller: usernameController,
                decoration: InputDecoration(
                    label: Text("Name"),
                    border: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(10)))
                ),
              ),
            ),
            Padding(
              padding:  EdgeInsets.all(10),
              child: TextField(
                controller: useremailController,
                decoration: InputDecoration(
                    label: Text("Email"),
                    border: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(10)))
                ),
              ),
            ),
            SizedBox(height: 10,),
            Padding(
              padding: EdgeInsets.all(10),
              child: TextField(
                controller: userpasswordController,
                decoration: InputDecoration(
                    label: Text("password"),
                    border: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(10)))
                ),
              ),
            ),
            SizedBox(height: 10,),
            Padding(
              padding: EdgeInsets.all(10),
              child: TextField(
                controller: userphoneController,
                decoration: InputDecoration(
                    label: Text("Phone number"),
                    border: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(10)))
                ),
              ),
            ),
            SizedBox(height: 50,),
            ElevatedButton(onPressed: () {

              final user = User(
                  userid: DateTime.now().millisecondsSinceEpoch.toString(),
                  username: usernameController.text,
                  useremail: useremailController.text,
                  userpassword: userpasswordController.text,
              );

              String  jsonString = jsonEncode(user);
              pref.setString("userData", jsonString);
              pref.setBool("isLogin", true);

              Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) {
                return Show_data();
              },));

            }, child: Text("Register",style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),)),
            SizedBox(height: 10,),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text("Don't have an account?",style: TextStyle(fontSize: 15,),),
                GestureDetector(
                  onTap: () {
                    Navigator.push(context, MaterialPageRoute(builder: (context) {
                      return Share_Prefrense();
                    },));
                  },
                  child: Text("Login",style: TextStyle(fontSize: 20,color: Colors.yellow),),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
