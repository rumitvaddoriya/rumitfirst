
class User{
  late String userid;
  late String username;
  late String useremail;
  late String userpassword;

  User({required this.userid,required this.username,required this.useremail,required this.userpassword});

  User.fromJson(Map<String, dynamic> json){
    userid = json['userid'];
    username = json['username'];
    useremail = json['useremail'];
    userpassword = json['userpassword'];
  }

  Map<String, dynamic> toJson(){
      final Map<String, dynamic> data = new Map<String, dynamic>();
      data['userid'] = this.userid;
      data['username'] = this.username;
      data['useremail'] = this.useremail;
      data['userpassword'] = this.userpassword;
      return data;
  }
}