import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_otp_text_field/flutter_otp_text_field.dart';
import 'package:phone_otp/second.dart';

class first extends StatefulWidget {
  const first({Key? key}) : super(key: key);

  @override
  State<first> createState() => _firstState();
}

class _firstState extends State<first> {
  FirebaseAuth auth = FirebaseAuth.instance;
  String ?id;
  TextEditingController t1 =TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("PHONE OTP"),),
      body: Column(
        children: [
          TextField(controller: t1,),
          ElevatedButton(onPressed: () async {
            await FirebaseAuth.instance.verifyPhoneNumber(
              phoneNumber: '+91${t1.text}',
              verificationCompleted: (PhoneAuthCredential credential) async {
                await auth.signInWithCredential(credential);
              },
              verificationFailed: (FirebaseAuthException e) {
                if (e.code == 'invalid-phone-number') {
                  print('The provided phone number is not valid.');
                }
              },
              codeSent: (String verificationId, int? resendToken) {
                id=verificationId;
              },
              codeAutoRetrievalTimeout: (String verificationId) {},
            );
          }, child: Text("otp")),
          OtpTextField(
            numberOfFields: 6,
            borderColor: Color(0xFF512DA8),
            //set to true to show as box or false to show as dash
            showFieldAsBox: true,
            //runs when a code is typed in
            onCodeChanged: (String code) {
              //handle validation or checks here
            },
            //runs when every textfield is filled
            onSubmit: (String verificationCode) async {
              String smsCode = verificationCode;

              // Create a PhoneAuthCredential with the code
              PhoneAuthCredential credential = PhoneAuthProvider.credential(verificationId: id!, smsCode: smsCode);

              // Sign the user in (or link) with the credential
              await auth.signInWithCredential(credential).then((value) {
                if(value!=null)
                  {
                    Duration(seconds: 3);
                    Navigator.push(context, MaterialPageRoute(builder: (context) {
                      return second();
                    },));
                  }
              });
            }, // end onSubmit
          ),
          // ElevatedButton(onPressed: () {
          //
          // }, child: Text("Submit"))
        ],
      )
    );
  }
}
