import 'package:flutter/material.dart';
import 'package:push_notification/notification_services.dart';

void main() {
  runApp(const MaterialApp(home: first(),));
}

class first extends StatefulWidget {
  const first({Key? key}) : super(key: key);

  @override
  State<first> createState() => _firstState();
}

class _firstState extends State<first> {
  NotificationServices notificationServices = NotificationServices();


  @override
  void initState() {
    super.initState();
    notificationServices.initaliseNotifications();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SizedBox(
        width: double.infinity,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(onPressed: () {
              notificationServices.sendNotification("This is title", "This is body");
            }, child: Text("Send Notification")),
            ElevatedButton(onPressed: () {
              notificationServices.secheduleNotification("This is title", "this is body");
            }, child: Text("schedul Notification")),
            ElevatedButton(onPressed: () {
              notificationServices.stopnotification();
            }, child: Text("Stop Notification"))
          ],
        ),
      ),
    );
  }
}


