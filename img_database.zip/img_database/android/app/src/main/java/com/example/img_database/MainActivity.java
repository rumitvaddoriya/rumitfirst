package com.example.img_database;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
