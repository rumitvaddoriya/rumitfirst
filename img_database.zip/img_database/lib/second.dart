import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:img_database/third.dart';
import 'package:sqflite_common/sqlite_api.dart';

class second extends StatefulWidget {
  Database database;

  second(this.database);

  @override
  State<second> createState() => _secondState();
}

class _secondState extends State<second> {
  List name = [];
  List contact = [];
  List id = [];
  List image = [];

  @override
  void initState() {
    super.initState();
    view_data();
  }

  view_data() async {
    String qry;
    List<Map> list = [];
    qry = "select * from contact_book";
    list = await widget.database.rawQuery(qry);
    // print(list);
    return list;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: FutureBuilder(
        future: view_data(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.done) {
            if (snapshot.hasData) {
              List<Map>? st = [];
              name.clear();
              contact.clear();
              id.clear();
              image.clear();
              st = snapshot.data as List<Map>?;
              st!.forEach((element) {
                name.add(element['name']);
                contact.add(element['contact']);
                id.add(element['id']);
                image.add(element['image']);
              });
            }
            return ListView.builder(
              itemCount: name.length,
              itemBuilder: (context, index) {
                return ListTile(
                  title: Text(name[index]),
                  subtitle: Text(contact[index]),
                  leading: Container(
                    height: 60,
                    width: 60,
                    padding: EdgeInsets.all(5),
                    child: Container(
                      child: Image.memory(
                        base64Decode(
                          image[index],
                        ),
                        fit: BoxFit.fill,
                      ),
                    ),
                  ),
                  trailing: IconButton(
                      onPressed: () {
                        showDialog(
                          context: context,
                          builder: (context) {
                            return AlertDialog(
                              title: Text("delete or update"),
                              actions: [
                                TextButton(
                                    onPressed: () async {
                                      String qry;
                                      qry="delete from contact_book where id=${id[index]}";
                                      int r_id=await widget.database.rawDelete(qry);
                                      if(r_id==1)
                                        {
                                          setState(() {

                                          });
                                        }
                                      else
                                        {
                                          print("Not Deleted");
                                        }
                                      Navigator.pop(context);
                                    }, child: Text("delete")),
                                TextButton(
                                    onPressed: () {
                                      Navigator.push(context, MaterialPageRoute(builder: (context) {
                                          return third(id[index],name[index],contact[index],image[index],widget.database);
                                      },));
                                    }, child: Text("update"))
                              ],
                            );
                          },
                        );
                      },
                      icon: Icon(Icons.edit)),
                );
              },
            );
          } else {
            return Center(
              child: CircularProgressIndicator(),
            );
          }
        },
      ),
    );
  }
}
