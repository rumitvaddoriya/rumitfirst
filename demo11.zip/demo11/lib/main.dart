import 'dart:convert';

import 'package:demo11/student.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main(){
  runApp(MaterialApp(home: first(),));
}

class first extends StatefulWidget {
  const first({Key? key}) : super(key: key);

  @override
  State<first> createState() => _firstState();
}

class _firstState extends State<first> {

  student?l;

  @override
   void initState() {
     super.initState();
     get();
   }

  Future get() async {
    var url = Uri.parse('https://dummy.restapiexample.com/api/v1/employees');
    var response = await http.get(url);
    print('Response status: ${response.statusCode}');
    print('Response body: ${response.body}');

    Map<String, dynamic> m = jsonDecode(response.body);
    print(m['data']);

    l=student.fromJson(m);
    print(l);
    return l;

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Api"),),
      body:FutureBuilder(future: get(),builder: (context, snapshot) {
        if(snapshot.connectionState == ConnectionState.done)
          {
                return ListView.builder(itemCount: 5,itemBuilder: (context, index) {
                  var p=snapshot.data;
                  return ListTile(
                    title: Text("${p.data![index].employeeName}"),
                    subtitle: Text("${p.data![index].employeeSalary}"),
                    leading: Text("${p.data![index].id}"),
                  );
                },);
          }
        else
        {
          return Center(child: CircularProgressIndicator(),);
        }
      },) ,
    );
  }
}
