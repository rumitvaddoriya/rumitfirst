package com.example.chat_app_brain

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
