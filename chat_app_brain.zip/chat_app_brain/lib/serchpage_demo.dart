import 'package:chat_app_brain/chatroommodel_demo.dart';
import 'package:chat_app_brain/chatroompage_demo.dart';
import 'package:chat_app_brain/main.dart';
import 'package:chat_app_brain/usermodel_demo.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class serchpage_demo extends StatefulWidget {
  final UserModel userModel;
  final User firebaseuser;

  const serchpage_demo({super.key, required this.userModel, required this.firebaseuser});

  @override
  State<serchpage_demo> createState() => _serchpage_demoState();
}

class _serchpage_demoState extends State<serchpage_demo> {

  TextEditingController emailcontroller = TextEditingController();

  Future<ChatRoomModel?> getchatroomModel(UserModel targetUser) async {
   QuerySnapshot snapshot =  await FirebaseFirestore.instance.collection("chatrooms").where
      ("participnts.${widget.userModel.uid}",isEqualTo: true).where
      ("participnts.${targetUser.uid}",isEqualTo: true).get();

   if(snapshot.docs.length > 0){
     print("Chatroom already created");
   }else{
     ChatRoomModel newChatroom = ChatRoomModel(
       chatroomid: uuid.v1(),
       lastmessage: "",
       participants: {
         widget.userModel.uid.toString():true,
         targetUser.uid.toString():true,
       }
     );
     await FirebaseFirestore.instance.collection("chatrooms").doc
       (newChatroom.chatroomid).set(newChatroom.toMap());
     print("new custom created");
   }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("serch"),),
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: 20,),
            StreamBuilder(
              stream: FirebaseFirestore.instance.collection("users").where("email",isEqualTo: widget.userModel.email).snapshots(),
              builder: (context, snapshot) {
                  if(snapshot.connectionState == ConnectionState.active){
                      if(snapshot.hasData){

                          QuerySnapshot dataSnapshot = snapshot.data as QuerySnapshot;

                          if(dataSnapshot.docs.length > 0){
                            Map<String,dynamic> userMap = dataSnapshot.docs[0].data() as Map<String,dynamic>;

                            UserModel serchBar = UserModel.fromMap(userMap);

                            return ListTile(
                              onTap: () async {
                                ChatRoomModel? chatroomModel = await getchatroomModel(serchBar);
                                // Navigator.pop(context);
                                // Navigator.push(context, MaterialPageRoute(builder: (context) {
                                //   return chatroompage_demo(targetUser: serchBar, chatroom: widget.userModel,
                                //       userModel: widget.userModel, firebaseUser: widget.firebaseuser);
                                // },));
                              },
                              leading: CircleAvatar(
                                backgroundImage: NetworkImage(serchBar.profilepic!),
                              ),
                              title: Text(serchBar.fullname.toString()),
                              subtitle: Text(serchBar.email.toString()),
                              trailing: Icon(Icons.keyboard_arrow_right),
                            );

                          }else{
                            return Center(child:  Text("No resul found!"),);
                          }

                      }else if(snapshot.hasError){
                        return Text("An Error occured!");
                      }else{
                        return Text("No Result Found!");
                      }
                  }else{
                    return Center(child: CircularProgressIndicator(),);
                  }
            },),
          ],
        ),
      ),
    );
  }
}
