import 'package:chat_app_brain/complateprofile_demo.dart';
import 'package:chat_app_brain/usermodel_demo.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';

class signup_demo extends StatefulWidget {
  const signup_demo({Key? key}) : super(key: key);

  @override
  State<signup_demo> createState() => _signup_demoState();
}

class _signup_demoState extends State<signup_demo> {

  TextEditingController emailcontroller = TextEditingController();
  TextEditingController passwordcontroller = TextEditingController();
  TextEditingController cpasswordcontroller = TextEditingController();

  void chechvalue(){
    String email = emailcontroller.text.trim();
    String password = passwordcontroller.text.trim();
    String cpassword = cpasswordcontroller.text.trim();

    if(email == "" || password == "" || cpassword == ""){
      print("please feild");
    }else if(password != cpassword){
      print("password not match");
    }else{
      signup(email, password);
    }
  }

  void signup(String email, String password)async{
    UserCredential? credential;

    try{
      credential = await FirebaseAuth.instance.createUserWithEmailAndPassword(email: email, password: password);
    }on FirebaseAuthException catch(ex){
      print(ex.code.toString());
    }

    if(credential != null){
      String uid = credential.user!.uid;
      UserModel newUser = UserModel(
        uid: uid,
        email: email,
        fullname: "",
        profilepic: ""
      );
      await FirebaseFirestore.instance.collection("users").doc(uid).set(newUser.toMAp()).then((value){
        print("new user created");
        Navigator.push(context, MaterialPageRoute(builder: (context) {
          return complateprofile_demo(userModel: newUser, firebaseuser: credential!.user!);
        },));
      });
    }

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            Center(child: SizedBox(height: 100,),),
            Text("Chat App",style: TextStyle(fontSize:40,fontWeight: FontWeight.bold),),
            SizedBox(height: 40,),
            TextField(
              controller: emailcontroller,
              decoration: InputDecoration(
                  hintText: "Email Address",
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(20)
                  )
              ),
            ),
            SizedBox(height: 20,),
            TextField(
              controller: passwordcontroller,
              decoration: InputDecoration(
                  hintText: "password",
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(20)
                  )
              ),
            ),
            SizedBox(height: 20,),
            TextField(
              controller: cpasswordcontroller,
              decoration: InputDecoration(
                  hintText: "Confirm password",
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(20)
                  )
              ),
            ),
            SizedBox(height: 30,),
            ElevatedButton(onPressed: () {
              chechvalue();
                // Navigator.push(context, MaterialPageRoute(builder: (context) {
                //   return complateprofile_demo();
                // },));
            }, child: Text("Sign up"))
          ],
        ),
      ),
      bottomNavigationBar: Container(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text("Already have account ?",style: TextStyle(fontSize: 16),),
            TextButton(onPressed: () {
              Navigator.pop(context);
            } , child:Text("Login",style: TextStyle(fontSize: 16),))
          ],
        ),
      ),
    );
  }
}
