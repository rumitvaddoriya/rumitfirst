import 'package:chat_app_brain/serchpage_demo.dart';
import 'package:chat_app_brain/usermodel_demo.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class homepage_demo extends StatefulWidget {
  final UserModel userModel;
  final User firebaseuser;

  const homepage_demo({super.key, required this.userModel, required this.firebaseuser});

  @override
  State<homepage_demo> createState() => _homepage_demoState();
}

class _homepage_demoState extends State<homepage_demo> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.search),
        onPressed: () {
          Navigator.push(context, MaterialPageRoute(builder: (context) {
            return serchpage_demo(userModel: widget.userModel, firebaseuser: widget.firebaseuser);
          },));
      },),
    );
  }
}
