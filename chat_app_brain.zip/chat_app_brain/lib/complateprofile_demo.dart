import 'dart:developer';
import 'dart:io';
import 'package:chat_app_brain/homepage_demo.dart';
import 'package:chat_app_brain/usermodel_demo.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

class complateprofile_demo extends StatefulWidget {
  final UserModel userModel;
  final User firebaseuser;

  const complateprofile_demo({super.key,required this.userModel,required this.firebaseuser});

  @override
  State<complateprofile_demo> createState() => _complateprofile_demoState();
}

class _complateprofile_demoState extends State<complateprofile_demo> {


  TextEditingController fullnamecontroller = TextEditingController();
  File? pickedImage;

  void pickedimage(ImageSource source) async {
    try{
      final photo = await ImagePicker().pickImage(source: source);
      if(photo == null) return;
      final tempImage = File(photo.path);
      setState(() {
        pickedImage = tempImage;
      });
      Navigator.pop(context);
    }catch(e){
      print("error: ${e.toString()}");
    }
  }

  void checkvalue(){
    String fullname = fullnamecontroller.text.trim();

    if(fullname == "" || pickedImage == null){
      print("please fill all field");
    }else{
      log("Data uploadeding....");
      uploadData();
    }
  }

  void uploadData() async {
    UploadTask uploadTask =
    FirebaseStorage.instance.ref("profile").child(widget.userModel.uid.toString()).putFile(pickedImage!);

    TaskSnapshot snapshot = await uploadTask;

    String?  imageurl = await snapshot.ref.getDownloadURL();
    String? fullname = fullnamecontroller.text.trim();

    widget.userModel.fullname = fullname;
    widget.userModel.profilepic = imageurl;

    await FirebaseFirestore.instance.collection("users").doc(widget
        .userModel.uid).set(widget.userModel.toMAp()).then((value){
          log("Data uploaded");
          print("Data uploaded");
          Navigator.push(context, MaterialPageRoute(builder: (context) {
            return homepage_demo(userModel: widget.userModel, firebaseuser: widget.firebaseuser);
          },));
    });
  }


  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      appBar: AppBar(
        centerTitle: true,
        automaticallyImplyLeading: false,
        title: Text("Complate Profile"),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Center(child: SizedBox(height: 40,),),
             InkWell(
              onTap: () {
                showImagepick();
              },
              child: pickedImage != null ? Container(
               height: 150,
               width: 150,
               child:Image.file(pickedImage!,fit: BoxFit.cover,),
               decoration: BoxDecoration(color: Colors.grey,borderRadius: BorderRadius.all(Radius.circular(100))),
            ) : Container(
              height: 150,
              width: 150,
              child: Icon(Icons.person,color: Colors.black54,size: 50,),
              decoration: BoxDecoration(color: Colors.grey,borderRadius: BorderRadius.all(Radius.circular(100))),
            ),
             ),
            SizedBox(height: 50,),
            TextField(
              controller: fullnamecontroller,
              decoration: InputDecoration(
                  hintText: "Full Name",
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(20)
                  )
              ),
            ),
            SizedBox(height: 30,),
            ElevatedButton(onPressed: () {
              checkvalue();
            }, child: Text("Submit"))
          ],
        ),
      ),
    );
  }

  void showImagepick(){
    showDialog(context: context, builder: (context) {
      return AlertDialog(
        title: Text("Upload profile picture"),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              onTap: () async {
                pickedimage(ImageSource.gallery);
                // final ImagePicker _picker = ImagePicker();
                // final XFile? image = await _picker.pickImage(source: ImageSource.gallery);
                // if(image != null){
                //   print("image : ${image.path}");
                //   setState(() {
                //     _image = image.path;
                //   });
                // };
              },
              title: Text("Select from gallery"),
            ),
            ListTile(
              onTap: () async {
                pickedimage(ImageSource.camera);
                // final ImagePicker _picker = ImagePicker();
                // final XFile? image = await _picker.pickImage(source: ImageSource.camera);
                // if(image != null){
                //   print("image : ${image.path}");
                //   setState(() {
                //     _image = image.path as XFile?;
                //   });
                // };
              },
              title: Text("Select from camera"),
            ),
          ],
        ),
      );
    },);
  }

}
