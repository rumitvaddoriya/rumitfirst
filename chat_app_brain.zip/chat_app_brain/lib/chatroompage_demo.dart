import 'package:chat_app_brain/chatroommodel_demo.dart';
import 'package:chat_app_brain/usermodel_demo.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class chatroompage_demo extends StatefulWidget {
  final UserModel targetUser;
  final ChatRoomModel chatroom;
  final UserModel userModel;
  final User firebaseUser;
  const chatroompage_demo({Key? key, required this.targetUser,required this.chatroom,required this.userModel,required this.firebaseUser}) : super(key: key);

  @override
  State<chatroompage_demo> createState() => _chatroompage_demoState();
}

class _chatroompage_demoState extends State<chatroompage_demo> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
        body: Column(
          children: [
              Expanded(child: Container()),
            Container(
              color: Colors.black12,
              child:Row(
                children: [
                  Flexible(
                    child: TextField(
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      hintText: "Enter Message...",
                    ),
                  ),
                  ),
                  IconButton(
                    color: Colors.blueAccent,
                      onPressed: () {

                  }, icon: Icon(Icons.send)),
                ],
              ),
            )
          ],
        ),
    );
  }
}
