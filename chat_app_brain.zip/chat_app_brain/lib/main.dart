import 'package:chat_app_brain/firebasehelper.dart';
import 'package:chat_app_brain/homepage_demo.dart';
import 'package:chat_app_brain/loginpage_demo.dart';
import 'package:chat_app_brain/usermodel_demo.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';

var uuid = Uuid();

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();

  User? currentuser = FirebaseAuth.instance.currentUser;
  if(currentuser != null){
    UserModel? thisusermodle = await FirebaseHelper.getusermodelId(currentuser.uid);
    if(thisusermodle != null){
      runApp(MyAppLoggedIn(userModel: thisusermodle, firebaseuser: currentuser));
    }else{
      runApp(MyApp());
    }

  }else{
    runApp(MyApp());
  }

}

// not login
class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: loginpagee(),
    );
  }
}

//alerady loggin
class MyAppLoggedIn extends StatelessWidget {
  final UserModel userModel;
  final User firebaseuser;

  const MyAppLoggedIn({super.key, required this.userModel, required this.firebaseuser});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: homepage_demo(userModel: userModel, firebaseuser: firebaseuser),
    );
  }
}

