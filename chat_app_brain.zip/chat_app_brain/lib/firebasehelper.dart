import 'package:cloud_firestore/cloud_firestore.dart';

import 'usermodel_demo.dart';

class FirebaseHelper{

 static Future<UserModel?> getusermodelId(String uid) async{
    UserModel? usermodel;

    DocumentSnapshot doc = await FirebaseFirestore.instance.collection("users").doc(uid).get();

    if(doc.data() != null){
      usermodel = UserModel.fromMap(doc.data() as Map<String, dynamic>);
    }
    return usermodel;
  }
}