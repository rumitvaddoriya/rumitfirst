import 'package:chat_app_brain/Helper/My_date.dart';
import 'package:chat_app_brain/api/Apis.dart';
import 'package:chat_app_brain/models/message.dart';
import 'package:flutter/material.dart';

class message_card extends StatefulWidget {
  final Message message;
  const message_card({Key? key, required this.message}) : super(key: key);

  @override
  State<message_card> createState() => _message_cardState();
}

class _message_cardState extends State<message_card> {
  @override
  Widget build(BuildContext context) {
    return APIs.user.uid == widget.message.fromId ? _greenMessage() : _blueMessage();
  }

  Widget _blueMessage(){

    if(widget.message.read.isEmpty){
      APIs.updateMessageReadStatus(widget.message);
    }

    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Flexible(
          child: Container(
            padding: EdgeInsets.all(10),
            margin: EdgeInsets.all(10),
            decoration: BoxDecoration(
              border: Border.all(color: Colors.lightBlue),
                color: Color.fromARGB(255, 221, 245, 255),
                borderRadius: BorderRadius.only(topLeft: Radius.circular(30),
                  topRight: Radius.circular(30),
                  bottomRight: Radius.circular(30)
                ),
            ),
            child: Text(widget.message.msg,style:TextStyle(fontSize: 20,color: Colors.black87),) ,
          ),
        ),
        Padding(
          padding:  EdgeInsets.only(right: 10),
          child:Text(MyDateUtils.getFormattedTime(context: context, time: widget.message.sent),style:TextStyle(fontSize: 13,color: Colors.black54)),

        ),
      ],
    );
  }

  Widget _greenMessage(){
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Row(
          children: [
            SizedBox(width: 5,),

            if(widget.message.read.isNotEmpty)
            Icon(Icons.done_all_rounded,color: Colors.blue,size: 20,),
            SizedBox(width: 5,),
            Text(MyDateUtils.getFormattedTime(context: context, time: widget.message.sent),style:TextStyle(fontSize: 13,color: Colors.black54)),
          ],
        ),
        Flexible(
          child: Container(
            padding: EdgeInsets.all(10),
            margin: EdgeInsets.all(10),
            decoration: BoxDecoration(
              border: Border.all(color: Colors.lightGreen),
              color: Color.fromARGB(255, 218, 255, 176),
              borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(30),
                  topRight: Radius.circular(30),
                  bottomLeft: Radius.circular(30)
              ),
            ),
            child: Text(widget.message.msg,style:TextStyle(fontSize: 20,color: Colors.black87),) ,
          ),
        ),
      ],
    );
  }

}
