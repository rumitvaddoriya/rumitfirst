import 'package:cached_network_image/cached_network_image.dart';
import 'package:chat_app_brain/Helper/My_date.dart';
import 'package:chat_app_brain/Screens/Chat_Screen/chat_screen.dart';
import 'package:chat_app_brain/api/Apis.dart';
import 'package:chat_app_brain/models/chat_user.dart';
import 'package:chat_app_brain/models/message.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class UserChatCard extends StatefulWidget {
  final ChatUser user;
  const UserChatCard({Key? key, required this.user}) : super(key: key);

  @override
  State<UserChatCard> createState() => _UserChatCardState();
}

class _UserChatCardState extends State<UserChatCard> {

  Message? message;

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.all(5),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: InkWell(
        onTap: () {
          Navigator.push(context, MaterialPageRoute(builder: (context) {
            return chat_screen(user: widget.user);
          },));
        },
        child:StreamBuilder(
          stream: APIs.getLastMessage(widget.user),
          builder: (context, snapshot) {
            final data = snapshot.data?.docs;
            final list = data?.map((e) => Message.fromJson(e.data())).toList() ?? [];

            // if(list.isNotEmpty){
            //     message = list[0];
            //   }

            return ListTile(
              leading:ClipRRect(
                borderRadius: BorderRadius.circular(40),
                child: CachedNetworkImage(
                  imageUrl:widget.user.email,
                  placeholder:(context, url) => CircularProgressIndicator(),
                  errorWidget: (context, url, error) => CircleAvatar(child: Icon(CupertinoIcons.person)),
                ),
              ),
              title: Text(widget.user.name),
              subtitle: Text(message != null ? message!.msg : widget.user.about,maxLines: 1,),
              trailing:message != null ? null : message!.read.isEmpty && message!.fromId != APIs.user.uid ?
              Container(
                height: 15,
                width: 15,
                decoration: BoxDecoration(borderRadius: BorderRadius.circular(10),color: Colors.blueAccent.shade100),
              ) : Text(MyDateUtils.getLastMessageTime(context: context, time: message!.sent),style: TextStyle(color: Colors.black54),)
            );
        },),
      ),
    );
  }
}
