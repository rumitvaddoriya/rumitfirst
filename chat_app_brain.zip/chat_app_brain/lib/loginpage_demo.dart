import 'package:chat_app_brain/homepage_demo.dart';
import 'package:chat_app_brain/signuppage_demo.dart';
import 'package:chat_app_brain/usermodel_demo.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class loginpagee extends StatefulWidget {
  const loginpagee({Key? key}) : super(key: key);

  @override
  State<loginpagee> createState() => _loginpageeState();
}

class _loginpageeState extends State<loginpagee> {

  TextEditingController emailcontroller = TextEditingController();
  TextEditingController passwordcontroller = TextEditingController();

  void chechvalue(){
    String email = emailcontroller.text.trim();
    String password = passwordcontroller.text.trim();

    if(email == "" || password == ""){
      print("please feild");
    }else{
      signup(email, password);
    }
  }

  void signup(String email, String password)async{
    UserCredential? credential;

    try{
      credential = await FirebaseAuth.instance.signInWithEmailAndPassword(email: email, password: password);
    }on FirebaseAuthException catch(ex){
      print(ex.code.toString());
    }

    if(credential != null){
      String uid = credential.user!.uid;
      DocumentSnapshot userData = await FirebaseFirestore.instance.collection("users").doc(uid).get();
      UserModel userModel = UserModel.fromMap(userData.data() as Map<String, dynamic>);

      print("login seuccess");
      Navigator.push(context, MaterialPageRoute(builder: (context) {
        return homepage_demo(userModel: userModel, firebaseuser: credential!.user!);
      },));
    }

  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Center(child: SizedBox(height: 100,),),
          Text("Chat App",style: TextStyle(fontSize:40,fontWeight: FontWeight.bold),),
          SizedBox(height: 40,),
          TextField(
            controller: emailcontroller,
            decoration: InputDecoration(
              hintText: "Email Address",
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(20)
                )
            ),
          ),
          SizedBox(height: 20,),
          TextField(
            controller: passwordcontroller,
            decoration: InputDecoration(
                hintText: "password",
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(20)
                )
            ),
          ),
          SizedBox(height: 30,),
          ElevatedButton(onPressed: () {
              chechvalue();
          }, child: Text("Login"))
        ],
      ),
      bottomNavigationBar: Container(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text("Dont have account ?",style: TextStyle(fontSize: 16),),
            TextButton(onPressed: () {
              Navigator.push(context, MaterialPageRoute(builder: (context) {
                return signup_demo();
              },));
            } , child:Text("Sign up",style: TextStyle(fontSize: 16),))
          ],
        ),
      ),
    );
  }
}
