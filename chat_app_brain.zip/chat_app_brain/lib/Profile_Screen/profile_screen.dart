import 'dart:io';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:chat_app_brain/Screens/auth/Login_Screen.dart';
import 'package:chat_app_brain/api/Apis.dart';
import 'package:chat_app_brain/models/chat_user.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:image_picker/image_picker.dart';

class profile_screen extends StatefulWidget {
  final ChatUser user;
  const profile_screen({Key? key, required this.user}) : super(key: key);

  @override
  State<profile_screen> createState() => _profile_screenState();
}

class _profile_screenState extends State<profile_screen> {

    TextEditingController namecontroller = TextEditingController();
    TextEditingController passcontroller = TextEditingController();

    GlobalKey<FormState> formkey = GlobalKey<FormState>();

    String? _image;

  @override
  Widget build(BuildContext context)  {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        elevation: 1,
        title: Text("Profile Screen",style:TextStyle(color: Colors.black,fontWeight: FontWeight.normal,fontSize: 19),),
        backgroundColor: Colors.white,
      ),
      floatingActionButton: Padding(
        padding: EdgeInsets.only(bottom: 10),
        child: FloatingActionButton.extended(
          backgroundColor: Colors.redAccent,
          onPressed: () async {
            Center(child: CircularProgressIndicator(),);
            await APIs.auth.signOut().then((value) async {
              await GoogleSignIn().signOut().then((value){
                Navigator.pop(context);
                Navigator.push(context, MaterialPageRoute(builder: (context) => login_screen(),));
              });
            });
          },
          icon: Icon(Icons.add_comment_rounded),
          label:Text("Logout"),
        ),
      ),
      body:Form(
        key: formkey,
        child: SingleChildScrollView(
          child: Column(
            children: [
              Center(child: SizedBox(height: 20,),),
              Stack(
                children: [
                 _image != null ?  Padding(
                  padding:EdgeInsets.all(0),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(40),
                    child: Image.file(
                      File(_image!),
                      height: 150,
                      width: 150,
                      fit: BoxFit.cover,
                    ),
                  ),
                ) :  Padding(
                   padding:EdgeInsets.all(0),
                   child: ClipRRect(
                     borderRadius: BorderRadius.circular(40),
                     child: CachedNetworkImage(
                       imageUrl:widget.user.email,
                       height: 150,
                       width: 150,
                       placeholder:(context, url) => CircularProgressIndicator(),
                       errorWidget: (context, url, error) => CircleAvatar(child: Icon(CupertinoIcons.person,size: 100,)),
                     ),
                   ),
                 ),
                  Padding(
                    padding:  EdgeInsets.only(top: 80,left: 90),
                    child: MaterialButton(
                      shape: CircleBorder(),
                      color: Colors.white,
                      child: Icon(Icons.edit,color: Colors.blue,),
                      onPressed: () {
                        showmodelBottom();
                      },
                    ),
                  ),
                ],
              ),
              SizedBox(height: 20,),
              Text(widget.user.email,style: TextStyle(fontSize: 16,color: Colors.black54),),
              SizedBox(height: 40,),
              Padding(
                padding:EdgeInsets.only(left: 20,right: 20),
                child: TextFormField(
                  initialValue: widget.user.name,
                  onSaved: (value) => APIs.me.name = value ?? '',
                  validator: (value) => value != null && value.isNotEmpty ? null : 'Enter Name',
                  decoration: InputDecoration(
                    prefixIcon: Icon(Icons.person),
                    hintText: "Enter Name",
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(10))
                  ),
                ),
              ),
              SizedBox(height: 20,),
              Padding(
                padding:EdgeInsets.only(left: 20,right: 20),
                child: TextFormField(
                  initialValue: widget.user.about,
                  onSaved: (value) => APIs.me.about = value ?? '',
                  validator: (value) => value != null && value.isNotEmpty ? null : 'Enter About',
                  decoration: InputDecoration(
                      prefixIcon: Icon(Icons.person),
                      hintText: "About",
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(10))
                  ),
                ),
              ),
              SizedBox(height: 30,),
              Container(
                height: 50,
                width: 200,
                child: ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(shape: StadiumBorder()),
                  onPressed: () {
                    if(formkey.currentState!.validate()){
                      formkey.currentState!.save();
                      APIs.updateUserItem();
                     ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Profile Updated Successdully!"),backgroundColor: Colors.black12,));
                      print("Validator");
                    }
                },label: Text("UPDATE"),icon: Icon(Icons.edit),),
              )
            ],
          ),
        ),
      ),
    );
  }

  //pic image
  void showmodelBottom(){
    showModalBottomSheet(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.only(topLeft: Radius.circular(20),bottomRight: Radius.circular(20))),
      context: context,
      builder: (context) {
      return Container(
        height: 200,
        width: double.infinity,
        color: Colors.white,
        child:Column(
          children: [
            Center(child: SizedBox(height: 30,),),
            Text("Pick Profile Picture",style: TextStyle(fontSize: 25,fontWeight: FontWeight.w500),),
            SizedBox(height: 50,),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
             ElevatedButton(onPressed: () async {
               final ImagePicker _picker = ImagePicker();
               final XFile? image = await _picker.pickImage(source: ImageSource.gallery);
               if(image != null){
                 print("image : ${image.path}");
                 setState(() {
                   _image = image.path;
                 });
                 APIs.updateProfilePicture(File(_image!));
                 Navigator.pop(context);
               }else{
                 print("hhhh");
               }
             }, child: Text("Pick image Gallery")),
                SizedBox(width: 10,),
                ElevatedButton(onPressed: () async {
                  final ImagePicker _picker = ImagePicker();
                  final XFile? image = await _picker.pickImage(source: ImageSource.camera);
                  if(image != null){
                    print("image : ${image.path}");
                    setState(() {
                      _image = image.path;
                    });
                    APIs.updateProfilePicture(File(_image!));
                    Navigator.pop(context);
                  }else{
                    print("hhhh");
                  }
                }, child: Text("Pick image Camera")),
            ],)
          ],
        )
      );
    },);
  }

}
