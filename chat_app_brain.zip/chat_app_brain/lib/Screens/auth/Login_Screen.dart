import 'dart:developer';
import 'dart:io';
import 'package:chat_app_brain/Helper/dialog.dart';
import 'package:chat_app_brain/Screens/Home_Screen/home_screen.dart';
import 'package:chat_app_brain/api/Apis.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';

class login_screen extends StatefulWidget {
  const login_screen({Key? key}) : super(key: key);

  @override
  State<login_screen> createState() => _login_screenState();
}

class _login_screenState extends State<login_screen> {
  bool looged = true;

  GoogleSigninButton(){
   _signInWithGoogle().then((user) async {

     if(user != null){
       log("---------------->\nUser: ${user.user}");
       log("---------------->\nUserAssitionalInfo: ${user.additionalUserInfo}");

       if(await APIs.userExits()){
         Navigator.push(context, MaterialPageRoute(builder: (context) {
           return home_screen();
         },));
       }else{
          await APIs.createUser().then((value){
            Navigator.push(context, MaterialPageRoute(builder: (context) {
              return home_screen();
            },));
          });
       }
     }
   });
  }

  Future<UserCredential?> _signInWithGoogle() async {
   try{
        await InternetAddress.lookup("Google.com");
     // Trigger the authentication flow
     final GoogleSignInAccount? googleUser = await GoogleSignIn().signIn();

     // Obtain the auth details from the request
     final GoogleSignInAuthentication? googleAuth = await googleUser?.authentication;

     // Create a new credential
     final credential = GoogleAuthProvider.credential(
       accessToken: googleAuth?.accessToken,
       idToken: googleAuth?.idToken,
     );
     // Once signed in, return the UserCredential
     return await APIs.auth.signInWithCredential(credential);
   }catch(e){
      log("----------?\n_signInWithGoogle: ${e}");
      Dialogs.ShowSnackbar(context, 'Somthing Want wrong (Check Internet!)');
      return null;
   }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        elevation: 1,
        title: Text("Welcome to We Chat",style:TextStyle(color: Colors.black,fontWeight: FontWeight.normal,fontSize: 19),),
        backgroundColor: Colors.white,
      ),
      body: Column(
        children: [
          Center(child: SizedBox(height: 20,),),
          Padding(
            padding:EdgeInsets.all(10),
            child:Container(
              height: 150,
              width: 150,
              child: Image.asset("images/chat-app-logo-icon-vector.webp",fit: BoxFit.fill,),
            ),
          ),
          SizedBox(height: 250,),
          Padding(
            padding:EdgeInsets.all(10),
            child:InkWell(
              onTap: () {
               GoogleSigninButton();
              },
              child: Container(
                height: 50,
                width: 280,
                decoration: BoxDecoration(color: Colors.grey,borderRadius: BorderRadius.all(Radius.circular(20))),
                child: Center(child: Text("Google SignIn Account",style: TextStyle(fontSize: 19,color:Colors.black),)),
              ),
            ),
          ),
        ],
      )
    );
  }
}
