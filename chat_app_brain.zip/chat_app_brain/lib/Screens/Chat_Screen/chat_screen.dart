import 'package:cached_network_image/cached_network_image.dart';
import 'package:chat_app_brain/api/Apis.dart';
import 'package:chat_app_brain/models/chat_user.dart';
import 'package:chat_app_brain/models/message.dart';
import 'package:chat_app_brain/wigets/Message_Card/message_card.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class chat_screen extends StatefulWidget {
  final ChatUser user;
  const chat_screen({Key? key, required this.user}) : super(key: key);

  @override
  State<chat_screen> createState() => _chat_screenState();
}

class _chat_screenState extends State<chat_screen> {

  List<Message> list = [];
  TextEditingController _textcontroller = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        automaticallyImplyLeading: false,
        flexibleSpace: _appBar(),
      ),
      backgroundColor: Color.fromARGB(255, 234, 248, 255),
      body: Column(
        children: [
          Expanded(
            child: StreamBuilder(
              stream:APIs.getAllMessages(widget.user),
              builder: (context,snapshot) {
                switch(snapshot.connectionState){
                  case ConnectionState.waiting:
                  case ConnectionState.none:

                    return SizedBox();

                  case ConnectionState.active:
                  case ConnectionState.done:
                    final data = snapshot.data?.docs;
                    list = data?.map((e) => Message.fromJson(e.data())).toList() ?? [];

                    if(list.isNotEmpty){
                      return ListView.builder(
                        itemCount:list.length,
                        physics: BouncingScrollPhysics(),
                        itemBuilder: (context, index) {
                          return message_card(message: list[index],);
                        },
                      );
                    }else{
                      return Center(child: Text("Say Hii! 👋",style: TextStyle(fontSize: 20),),);
                    }
                }
              },
            ),
          ),
          _chatInput(),
        ],
      ),
    );
  }

  Widget _appBar(){
    return InkWell(
      onTap: () {},
      child: Row(
        children: [
        Padding(
          padding:  EdgeInsets.only(top: 25),
          child: IconButton(onPressed: () {
              Navigator.pop(context);
          }, icon: Icon(Icons.arrow_back,color: Colors.black54,)),
        ),
        Padding(
          padding:EdgeInsets.only(top: 25),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(40),
            child: CachedNetworkImage(
              imageUrl:widget.user.email,
              placeholder:(context, url) => CircularProgressIndicator(),
              errorWidget: (context, url, error) => CircleAvatar(child: Icon(CupertinoIcons.person)),
            ),
          ),
        ),
          SizedBox(width: 10,),
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
            Padding(
              padding:EdgeInsets.only(top: 27,),
              child: Text(widget.user.name,style: TextStyle(fontSize: 16,color: Colors.black,fontWeight: FontWeight.bold),),
            ),
              Text("Last seen not available",style: TextStyle(fontSize: 16,color: Colors.black54,fontWeight: FontWeight.w500),)

            ],)
      ],
      ),
    );
  }

  Widget _chatInput(){
    return Row(
      children: [
        Expanded(
          child: Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
            child: Row(
              children: [
                IconButton(onPressed: () {

                }, icon: Icon(Icons.emoji_emotions,color: Colors.blueAccent,)),
                Expanded(
                    child:TextField(
                      controller: _textcontroller,
                      keyboardType: TextInputType.multiline,
                      maxLines: null,
                      decoration: InputDecoration(
                        hintText: 'Type Somthing....',
                        hintStyle: TextStyle(color: Colors.blueAccent),
                        border: InputBorder.none,
                      ),
                    ),
                ),
                IconButton(onPressed: () {

                }, icon: Icon(Icons.image,color: Colors.blueAccent,)),
                IconButton(onPressed: () {

                }, icon: Icon(Icons.camera_alt_rounded,color: Colors.blueAccent,))
              ],
            ),
          ),
        ),
        MaterialButton(
          onPressed: () {
              if(_textcontroller.text.isNotEmpty){
                APIs.sendMessage(widget.user, _textcontroller.text);
                _textcontroller.text = '';
              }
          },
          minWidth: 0,
          padding:EdgeInsets.only(top: 10,bottom: 10,right: 5,left: 10),
          shape: CircleBorder(),
          color: Colors.green,
          child: Icon(Icons.send,color: Colors.white,size: 28,),
        )
      ],
    );
  }

}
