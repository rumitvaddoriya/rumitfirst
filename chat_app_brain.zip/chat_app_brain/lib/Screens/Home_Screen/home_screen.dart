import 'package:chat_app_brain/Profile_Screen/profile_screen.dart';
import 'package:chat_app_brain/api/Apis.dart';
import 'package:chat_app_brain/models/chat_user.dart';
import 'package:chat_app_brain/wigets/user_chat_card.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';

class home_screen extends StatefulWidget {
  const home_screen({Key? key}) : super(key: key);

  @override
  State<home_screen> createState() => _home_screenState();
}

class _home_screenState extends State<home_screen> {

  TextEditingController serchcontroller = TextEditingController();

  //all user store
  List<ChatUser> list = [];

  //store serch item
  final List<ChatUser> serchlist = [];
  //serch store status
  bool _isserching = false;

  @override
  void initState() {
    super.initState();
    APIs.getSelfInfo();
    APIs.getAlluser();
  }

  @override
  Widget build(BuildContext context)  {
    return Scaffold(
      appBar: AppBar(
        leading: Icon(CupertinoIcons.home,color: Colors.black,),
        centerTitle: true,
        elevation: 1,
        title:_isserching ? TextField(
          controller: serchcontroller,
          decoration: InputDecoration(
            border: InputBorder.none,
            hintText: 'Name, Email..',),
          autofocus: true,
          style: TextStyle(fontSize: 16,letterSpacing: 0.5),
          onChanged: (value){
            serchlist.clear();
            for(var i in list){
              if(i.name.toLowerCase().contains(value.toLowerCase()) || i.email.toLowerCase().contains(value.toLowerCase())){
                serchlist.add(i);
              }
              setState(() {
                serchlist;
              });
            }
          },
        ) : Text("chat App",style:TextStyle(color: Colors.black,fontWeight: FontWeight.normal,fontSize: 19),),
        backgroundColor: Colors.white,
        actions: [
          IconButton(onPressed:() {
            setState(() {
              _isserching = !_isserching;
            });
          }, icon: Icon(_isserching ? CupertinoIcons.clear_circled_solid :  Icons.search,color: Colors.black,)),
          IconButton(onPressed:() {
            Navigator.push(context, MaterialPageRoute(builder: (context) {
              return profile_screen(user: APIs.me);
            },));
          }, icon: Icon(Icons.more_vert,color: Colors.black,)),
        ],
      ),
      floatingActionButton: Padding(
        padding: EdgeInsets.only(bottom: 10),
        child: FloatingActionButton(
          onPressed: () async {
            await APIs.auth.signOut();
            await GoogleSignIn().signOut();
          },
          child: Icon(Icons.add_comment_rounded),
        ),
      ),
      body:StreamBuilder(
        stream:APIs.getAlluser(),
        builder: (context,snapshot) {
          switch(snapshot.connectionState){
            case ConnectionState.waiting:
            case ConnectionState.none:
              return Center(child: CircularProgressIndicator(),);
            case ConnectionState.active:
            case ConnectionState.done:
              final data = snapshot.data?.docs;
              list = data?.map((e) => ChatUser.fromJson(e.data())).toList() ?? [];
          }
          if(list.isNotEmpty){
            return ListView.builder(
              itemCount:!_isserching || serchcontroller.text.isEmpty ? list.length : serchlist.length,
              physics: BouncingScrollPhysics(),
              itemBuilder: (context, index) {
                return UserChatCard(user:!_isserching || serchcontroller.text.isEmpty? list[index] : serchlist[index]);
              },
            );
          }else{
            return Center(child: Text("Not Connection Found!",style: TextStyle(fontSize: 20),),);
          }
        },
      ),
    );
  }
}
