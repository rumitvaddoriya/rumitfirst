import 'dart:async';
import 'dart:developer';
import 'package:chat_app_brain/Screens/Home_Screen/home_screen.dart';
import 'package:chat_app_brain/Screens/auth/Login_Screen.dart';
import 'package:chat_app_brain/api/Apis.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class splash_screen extends StatefulWidget {
  const splash_screen({Key? key}) : super(key: key);

  @override
  State<splash_screen> createState() => _splash_screenState();
}

class _splash_screenState extends State<splash_screen> {
  
  @override
  void initState() {
  super.initState();
  Future.delayed(Duration(seconds: 2),(){
    if(APIs.auth.currentUser != null){
      log("---------------->\nUser: ${FirebaseAuth.instance.currentUser}");
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => home_screen(),));
    }else{
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => login_screen(),));
    }
  });
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Text("Start to Chat App",style: TextStyle(fontSize: 25,color: Colors.pink),),
      ),
    );
  }

}
