

class UserModel {
  UserModel({
    this.uid,
    this.fullname,
    this.email,
    this.profilepic,
  });

  String? uid;
  String? fullname;
  String? email;
  String? profilepic;

  factory UserModel.fromMap(Map<String, dynamic> map) => UserModel(
    uid: map["uid"],
    fullname: map["fullName"],
    email: map["email"],
    profilepic: map["profilepic"],
  );

  Map<String, dynamic> toMAp() => {
    "uid": uid,
    "fullname": fullname,
    "email": email,
    "profilepic": profilepic,
  };
}
