package com.example.demo_rumit;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
