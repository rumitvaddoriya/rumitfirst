import 'package:demo_rumit/HomeScreen/home_screen_controller.dart';
import 'package:demo_rumit/StaticData/static.dart';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';

class AddDataController extends GetxController{

  TextEditingController nameController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController phoneController = TextEditingController();

  submitData(){
    demoList.value.add(
      ModelList(
        name: nameController.text,
        email: emailController.text,
        phone: phoneController.text,
      ),
    );
    Get.back();
  }

}