import 'package:demo_rumit/AddData/add_data_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class AddData extends StatelessWidget {
  AddData({Key? key}) : super(key: key);

  final AddDataController addDataController = Get.put(AddDataController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Add Data"),
      ),
      body: Column(
        children: [
          const SizedBox(height: 10.0,),
          TextFormField(
            controller: addDataController.nameController,
            decoration: const InputDecoration(
              hintText: "Name"
            ),
          ),
          const SizedBox(height: 10.0,),
          TextFormField(
            controller: addDataController.emailController,
            decoration: const InputDecoration(
              hintText: "Email"
            ),
          ),
          const SizedBox(height: 10.0,),
          TextFormField(
            controller: addDataController.phoneController,
            decoration: const InputDecoration(
              hintText: "Phone"
            ),
          ),
          const SizedBox(height: 10.0,),
          ElevatedButton(
            onPressed: () {
              addDataController.submitData();
          }, child: const Text("Submit"))
        ],
      ),
    );
  }
}
