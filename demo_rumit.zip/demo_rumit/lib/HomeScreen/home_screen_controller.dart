import 'package:demo_rumit/AddData/add_data.dart';
import 'package:get/get.dart';

class HomeScreenController extends GetxController{
  
  navigateToPage(){
    Get.to(()=>AddData())!.then((value) {
      update();
    });
  }
  
}