import 'package:demo_rumit/HomeScreen/home_screen_controller.dart';
import 'package:demo_rumit/StaticData/static.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class HomeScreen extends StatelessWidget {
   HomeScreen({Key? key}) : super(key: key);

  final HomeScreenController homeScreenController = Get.put(HomeScreenController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("demo"),
      ),
      body: GetBuilder<HomeScreenController>(
        init: HomeScreenController(),
        builder: (homeScreenController)=>ListView.builder(
            itemCount: demoList.value.length,
            itemBuilder: (context, index) {
              return Container(
                padding: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 10.0),
                margin: const EdgeInsets.all(8.0),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10.0),
                    color: Colors.orangeAccent.withOpacity(0.5)
                ),
                child: Row(
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children:  [
                        Text(demoList.value[index].name),
                        Text(demoList.value[index].email),
                        Text(demoList.value[index].phone),
                      ],
                    ),
                    const Spacer(),
                    IconButton(onPressed: () {

                    }, icon: const Icon(Icons.edit)),
                    IconButton(onPressed: () {
                      demoList.value.removeAt(index);
                      homeScreenController.update();
                    }, icon: const Icon(Icons.delete))
                  ],
                ),
              );
            },)),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          homeScreenController.navigateToPage();
      },),
    );
  }
}
