import 'package:get/get.dart';

RxList<ModelList> demoList = RxList();

class ModelList{
  String name;
  String email;
  String phone;

  ModelList({required this.name, required this.email, required this.phone});
}