class Photo {
  int? id;
  // ignore: non_constant_identifier_names
  String? name;
  int ?phone;


  Photo(  this.name, this.phone,);

  Map<String, dynamic> toMap() {
    var map = <String, dynamic>{
      'name': name,
      'phone' : phone,
    };
    return map;
  }

  Photo.fromMap(Map<dynamic, dynamic> map) {
    id = map['id'];
    name = map['name'].toString();
    phone = map['phone'];

  }
}