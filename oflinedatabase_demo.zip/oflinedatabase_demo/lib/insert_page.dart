import 'package:flutter/material.dart';
import 'database.dart';
import 'main.dart';
import 'model.dart';

class insert extends StatefulWidget {
  const insert({Key? key}) : super(key: key);

  @override
  State<insert> createState() => _insertState();
}

class _insertState extends State<insert> {
  TextEditingController t1 = TextEditingController();
  TextEditingController t2 = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey,
      appBar: AppBar(),
      body: Column(
        children: [
          SizedBox(height: 40,),
          Center(child: Text("Insert data",style: TextStyle(fontSize: 25,fontWeight: FontWeight.bold,color: Colors.black),)),
          SizedBox(height: 30,),
          TextField(
            controller: t1,
            decoration: InputDecoration(
              border: OutlineInputBorder(),
              labelText: "Enter Name",
            ),
          ),
          SizedBox(height: 20,),
          TextField(
            controller: t2,
            decoration: InputDecoration(
              border: OutlineInputBorder(),
                labelText: "Enter Number",
            ),
          ),
          SizedBox(height: 20,),
          ElevatedButton(onPressed: () async {
            dbHelperPhoto = DBHelperPhoto();
            Photo photo = Photo(t1.text.toString(),int.parse(t2.text.toString()));
            dbHelperPhoto!.save(photo);
              Navigator.pop(context);
          }, child: Text("Save"))
        ],
      ),
    );
  }
}
