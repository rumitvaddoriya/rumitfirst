import 'dart:async';
import 'dart:io' as io;
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

import 'model.dart';


class DBHelperPhoto {
  Database? _db;
  static const String ID = 'id';
  static const String NAME = 'name';
  static const String PHONE = 'phone';
  static const String TABLE = 'History';
  static const String DB_NAME = 'status.db';

  Future<Database> get db async {
    if (null != _db) {
      return _db!;
    }
    _db = await initDb();
    return _db!;
  }

  initDb() async {
    io.Directory documentsDirectory = await getApplicationDocumentsDirectory();
    String path = join(documentsDirectory.path, DB_NAME);
    print(path);
    var db = await openDatabase(path, version: 1, onCreate: _onCreate);
    return db;
  }

  _onCreate(Database db, int version) async {
    await db.execute("CREATE TABLE $TABLE ($ID INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,"
        " $NAME TEXT, $PHONE INTEGER)");
  }
//PRIMARY KEY AUTOINCREMENT
  Future<Photo> save(Photo img) async {
    var dbClient = await db;
    img.id = await dbClient.insert(TABLE, img.toMap());
    return img;

  }

  // Future<int> delete(int img)async{
  //   var dbClient = await db;
  //   img = await dbClient.delete(TABLE, where: 'id = ? ', whereArgs: [img]);
  //   return img;
  // }
  //
  //
  // Future<int>  updateData(int id,String name) async {
  //   var dbClient = await db;
  //   int res =
  //   await dbClient.rawUpdate('UPDATE '+TABLE+' SET $NAME = ?  WHERE cid = ?', [NAME, id]);
  //   return res;
  // }

  // Future<Photo> update(
  //     Photo save,
  //     int? id,
  //     ) async {
  //  var dbClient = await db;
  //   await dbClient.update(TABLE, save.toMap(),
  //       where: "$ID = ?", whereArgs: [save.id,id]);
  //   return save;
  // }

  Future<int> update(Photo photo, int id) async {
    final dbClient = await db;
    var res = await dbClient.update(TABLE, photo.toMap(),
        where: "id = ?", whereArgs: [id]);
    return res;
  }

  Future<int> delete(int idForUse) async {
    var dbClient = await db;
    int id = await dbClient.delete(TABLE, where: '$ID = ? ', whereArgs: [idForUse]);
    return id;
  }

  Future<List<Photo>> getPhotos() async {
    var dbClient = await db;
    List<Map> maps = await dbClient.query(TABLE, columns: [ID, NAME, PHONE]);
    List<Photo> imgs = [];
    if (maps.length > 0) {
      for (int i = 0; i < maps.length; i++) {
        imgs.add(Photo.fromMap(maps[i]));
      }
    }
    return imgs;
  }


  Future close() async {
    var dbClient = await db;
    dbClient.close();
  }

}
