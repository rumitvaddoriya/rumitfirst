import 'package:flutter/material.dart';
import 'package:oflinedatabase_demo/model.dart';

import 'main.dart';

class edit extends StatefulWidget {
  String name;
  int phone;
  int id;

   edit({
    required this.name,
      required this.phone,required this.id
});

  @override
  State<edit> createState() => _editState();
}

class _editState extends State<edit> {

  TextEditingController t1 = TextEditingController();
  TextEditingController t2 = TextEditingController();

  @override
  void initState() {
    super.initState();
    t1.text = widget.name;
    t2.text = widget.phone.toString();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey,
      appBar: AppBar(),
      body: Column(
        children: [
          SizedBox(height: 40,),
          Center(child: Text("Update data",style: TextStyle(fontSize: 25,fontWeight: FontWeight.bold,color: Colors.black),)),
          SizedBox(height: 30,),
          TextField(
            controller: t1,
            decoration: InputDecoration(
              border: OutlineInputBorder(),
              labelText: "Enter Name",
            ),
          ),
          SizedBox(height: 20,),
          TextField(
            controller: t2,
            decoration: InputDecoration(
              border: OutlineInputBorder(),
              labelText: "Enter Number",
            ),
          ),
          SizedBox(height: 20,),
          ElevatedButton(onPressed: () async {
            dbHelperPhoto?.update(Photo(t1.text.toString(),int.parse(t2.text.toString())),widget.id);
            //dbHelperPhoto.update(Photo( widget.itemId,t1.text.toString(), int.parse(t2.text.toString())));
            Navigator.pop(context,MaterialPageRoute(builder: (context) => first(),));
          }, child: Text("Update"))
        ],
      ),
    );
  }
}
