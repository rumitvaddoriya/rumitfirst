import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:oflinedatabase_demo/Edit_page.dart';
import 'package:oflinedatabase_demo/insert_page.dart';
import 'package:oflinedatabase_demo/model.dart';

import 'database.dart';

DBHelperPhoto? dbHelperPhoto;
List<Photo> datalist=[];

void main(){
  runApp(MaterialApp(debugShowCheckedModeBanner: false,home: first(),));
}

class first extends StatefulWidget {
  const first({Key? key}) : super(key: key);

  @override
  State<first> createState() => _firstState();
}
class _firstState extends State<first> {

  initdb2() {
    dbHelperPhoto = DBHelperPhoto();
    dbHelperPhoto!.getPhotos().then((value){
      setState(() {
        datalist.clear();
        datalist.addAll(value);
      });
    });
  }


  @override
  void initState() {
    super.initState();
    initdb2();
  }

  @override
  Widget build(BuildContext context) {
    final data = List<String>.generate(datalist.length, (i) => "data ${i + 1}");
    return Scaffold(
      backgroundColor: Colors.grey,
      appBar: AppBar(title: Text("List Demo"),actions: [IconButton(onPressed: () {
        Navigator.push(context, MaterialPageRoute(builder: (context) => insert()));
      }, icon: Icon(Icons.add))],),
      body: datalist.length==0 ? Container() :
      ListView.builder(
        itemCount: data.length,itemBuilder: (context, index) {

        final delete = data[index];
        initdb2();
        return InkWell(
          onTap: () {
            Navigator.push(context, MaterialPageRoute(builder: (context) => edit(name: datalist[index].name!,phone: datalist[index].phone!,id: datalist[index].id!,)));
          },

          child: Dismissible(
            key: Key(datalist[index].name!),
            onDismissed:(direction){
              if (direction == DismissDirection.endToStart) {
                datalist.removeAt(
                  datalist.indexWhere(
                        (element) => element.name == datalist[index].name,
                  ),
                );
                dbHelperPhoto?.delete(datalist[index].id!);
              }
            },

            child: ListTile(
              leading: Text("${datalist[index].id}"),
              title: Text("${datalist[index].name}"),
              subtitle: Text("${datalist[index].phone}"),
            ),
            background: Container(
              color: Colors.red,
            ),
          ),
        );
      },),
    );
  }
}
