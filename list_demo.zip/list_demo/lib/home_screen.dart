import 'package:flutter/material.dart';
import 'package:list_demo/model.dart';
import 'package:list_demo/view_screen.dart';

class HomeScreen extends StatefulWidget {
   HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {

  List<CheckBoxModel> showList = [
    CheckBoxModel(name: "Surat", isCheck: false),
    CheckBoxModel(name: "Ahemdabad", isCheck: false),
    CheckBoxModel(name: "Vapi", isCheck: false),
    CheckBoxModel(name: "Valsad", isCheck: false),
    CheckBoxModel(name: "Navsari", isCheck: false),
    CheckBoxModel(name: "Bharuch", isCheck: false),
    CheckBoxModel(name: "Ankleshver", isCheck: false),
    CheckBoxModel(name: "Junagath", isCheck: false),
    CheckBoxModel(name: "Daman", isCheck: false),
    CheckBoxModel(name: "Diu", isCheck: false),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Home"),
      ),
      body: ListView.builder(
        itemCount: showList.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(showList[index].name),
            trailing: Checkbox(
              value: showList[index].isCheck,
              onChanged: (value) {
                if(showList[index].isCheck){
                  showList[index].isCheck = value!;
                } else{
                  showList[index].isCheck = value!;
                }
                setState(() {});
            },),
          );
      },),
      floatingActionButton: FloatingActionButton(onPressed: () {
        Navigator.push(context, MaterialPageRoute(builder: (context) => ViewScreen(showList),));
      },child: const Text("Result"),),
    );
  }
}
