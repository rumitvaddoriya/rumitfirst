class CheckBoxModel{
  String name;
  bool isCheck;

  CheckBoxModel({required this.name, required this.isCheck});
}