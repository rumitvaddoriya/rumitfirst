import 'package:flutter/material.dart';
import 'package:list_demo/home_screen.dart';

void main(){
  runApp(MaterialApp(
    home: HomeScreen(),
  ));
}
