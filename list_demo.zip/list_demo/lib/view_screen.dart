import 'package:flutter/material.dart';
import 'package:list_demo/model.dart';

class ViewScreen extends StatefulWidget {
  List<CheckBoxModel> resultList = [];
  ViewScreen(this.resultList);

  @override
  State<ViewScreen> createState() => _ViewScreenState();
}

class _ViewScreenState extends State<ViewScreen> {
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("View"),
      ),
      body: ListView.builder(
        itemCount: widget.resultList.length,
        itemBuilder: (context, index) {
          List temp = [];
          for(int i = 0 ; i < widget.resultList.length ; i++){
            if(widget.resultList[i].isCheck == true){
              temp.add(widget.resultList[i].name);
            }
          }
          temp.shuffle();
          return widget.resultList[index].isCheck == true ? ListTile(
            title: Text(temp.join(", ")),
          ) : const SizedBox();
      },),
    );
  }
}
