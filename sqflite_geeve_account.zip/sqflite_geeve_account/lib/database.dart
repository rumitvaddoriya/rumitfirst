import 'package:sqflite/sqflite.dart';
import 'package:sqflite/sqlite_api.dart';
import 'dart:io' as io;
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite_geeve_account/model/model.dart';

class DBHelper{

  Database? _db;

  static const String ID = 'id';
  static const String FIRSTNAME = 'firstname';
  static const String LASTNAME = 'lastname';
  static const String PHONE = 'phone';
  static const String EMAIL = 'email';
  static const String PASSWORD = 'password';
  static const String CPASSWORD = 'cpassword';
  static const String TABLE = 'History';
  static const String DB_NAME = 'status.db';

  Future<Database> get db async {
    if (null != _db) {
      return _db!;
    }
    _db = await initDb();
    return _db!;
  }

  initDb() async {
    io.Directory documentsDirectory = await getApplicationDocumentsDirectory();
    String path = join(documentsDirectory.path, DB_NAME);
    print(path);
    var db = await openDatabase(path, version: 1, onCreate: _onCreate);
    return db;
  }

  _onCreate(Database db, int version) async {
    await db.execute("CREATE TABLE $TABLE ($ID INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,"
        " $FIRSTNAME TEXT, $LASTNAME TEXT, $PHONE TEXT, $EMAIL TEXT, $PASSWORD TEXT, $CPASSWORD TEXT)");
  }

  //PRIMARY KEY AUTOINCREMENT
  //, LASTNAME, PHONE, EMAIL, PASSWORD, CPASSWORD

  Future<Data> save(Data data) async {
    var dbClient = await db;
    data.id = await dbClient.insert(TABLE, data.toMap());
    return data;
  }

  Future<List<Data>> getData() async {
    var dbClient = await db;
    List<Map> maps = await dbClient.query(TABLE, columns: [ID, FIRSTNAME, LASTNAME, PHONE, EMAIL, PASSWORD, CPASSWORD]);
    List<Data> datas = [];
    if (maps.length > 0) {
      for (int i = 0; i < maps.length; i++) {
        datas.add(Data.fromMap(maps[i]));
      }
    }
    return datas;
  }

  Future<int> update(Data data, String email) async {
    final dbClient = await db;
    var res = await dbClient.update(TABLE, data.toMap(),
        where: "email = ?", whereArgs: [email]);
    return res;
  }

  Future<int> delete(int idForUse) async {
    var dbClient = await db;
    int id = await dbClient.delete(TABLE, where: '$ID = ? ', whereArgs: [idForUse]);
    return id;
  }


  Future close() async {
    var dbClient = await db;
    dbClient.close();
  }

}