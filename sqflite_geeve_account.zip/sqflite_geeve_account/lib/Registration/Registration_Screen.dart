import 'package:flutter/material.dart';
import 'package:sqflite_geeve_account/phone_verifications/phone_veridications.dart';
import 'package:sqflite_geeve_account/suggations/Suggetions_screen.dart';

class Registration_Screen extends StatefulWidget {
  const Registration_Screen({Key? key}) : super(key: key);

  @override
  State<Registration_Screen> createState() => _Registration_ScreenState();
}

class _Registration_ScreenState extends State<Registration_Screen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor:Color(0xfffa7914),
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
              bottomRight: Radius.circular(25),
              topLeft: Radius.circular(25),
              topRight: Radius.circular(25)),
        ),
        centerTitle: true,
        title:Text("Registration",style: TextStyle(fontSize: 20,color: Colors.white,fontFamily: 'FontsFree'),),
      ),
        body: Column(
          children: [
            SizedBox(height: 100,),
            Center(child: Text("I am a",style: TextStyle(fontSize: 15,fontFamily: 'FontsFree',color: Color(0xff7d7f86),),),),
            Center(child: SizedBox(height: 10,)),
            Row(
              mainAxisAlignment:MainAxisAlignment.center,
              children: [
              Container(
                height: 130,
                width: 130,
                child: Center(child: Text("Donor",style: TextStyle(fontSize: 20,color:Color(0xfffa7914),fontFamily: 'FontsFree'),),),
                decoration: BoxDecoration(
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.1),
                      offset: Offset(3,0),
                      blurRadius: 5,
                    ),
                  ],
                  color: Colors.white,
                  borderRadius: BorderRadius.all(Radius.circular(100)),
                ),
              ),
                SizedBox(width: 30,),
                Container(
                  height: 140,
                  width: 140,
                  child: Center(child: Text("Donee",style: TextStyle(fontSize: 20,color:Color(0xfffa7914),fontFamily: 'FontsFree'),),),
                  decoration: BoxDecoration(
                  boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.40),blurRadius: 5,offset: const Offset(1, 0)),],
                    border: Border.all(width: 9,color:Color(0xfffa7914)),
                    color: Colors.white,
                    borderRadius: BorderRadius.all(Radius.circular(100)),
                  ),
                ),
            ],),
            SizedBox(height: 20,),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                GestureDetector(
                  onTap: () {
                    Navigator.push(context, MaterialPageRoute(builder: (context) {
                          return Suggetions_screen();
                    },));
                  },
                  child: InkWell(
                    onTap: () {
                      Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) {
                        return phone_verifications();
                      },));
                    },
                    child: Container(
                      height: 100,
                      width: 100,
                      child: Center(child: Text("Go",style: TextStyle(fontSize: 20,color:Colors.white,fontFamily: 'FontsFree'),),),
                      decoration: BoxDecoration(
                        color:Color(0xfffa7914),
                        borderRadius: BorderRadius.all(Radius.circular(100)),
                      ),
                    ),
                  ),
                ),
               Container(
                 height: 70,
                 width: 20,
                 decoration: BoxDecoration(image: DecorationImage(image: AssetImage("images/btn-arow.png"),fit: BoxFit.fill)),
               )
              ],
            ),
            SizedBox(height: 60,),
            Container(
              height:150,
              width: double.infinity,
              decoration: BoxDecoration(image: DecorationImage(image: AssetImage("images/Layer 7.png"),fit: BoxFit.fill)),
            ),
          ],
        ),
      drawer: Drawer(
        backgroundColor: Color(0xFFffffff),
        child: ListView(
          padding: const EdgeInsets.all(0),
          children: [
            Container(
              height: 200,
              width: double.infinity,
              color: Color(0xFFffffff),
              child: Column(
                children: [
                  Center(child: SizedBox(height: 30,),),
                  Center(
                    child: Container(
                      height: 90,
                      width: 90,
                      child: Padding(
                        padding: EdgeInsets.all(13),
                        child: Image.asset("images/Layer 45.png",height: 20,width: 20,),
                      ),
                      decoration: BoxDecoration(
                        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.20),blurRadius: 5,offset: const Offset(1, 0)),],
                          color: Colors.white,
                          borderRadius: BorderRadius.all(Radius.circular(100)),
                      ),
                    ),
                  ),
                  SizedBox(height: 10,),
                  Row(children: [
                    Padding(
                      padding: EdgeInsets.only(left: 10),
                      child: Container(
                        height:30,
                        width: 30,
                        decoration: BoxDecoration(borderRadius: BorderRadius.all(Radius.circular(100)), image: DecorationImage(image: AssetImage("images/Layer 34.png"),),),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(left: 10),
                      child: Text(
                        "Jesus House Toronto",
                        style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold,fontFamily: 'FontsFree',),
                      ),
                    ),
                  ],),
                  Padding(
                    padding:EdgeInsets.only(left: 10,right: 50),
                    child: Text("asma@jesushouse.com",style: TextStyle(color: Color(0xff7d7f86),fontFamily: 'FontsFree'),),
                  )
                ],
              ),
            ),
            Container(
              height: 50,
              width: 300,
              decoration: BoxDecoration(border: Border(top: BorderSide(width: 0.5, color: Colors.black26), bottom: BorderSide(width: 0.5, color: Colors.black26),)),
              child: Row(children: [
                  Padding(
                    padding:  EdgeInsets.only(left: 25),
                    child: Container(
                              height: 25,
                              width: 25,
                              child: Image.asset("images/Layer 36.png"),
                    ),
                  ),
                Padding(
                  padding: EdgeInsets.only(left: 20),
                  child: Center(child: Text('Dashboard',style: TextStyle(fontSize: 17,color:Color(0xfffa7914),fontFamily: 'FontsFree'),)),
                )
              ]),
            ),

            Container(
              height: 50,
              width: 300,
              decoration: BoxDecoration(border: Border(bottom: BorderSide(width: 0.5, color: Colors.black26),)),
              child: Row(children: [
                Padding(
                  padding:  EdgeInsets.only(left: 25),
                  child: Container(
                    height: 25,
                    width: 25,
                    child: Image.asset("images/Layer 37.png"),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(left: 20),
                  child: Center(child: Text('Donations Pages',style: TextStyle(fontSize: 17,color:Color(0xff7d7f86),fontFamily: 'FontsFree'),)),
                )
              ]),
            ),

            Container(
              height: 50,
              width: 300,
              decoration: BoxDecoration(border: Border(bottom: BorderSide(width: 0.5, color: Colors.black26),)),
              child: Row(children: [
                Padding(
                  padding:  EdgeInsets.only(left: 25),
                  child: Container(
                    height: 25,
                    width: 25,
                    child: Image.asset("images/Layer 39.png"),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(left: 20),
                  child: Center(child: Text('Text 2 Give',style: TextStyle(fontSize: 17,color:Color(0xff7d7f86),fontFamily: 'FontsFree'),)),
                )
              ]),
            ),

            Container(
              height: 50,
              width: 300,
              decoration: BoxDecoration(border: Border(bottom: BorderSide(width: 0.5, color: Colors.black26),)),
              child: Row(children: [
                Padding(
                  padding:  EdgeInsets.only(left: 25),
                  child: Container(
                    height: 25,
                    width: 25,
                    child: Image.asset("images/Layer 42.png",),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(left: 20),
                  child: Center(child: Text('Transactions',style: TextStyle(fontSize: 17,color:Color(0xff7d7f86),fontFamily: 'FontsFree'),)),
                )
              ]),
            ),

            Container(
              height: 50,
              width: 300,
              decoration: BoxDecoration(border: Border(bottom: BorderSide(width: 0.5, color: Colors.black26),)),
              child: Row(children: [
                Padding(
                  padding:  EdgeInsets.only(left: 25),
                  child: Container(
                    height: 25,
                    width: 25,
                    child: Image.asset("images/Layer 40.png"),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(left: 20),
                  child: Center(child: Text('Analytics',style: TextStyle(fontSize: 17,color:Color(0xff7d7f86),fontFamily: 'FontsFree'),)),
                )
              ]),
            ),

            Container(
              height: 50,
              width: 300,
              decoration: BoxDecoration(border: Border(bottom: BorderSide(width: 0.5, color: Colors.black26),)),
              child: Row(children: [
                Padding(
                  padding:  EdgeInsets.only(left: 25),
                  child: Container(
                    height: 25,
                    width: 25,
                    child: Image.asset("images/Layer 41.png"),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(left: 20),
                  child: Center(child: Text('Settings',style: TextStyle(fontSize: 17,color:Color(0xff7d7f86),fontFamily: 'FontsFree'),)),
                )
              ]),
            ),

            SizedBox(height: 20,),
            Container(
              margin: EdgeInsets.all(40),
              height: 50,
              width: 140,
              child:Center(child: Text("Logout",style: TextStyle(fontSize: 20,color:Colors.white,fontFamily: 'FontsFree'),),),
              decoration: BoxDecoration(color: Color(0xfffa7914),borderRadius: BorderRadius.all(Radius.circular(50),),boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.40),blurRadius:5,offset: const Offset(1, 0)),]),
            ),
          ],
        ),
      ), //Drawer

    );
  }
}
