class Data{

  int? id;
  // ignore: non_constant_identifier_names
  String? firstname;
   String? lastname;
   String ? phone;
  String? email;
  String? password;
  String? cpassword;

  Data(this.firstname,this.lastname,this.phone,this.email,this.password,this.cpassword);
  // this.lastname,this.phone,this.email,this.password,this.cpassword

  Map<String, dynamic> toMap() {
    var map = <String, dynamic>{
      'firstname': firstname,
       'lastname': lastname,
      'phone': phone,
       'email': email,
      'password': password,
      'cpassword': cpassword,
    };
    return map;
  }

  Data.fromMap(Map<dynamic, dynamic> map) {
    id = map['id'];
    firstname = map['firstname'].toString();
    lastname = map['lastname'].toString();
     phone = map['phone'].toString();
    email = map['email'].toString();
    password = map['password'].toString();
    cpassword = map['cpassword'].toString();
  }

}