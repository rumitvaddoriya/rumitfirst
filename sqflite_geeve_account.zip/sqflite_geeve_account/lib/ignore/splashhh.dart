import 'package:flutter/material.dart';
void main() {
  runApp(myApp());
}
class myApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(
        primarySwatch: Colors.deepOrange,
      ),
      home: HomePage(),
      debugShowCheckedModeBanner: false,
    );
  }
}
class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}
class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Calculator'),
      ),
      body: Container(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.end,
          children: <Widget>[
            Expanded(
              child: Container(
                padding: EdgeInsets.all(10.0),
                alignment: Alignment.bottomRight,
                child: Text(
                  text,
                  style: TextStyle(
                      fontSize: 60.0,
                      fontWeight: FontWeight.w500,
                      color: Colors.red),
                ),
              ),
            ),
            Row(
              children: <Widget>[
                customOutlineButton("9"),
                customOutlineButton("8"),
                customOutlineButton("7"),
                customOutlineButton("+"),
              ],
            ),
            Row(
              children: <Widget>[
                customOutlineButton("6"),
                customOutlineButton("5"),
                customOutlineButton("4"),
                customOutlineButton("-"),
              ],
            ),
            Row(
              children: <Widget>[
                customOutlineButton("3"),
                customOutlineButton("2"),
                customOutlineButton("1"),
                customOutlineButton("x"),
              ],
            ),
            Row(
              children: <Widget>[
                customOutlineButton("C"),
                customOutlineButton("0"),
                customOutlineButton("="),
                customOutlineButton("/"),
              ],
            ),
          ],
        ),
      ),
    );
  }
  Widget customOutlineButton(String val) {
    return Expanded(
      child: Padding(
        padding: EdgeInsets.all(25.0),
        child: ElevatedButton(
          onPressed: () => btnClicked(val),
          child: Text(
            val,
            style: TextStyle(fontSize: 35.0, color: Colors.grey),
          ),
        ),
      ),
    );
  }
  late int first, second;
  late String res, text = "";
  late String opp;
  void btnClicked(String btnText) {
    if (btnText == "C") {
      res = "";
      text = "";
      first = 0;
      second = 0;
    } else if (btnText == "+" ||
        btnText == "-" ||
        btnText == "x" ||
        btnText == "/") {
      first = int.parse(text);
      res = "";
      opp = btnText;
    } else if (btnText == "=") {
      second = int.parse(text);
      if (opp == "+") {
        res = (first + second).toString();
      }
      if (opp == "-") {
        res = (first - second).toString();
      }
      if (opp == "x") {
        res = (first * second).toString();
      }
      if (opp == "/") {
        res = (first ~/ second).toString();
      }
    } else {
      res = int.parse(text + btnText).toString();
    }
    setState(() {
      text = res;
    });
  }
}




// import 'package:flutter/material.dart';
//
// class splashh extends StatefulWidget {
//   const splashh({Key? key}) : super(key: key);
//
//   @override
//   State<splashh> createState() => _splashhState();
// }
//
// class _splashhState extends State<splashh> {
//
//   var size,height,width;
//   PageController  pageController = PageController();
//   int currentpage = 0;
//
//   List<Map<String,dynamic>> nameList = [
//     {"imageurl":"images/Layer 11.png","title":"Let's getstarted","description":"Nemo enim ipsam voluptatem quia voluptas sit aspernature aut odit aut fugit, sed quia consequuntur magni dolores"},
//     {"imageurl":"images/Layer 11.png","title":"Let's getstarted","description":"Nemo enim ipsam voluptatem quia voluptas sit aspernature aut odit aut fugit, sed quia consequuntur magni dolores"},
//     {"imageurl":"images/Layer 11.png","title":"Let's getstarted","description":"Nemo enim ipsam voluptatem quia voluptas sit aspernature aut odit aut fugit, sed quia consequuntur magni dolores"},
//   ];
//
//   _onpagechanged(int index){
//     setState(() {
//       currentpage = index;
//     });
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     size = MediaQuery.of(context).size;
//     height = size.height;
//     width = size.width;
//     return Scaffold(
//       body: Column(
//         children: [
//           Center(child: SizedBox(height: 50,)),
//           Container(
//             height:height/10,
//             width: width/2,
//             decoration: BoxDecoration(image: DecorationImage(image: AssetImage("images/Layer 8.png"),fit: BoxFit.fill)),
//           ),
//           Container(
//             height:height/,
//             width: width/2,
//             color: Colors.green,
//             child: PageView.builder(
//               controller: pageController,
//               onPageChanged:_onpagechanged,
//               itemCount: nameList.length,itemBuilder: (context, index) {
//               return Column(
//                 children: [
//                   SizedBox(height: 15,),
//                   Container(
//                     height: height/2,
//                     width: width*2,
//                     decoration: BoxDecoration(image: DecorationImage(image: AssetImage(nameList[index]['imageurl']),fit: BoxFit.fill)),
//                   ),
//                   SizedBox(height: 20,),
//                   Text(nameList[index]['title'],style: TextStyle(color: Color(0xff121212),fontSize: 20, fontFamily: 'FontsFree',),),
//                   SizedBox(height: 10,),
//                   SizedBox(
//                     width: 300,
//                     child:  Text(
//                       textAlign: TextAlign.center,
//                       nameList[index]['description'].toString(),
//                       style: TextStyle(
//                         color: Color(0xff7d7f86),
//                         fontSize: 14,
//                         fontFamily: 'FontsFree',
//                       ),
//                     ),
//                   ),
//                 ],
//               );
//             },),
//           ),
//           // SizedBox(height: 50,),
//           // InkWell(
//           //   onTap: () {
//           //     // Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) {
//           //     //   return Signup_Screen();
//           //     // },));
//           //   },
//           //   child: Container(
//           //     height: bodyheight*0.1,
//           //     width: width*0.75,
//           //     child: Center(child: Text("Create Account",style: TextStyle(fontSize: 16, fontFamily: 'FontsFree',color: Colors.white),),),
//           //     decoration: BoxDecoration(color: Color(0xfffa7914),borderRadius: BorderRadius.all(Radius.circular(50)),boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.40),blurRadius: 5,offset: const Offset(1, 0)),]),
//           //   ),
//           // ),
//           // SizedBox(height: 15,),
//           // GestureDetector(
//           //   onTap: () {
//           //     // Navigator.push(context, MaterialPageRoute(builder: (context) {
//           //     //   return Login_Screen();
//           //     // },));
//           //   },
//           //   child: Container(
//           //     height: bodyheight*0.1,
//           //     width: width*0.75,
//           //     child: Center(child: Text("Login",style: TextStyle(fontSize: 16,color: Color(0xfffa7914)),),),
//           //     decoration: BoxDecoration(color:Colors.white,borderRadius: BorderRadius.all(Radius.circular(50),),boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.1),blurRadius: 5,offset: const Offset(3, 0),),]),
//           //   ),
//           // ),
//           // SizedBox(height: 30,),
//           // Container(
//           //   height:bodyheight*0.1,
//           //   width: double.infinity,
//           //   decoration: BoxDecoration(image: DecorationImage(image: AssetImage("images/Layer 7.png"),fit: BoxFit.fill)),
//           // ),
//         ],
//       ),
//     );
//   }
// }
