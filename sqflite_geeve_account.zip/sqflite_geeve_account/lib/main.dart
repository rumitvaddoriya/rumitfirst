import 'package:flutter/material.dart';
import 'package:sqflite_geeve_account/Login/Login_Screen.dart';
import 'package:sqflite_geeve_account/Splash/Splash_Screen.dart';
import 'package:sqflite_geeve_account/database.dart';


void main(){
  runApp(
      MaterialApp(
        debugShowCheckedModeBanner: false,
        home: Login_Screen(),
      ),
  );
}
