import 'package:flutter/material.dart';
import 'package:sqflite_geeve_account/Registration/Registration_Screen.dart';
import 'package:sqflite_geeve_account/Signup/Signup_Screen.dart';
import 'package:sqflite_geeve_account/database.dart';
import 'package:sqflite_geeve_account/model/model.dart';
import 'package:sqflite_geeve_account/suggations/Suggetions_screen.dart';

class Login_Screen extends StatefulWidget {
  const Login_Screen({Key? key}) : super(key: key);

  @override
  State<Login_Screen> createState() => _Login_ScreenState();
}

class _Login_ScreenState extends State<Login_Screen> {

  TextEditingController emailcontroller = TextEditingController();
  TextEditingController passwordcontroller = TextEditingController();

  GlobalKey<FormState> formkey = GlobalKey<FormState>();
  bool passToggle = true;
  String password = "";
  bool name = false;
  bool check = false;
  bool pass = false;
  bool pass2 = false;
  List<Data> matchemail =[];
  DBHelper? dbHelper;
  int i = 0;

  getdata() {
    dbHelper = DBHelper();
    dbHelper!.getData().then((value){
      setState(() {
        // list.clear();
        matchemail.addAll(value);
        print("================>${matchemail}");
      });
    });
  }


  @override
  void initState() {
    getdata();
  }

  login  (){
    if(formkey.currentState!.validate()){
      check = false;
      for(int i=0; i< matchemail.length; i++){
        print("-----------> ${matchemail.length}");
        print("-----------> ${matchemail[i].email}");
        print("-----------> ${matchemail[i].password}");
        print("Ok");
        //   }
        if(matchemail[i].email==emailcontroller.text && matchemail[i].password==passwordcontroller.text){
          check = true;
          break;
        }
      }
      if(check){
        Navigator.push(context, MaterialPageRoute(builder: (context) => Suggetions_screen(),));
        emailcontroller.clear();
        passwordcontroller.clear();
      }else
      {
        if(matchemail[i].email!=emailcontroller.text){
          showDialog(context: context, builder: (context) {
            return AlertDialog(
              title: Text("Wrong Email !"),
            );
          },);
        }else{
          showDialog(context: context, builder: (context) {
            return AlertDialog(
              title: Text("Wrong Password !"),
            );
          },);
        }
      }
    }else{
      showDialog(context: context, builder: (context) {
        return AlertDialog(
          title: Text("Enter Some details"),
        );
      },);
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor:Color(0xFFffffff),
      body: SingleChildScrollView(
        child: Form(
          key: formkey,
          child: Column(
            children: [
              Center(child: SizedBox(height: 80,)),
              Container(
                height: 70,
                width: 150,
                decoration: BoxDecoration(image: DecorationImage(image: AssetImage("images/Layer 8.png"),fit: BoxFit.fill)),
              ),
              SizedBox(height: 50,),
              Padding(
                padding:  EdgeInsets.only(left: 45,right: 45),
                child: TextFormField(
                  controller:emailcontroller,
                  style: TextStyle(
                    fontSize: 15,
                    fontFamily: 'FontsFree',color: Colors.black),
                  decoration: InputDecoration(
                    border: InputBorder.none,
                    hintText: "Email",
                    filled: true,
                    prefixIcon: Icon(Icons.email_outlined,color:Colors.grey,),
                    fillColor: Color(0xfff6f6f6),
                    enabledBorder: OutlineInputBorder(
                      borderSide:
                      BorderSide(color: Color(0xfff6f6f6)),
                      borderRadius: BorderRadius.circular(50),
                    ),
                  ),
                  validator:(value) {
                    bool emailvalid = RegExp(r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`  {|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+").hasMatch(value!);
                    if(value!.isEmpty)
                    {
                      return 'Enter Email';
                    }else if(!emailvalid){
                       return "Enter Valid email";
                     }
                  },
                ),
              ),
              SizedBox(height:15,),
              Padding(
                padding:  EdgeInsets.only(left: 45,right: 45),
                child: TextFormField(
                  keyboardType: TextInputType.number,
                  controller:passwordcontroller,
                  style: TextStyle(
                    fontSize: 15,
                    fontFamily: 'FontsFree',color: Colors.black),
                  decoration: InputDecoration(
                    border: InputBorder.none,
                    hintText: "Password",
                    filled: true,
                    prefixIcon: Icon(Icons.key,color:Colors.grey,),
                    fillColor: Color(0xfff6f6f6),
                    enabledBorder: OutlineInputBorder(
                      borderSide:
                      BorderSide(color: Color(0xfff6f6f6)),
                      borderRadius: BorderRadius.circular(50),
                    ),
                  ),
                  validator: (value){
                    if(value == null || value.isEmpty)
                    {
                      return 'Please Enter Password';
                    }else if(value.length < 6)
                    {
                      return 'At Least 6 char required';
                    }
                    return null;
                  },
                ),
              ),
              SizedBox(height: 20,),
              Row(
                children: [
                  Container(
                     margin: EdgeInsets.only(left: 50),
                    height: 20,
                    width: 20,
                    decoration: BoxDecoration(color: Color(0xfff6f6f6),borderRadius: BorderRadius.all(Radius.circular(5))),
                  ),
                  SizedBox(width: 15,),
                  Text("Remember me",style: TextStyle(fontSize: 15,color: Color(0xff7d7f86),fontFamily: 'FontsFree',),),
                ],
              ),
              SizedBox(height: 25,),
              GestureDetector(
                onTap: () {
                  login();
                },
                child: Container(
                  height: 50,
                  width: 270,
                  child: Center(child: Text("Login",style: TextStyle(fontSize: 20,color: Colors.white),),),
                  decoration: BoxDecoration(color: Color(0xfffa7914),borderRadius: BorderRadius.all(Radius.circular(50),),boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.40),blurRadius:5,offset: const Offset(1, 0)),]),
                ),
              ),
             SizedBox(height: 20,),
             Row(
               mainAxisAlignment: MainAxisAlignment.end,
               children: [
                 Icon(Icons.lock,color: Color(0xfffa7914),size: 15,),
                 SizedBox(width: 5,),
                 Padding(
                   padding:EdgeInsets.only(right:40),
                   child: Text("Forget Password?",style: TextStyle(fontSize: 13,color:Color(0xfffa7914),),),
                 )
               ],
             ),
             SizedBox(height: 50  ,),
             InkWell(
               onTap: () {
                 Navigator.push(context, MaterialPageRoute(builder: (context) => Registration_Screen(),));
               },
                 child: Text("Don't have an account?",style: TextStyle(fontSize: 13,color: Color(0xff7d7f86),fontFamily: 'FontsFree',),)),
              SizedBox(height: 10,),
              InkWell(
                onTap: () {
                    Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) {
                      return Signup_Screen(null);
                    },));
                },
                child:Text("Sign Up",style: TextStyle(fontSize: 16,color:Color(0xfffa7914),fontFamily: 'FontsFree',),),),
              Container(
                height:108,
                width: double.infinity,
                decoration: BoxDecoration(image: DecorationImage(image: AssetImage("images/Layer 7.png"),fit: BoxFit.fill)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
