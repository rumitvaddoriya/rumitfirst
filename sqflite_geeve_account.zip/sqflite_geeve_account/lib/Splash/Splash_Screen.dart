import 'package:flutter/material.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';
import 'package:sqflite_geeve_account/suggations/Suggetions_screen.dart';
import '../Signup/Signup_Screen.dart';

class Splash_Screen extends StatefulWidget {
  const Splash_Screen({Key? key}) : super(key: key);

  @override
  State<Splash_Screen> createState() => _Splash_ScreenState();
}

class _Splash_ScreenState extends State<Splash_Screen> {
  @override

  var size,height,width;
  PageController  pageController = PageController();
  int currentpage = 0;

  List<Map<String,dynamic>> nameList = [
    {"imageurl":"images/Layer 11.png","title":"Let's getstarted","description":"Nemo enim ipsam voluptatem quia voluptas sit aspernature aut odit aut fugit, sed quia consequuntur magni dolores"},
    {"imageurl":"images/Layer 11.png","title":"Let's getstarted","description":"Nemo enim ipsam voluptatem quia voluptas sit aspernature aut odit aut fugit, sed quia consequuntur magni dolores"},
    {"imageurl":"images/Layer 11.png","title":"Let's getstarted","description":"Nemo enim ipsam voluptatem quia voluptas sit aspernature aut odit aut fugit, sed quia consequuntur magni dolores"},
  ];

  _onpagechanged(int index){
    setState(() {
      currentpage = index;
    });
  }

  Widget build(BuildContext context) {
    // var height = MediaQuery.of(context).size.height;
    // var width = MediaQuery.of(context).size.width;
    // print(height);
    //height*0.1091,  container hight 70/phonesize height = 678 == 0.1091
    return Scaffold(
      backgroundColor:Color(0xFFffffff),
      body: SingleChildScrollView(
        child: Column(
          children: [
              Center(child: SizedBox(height: 60,)),
            Container(
              height: 70,
              width: 150,
              decoration: BoxDecoration(image: DecorationImage(image: AssetImage("images/Layer 8.png"),fit: BoxFit.fill)),
            ),
            Container(
              height: 285,
              width: 350,
              child: PageView.builder(
                controller: pageController,
                onPageChanged:_onpagechanged,
                itemCount: nameList.length,itemBuilder: (context, index) {
                return Column(
                  children: [
                    SizedBox(height: 15,),
                    Container(
                      height: 160,
                      width: 230,
                      decoration: BoxDecoration(image: DecorationImage(image: AssetImage(nameList[index]['imageurl']),fit: BoxFit.fill)),
                    ),
                    SizedBox(height: 20,),
                    Text(nameList[index]['title'],style: TextStyle(color: Color(0xff121212),fontSize: 20, fontFamily: 'FontsFree',),),
                    SizedBox(height: 10,),
                    SizedBox(
                      width: 300,
                      child:  Text(
                        textAlign: TextAlign.center,
                        nameList[index]['description'].toString(),
                        style: TextStyle(
                          color: Color(0xff7d7f86),
                          fontSize: 14,
                          fontFamily: 'FontsFree',
                        ),
                      ),
                    ),
                  ],
                );
              },),
            ),
            SizedBox(height: 15,),
            SmoothPageIndicator(
                controller: pageController,  // PageController
                count: nameList.length,
                effect:  WormEffect(
                    dotColor:Colors.grey,
                    activeDotColor:Color(0xfffa7914),
                    dotWidth:  8,
                    dotHeight:  8,
                  spacing: 14,
                ),  // your preferred effect
            ),
            SizedBox(height: 40,),
            InkWell(
              onTap: () {
                Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) {
                  return Signup_Screen(null);
                },));
              },
              child: Container(
                height: 50,
                width: 270,
                child: Center(child: Text("Create Account",style: TextStyle(fontSize: 16, fontFamily: 'FontsFree',color: Colors.white),),),
                decoration: BoxDecoration(color: Color(0xfffa7914),borderRadius: BorderRadius.all(Radius.circular(50)),boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.40),blurRadius: 5,offset: const Offset(1, 0)),]),
              ),
            ),
            SizedBox(height: 15,),
            GestureDetector(
              onTap: () {
                Navigator.push(context, MaterialPageRoute(builder: (context) {
                  return Suggetions_screen();
                },));
              },
              child: Container(
                height: 50,
                width: 270,
                child: Center(child: Text("Login",style: TextStyle(fontSize: 16,color: Color(0xfffa7914)),),),
                decoration: BoxDecoration(color:Colors.white,borderRadius: BorderRadius.all(Radius.circular(50),),boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.1),blurRadius: 5,offset: const Offset(3, 0),),]),
              ),
            ),
            SizedBox(height: 5,),
            Container(
              height:80 ,
              width: double.infinity,
              decoration: BoxDecoration(image: DecorationImage(image: AssetImage("images/Layer 7.png"),fit: BoxFit.fill)),
            ),
          ],
        ),
      ),
    );
  }
}
