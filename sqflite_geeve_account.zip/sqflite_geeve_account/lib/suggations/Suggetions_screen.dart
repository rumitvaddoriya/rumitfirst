import 'package:flutter/material.dart';
import 'package:sqflite_geeve_account/Signup/Signup_Screen.dart';
import 'package:sqflite_geeve_account/database.dart';
import 'package:sqflite_geeve_account/model/model.dart';


class Suggetions_screen extends StatefulWidget {
  const Suggetions_screen({Key? key}) : super(key: key);

  @override
  State<Suggetions_screen> createState() => _Suggetions_screenState();
}

class _Suggetions_screenState extends State<Suggetions_screen> {

  TextEditingController Nonprofitcontroller = TextEditingController();
  List<Data> list = [];
  DBHelper? dbHelper;
  //blank list
  List finduser = [];


  @override
  void initState() {
    getdata();
    // blank list under listdata add karya
    finduser = list;
    super.initState();
  }

  getdata() {
    dbHelper = DBHelper();
    dbHelper!.getData().then((value){
      setState(() {
        list.addAll(value);
      });
    });
  }

  // serchbar function
  void _runFilter(String enteredKeyword) {
    // result show mate blank list
    List results = [];
    if (enteredKeyword.isEmpty) { // text khali hoy tyare
      results = list;
    } else {
      // result blank list ma add listdata check kare firstname...
      results = list
          .where((user) =>
          user.firstname!.toLowerCase().contains(enteredKeyword.toLowerCase()))
          .toList();
    }
    // Refresh the UI
    setState((){
      finduser = results;
    });
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(80),
          child:AppBar(
            automaticallyImplyLeading: false,
            elevation: 0,
            leading: GestureDetector(
              onTap: () {
                Navigator.push(context, MaterialPageRoute(builder: (context) {
                  return Signup_Screen(null);
                },));
              },
                child: Image.asset("images/icn menu.png"),
            ),
            backgroundColor:Color(0xfffa7914),
            shape: const RoundedRectangleBorder(
              borderRadius: BorderRadius.only(
                  bottomRight: Radius.circular(25),
                  topLeft: Radius.circular(25),
                  topRight: Radius.circular(25)),
            ),
            centerTitle: true,
            title: Padding(
              padding: EdgeInsets.only(top:5),
              child: Container(
                height: 50,
                width: 250,
                decoration: BoxDecoration(
                    color:Colors.white,
                   borderRadius: BorderRadius.all(Radius.circular(15))
                ),
                child: TextField(
                 onChanged: (value) =>_runFilter(value),
                  controller: Nonprofitcontroller,
                  decoration: InputDecoration(
                    prefixIcon:Icon(Icons.search_rounded),
                    border: InputBorder.none,
                    hintText: "Non profit",
                  ),
                ),
              ),
            ),
          ),
      ),
      body: Column(
        children: [
          SizedBox(height: 10,),
          Center(
            child: GestureDetector(
              // onTap: () {
              //   Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) {
              //     return phone_verifications();
              //   },));
              // },
              child: Container(
                height: 50,
                width: 320,
                margin: EdgeInsets.only(left: 10,right: 10),
                decoration: BoxDecoration(
                    border: Border(
                      bottom: BorderSide(
                          width: 0.5, color: Colors.black26),
                    )),
                child:Padding(
                  padding:  EdgeInsets.only(left: 3,top: 10),
                  child: Text("Suggestions",style: TextStyle(fontSize: 17,color: Color(0xfffa7914),),),
                ),
              ),
            ),
          ),
          SizedBox(height: 5,),
          Expanded(
            child:finduser.isNotEmpty ? ListView.builder(
              itemCount: finduser.length,
              itemBuilder: (context,index) {
                return Container(
                  height: 70,
                  margin: EdgeInsets.only(left: 10,right: 10),
                  decoration: BoxDecoration(
                      border: Border(
                        top: BorderSide(
                            width: 0.5, color: Colors.white10),
                        bottom: BorderSide(
                            width: 0.5, color: Colors.black26),
                      )),
                  alignment: Alignment.centerLeft,
                  child: Row(
                    mainAxisAlignment:
                    MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        height: MediaQuery.of(context).size.height * 0.8 / 8,
                        width: MediaQuery.of(context).size.height * 0.18,
                        alignment: Alignment.centerLeft,
                        child: Column(
                          crossAxisAlignment:
                          CrossAxisAlignment.start,
                          mainAxisAlignment:
                          MainAxisAlignment.center,
                          children: [
                            Text(
                               "${finduser[index].firstname}",
                              style: TextStyle(
                                  fontSize: 16,
                                  fontFamily: 'FontsFree',
                                  fontWeight: FontWeight.bold),
                            ),
                            SizedBox(
                              height: 1,
                            ),
                            Text(
                              "${finduser[index].lastname}",
                              style: TextStyle(
                                  fontSize: 13,
                                  color: Color(0xff7d7f86)),
                            ),
                            SizedBox(
                              height: 1,
                            ),
                            Text(
                              "${finduser[index].email}",
                              style: TextStyle(
                                  fontSize: 13,
                                  color: Color(0xff7d7f86)),
                            ),
                          ],
                        ),
                      ),
                      Padding(
                        padding:  EdgeInsets.only(left: 20),
                        child: Container(
                            height: MediaQuery.of(context).size.height * 0.4 / 5,
                            width: MediaQuery.of(context).size.width * 0.23,
                            alignment: Alignment.center,
                            child: Text(
                              "${finduser[index].phone}",
                              style: TextStyle(
                                  fontSize: 14,
                                  color: Color(0xff7d7f86)),
                            ),
                            ),
                      ),
                      Padding(
                        padding:  EdgeInsets.only(left:19),
                        child: IconButton(
                            onPressed: () {
                              Navigator.push(context,
                                  MaterialPageRoute(
                                      builder: (context) {
                                        return Signup_Screen(index);
                                      }));
                            },
                            icon: Icon(
                              Icons.edit,
                              size: 20,
                              color: Color(0xfffa7914),
                            )),
                      ),
                      IconButton(
                          onPressed: () {
                            showDialog(context: context, builder: (context) {
                              return AlertDialog(
                                title: Text("Delete list ?"),
                                actions: [
                                  ElevatedButton(onPressed: () {
                                    Navigator.pop(context);
                                  }, child: Text("ok")),
                                ],
                              );
                            },);
                            finduser.removeAt(index);
                           setState(() {});
                          },
                          icon: Icon(
                            Icons.delete,
                            size: 20,
                            color: Color(0xfffa7914),
                          )),
                    ],
                  ),
                );
            },)
             : Center(child: Text('No results found', style: TextStyle(fontSize: 24),)),
          ),
          Container(
            height:100,
            width: double.infinity,
            decoration: BoxDecoration(image: DecorationImage(image: AssetImage("images/Layer 7.png"),fit: BoxFit.fill)),
          ),
        ],
      ),
    );
  }
}




