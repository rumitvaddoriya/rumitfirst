package com.example.sqflite_geeve_account

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
