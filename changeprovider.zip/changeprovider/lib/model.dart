import 'package:flutter/cupertino.dart';

class model extends  ChangeNotifier{

    TextEditingController t1 = TextEditingController();
    TextEditingController t2 = TextEditingController();

    int sum=0;

   void total(String  a,String b)
    {
        sum=int.parse(a)+int.parse(b);
        notifyListeners();
    }
}