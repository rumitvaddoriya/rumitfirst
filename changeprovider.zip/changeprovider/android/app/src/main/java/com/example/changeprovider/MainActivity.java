package com.example.changeprovider;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
