import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:random_multiple_group/viewScreen/view_screen_controller.dart';


class ViewScreen extends StatelessWidget {
   ViewScreen({Key? key}) : super(key: key);

  final ViewScreenController viewScreenController = Get.put(ViewScreenController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("View"),
      ),
      body: ListView.builder(
        itemCount: viewScreenController.viewList.value.length,
        itemBuilder: (context, index) {
          List list = [];
          viewScreenController.viewList.value.forEach((element) {
            if(element.isCheck.value){
              list.add(element.name);
            }
          });
          list.shuffle();
          return viewScreenController.viewList.value[index].isCheck.value ? ListTile(
            title: Text(list.join(", ")),
          ) : const SizedBox();
      },)
    );
  }
}
