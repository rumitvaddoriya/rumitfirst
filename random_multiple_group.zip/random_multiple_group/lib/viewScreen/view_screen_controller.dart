import 'package:get/get.dart';
import 'package:random_multiple_group/model.dart';

class ViewScreenController extends GetxController{

  RxList<CheckBoxModel> viewList = RxList();
  String name = "ru & mit";

  @override
  void onInit() {
    // TODO: implement onInit
    viewList.value = Get.find(tag: "getSelectList");
    print(name.replaceAll(" & ", ""));
    super.onInit();
  }

}