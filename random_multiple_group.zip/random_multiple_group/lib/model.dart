import 'package:get/get.dart';

class CheckBoxModel{
  String name;
  RxBool isCheck;

  CheckBoxModel({required this.name, required this.isCheck});
}