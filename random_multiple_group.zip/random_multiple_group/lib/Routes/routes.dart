import 'package:get/get.dart';
import 'package:random_multiple_group/HomeScreen/home_screen.dart';
import 'package:random_multiple_group/viewScreen/view_screen.dart';

class AppRoutes{
  AppRoutes._();

  static const homeScreen = "/HomeScreen";
  static const viewScreen = "/viewScreen";

  static List<GetPage> routesList = [
    GetPage(name: homeScreen, page: () => HomeScreen(), transition: Transition.rightToLeft, transitionDuration: const Duration(milliseconds: 300)),
    GetPage(name: viewScreen, page: () => ViewScreen(), transition: Transition.rightToLeft, transitionDuration: const Duration(milliseconds: 300))
  ];
}