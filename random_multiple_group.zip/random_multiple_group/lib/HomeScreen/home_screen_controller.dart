import 'package:get/get.dart';
import 'package:random_multiple_group/Extension/extension.dart';
import 'package:random_multiple_group/Routes/routes.dart';
import 'package:random_multiple_group/model.dart';

class HomeScreenController extends GetxController{

  RxList<CheckBoxModel> showList = RxList();
  
  @override
  void onInit() {
    // TODO: implement onInit
    showList.value = [
      CheckBoxModel(name: "Urmil", isCheck: false.obs),
      CheckBoxModel(name: "Romit", isCheck: false.obs),
      CheckBoxModel(name: "Jenish", isCheck: false.obs),
      CheckBoxModel(name: "Jay", isCheck: false.obs),
      CheckBoxModel(name: "Ravi", isCheck: false.obs),
      CheckBoxModel(name: "Bhargav", isCheck: false.obs),
      CheckBoxModel(name: "Amit", isCheck: false.obs),
      CheckBoxModel(name: "Raj", isCheck: false.obs),
      CheckBoxModel(name: "Rahul", isCheck: false.obs),
      CheckBoxModel(name: "meet", isCheck: false.obs),
      CheckBoxModel(name: "jaydeep", isCheck: false.obs),
    ];
    super.onInit();
  }
  
  navigationToViewScreen(){
    Get.deleteAndPut(showList.value ,tag: "getSelectList");
    Get.toNamed(AppRoutes.viewScreen);
  }

}