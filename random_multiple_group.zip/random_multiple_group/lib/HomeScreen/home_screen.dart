import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:random_multiple_group/HomeScreen/home_screen_controller.dart';

class HomeScreen extends StatelessWidget {
   HomeScreen({Key? key}) : super(key: key);
  
  final HomeScreenController homeScreenController = Get.put(HomeScreenController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Home"),
      ),
      body: ListView.builder(
        itemCount: homeScreenController.showList.value.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(homeScreenController.showList.value[index].name),
            trailing: Obx(()=>Checkbox(
              value: homeScreenController.showList.value[index].isCheck.value,
              onChanged: (value) {
                if(homeScreenController.showList.value[index].isCheck.value){
                  homeScreenController.showList.value[index].isCheck.value = value!;
                } else{
                  homeScreenController.showList.value[index].isCheck.value = value!;
                }
              },),)
          );
      },),
      floatingActionButton: FloatingActionButton(onPressed: () {
        homeScreenController.navigationToViewScreen();
      },child: const Text("Result"),),
    );
  }
}
