package com.example.firebase_crud_geeve_account

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
