package com.example.geolocation

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
