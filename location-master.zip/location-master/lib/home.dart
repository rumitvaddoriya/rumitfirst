import 'package:flutter/material.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';

class GeoLocatorScreen extends StatefulWidget {
  const GeoLocatorScreen({Key? key}) : super(key: key);

  @override
  State<GeoLocatorScreen> createState() => _GeoLocatorScreenState();
}

class _GeoLocatorScreenState extends State<GeoLocatorScreen> {

  double? lon,lat;
  List pl = [];

  void getPosition() async {

    Position position = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);

    setState(() {
      lon = position.longitude;
      lat = position.latitude;

    });

    pl =await placemarkFromCoordinates(lat!, lon!);

  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(child: Scaffold(
      appBar: AppBar(
        title: Text("Geo Locator"),
      ),
      body: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(onPressed: ()async{
              if(await Permission.location.isDenied)
              {
                Permission.location.request();
              }
              else if(await Permission.location.isGranted)
              {
                setState(() {
                  getPosition();
                });
              }
            }, child: Text("Get Location")),
            Text("$pl"),
          ],
        ),
      ),
    ));
  }
}