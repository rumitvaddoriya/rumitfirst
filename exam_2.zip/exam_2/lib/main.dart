import 'package:exam_2/first.dart';
// import 'package:exam_2/third.dart';
import 'package:flutter/material.dart';

void main()
{
    runApp(MaterialApp(
      home: splash(),
    ));
}
