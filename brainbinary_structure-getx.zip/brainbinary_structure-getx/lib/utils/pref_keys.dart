class PrefKeys {
  static const latitude = 'latitude';
  static const longitude = 'longitude';
  static const locality = 'locality';
}
