import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:brainbinary_structure/common/text_styles.dart';
import 'package:brainbinary_structure/service/pref_service.dart';
import 'package:brainbinary_structure/utils/pref_keys.dart';
import 'package:intl/intl.dart';

class HomeTopArea extends StatelessWidget {
  const HomeTopArea({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(height: Get.height * 0.03),
        Text(PrefService.getString(PrefKeys.locality), style: title),
        SizedBox(height: Get.height * 0.02),
        Text(
          DateFormat('MMMM dd, yyyy').format(DateTime.now()),
          style: subHeader,
        ),
      ],
    );
  }
}
