import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:brainbinary_structure/screen/dashboard/dashboard_controller.dart';
import 'package:brainbinary_structure/screen/dashboard/widgets/bottom_bar.dart';
import 'package:brainbinary_structure/screen/forecast/forecast_screen.dart';
import 'package:brainbinary_structure/screen/history/history_screen.dart';
import 'package:brainbinary_structure/screen/home/home_screen.dart';
import 'package:brainbinary_structure/screen/map/map_screen.dart';
import 'package:brainbinary_structure/utils/color_res.dart';

class Dashboard extends StatelessWidget {
  const Dashboard({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final DashboardController controller = Get.put(DashboardController());
    return Scaffold(
      backgroundColor: ColorRes.bgColor2,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [
              ColorRes.bgColor1,
              ColorRes.bgColor2,
            ],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: GetBuilder<DashboardController>(
          id: 'bottom_bar',
          builder: (controller) {
            if (controller.currentTab == 0) {
              return const HomeScreen();
            } else if (controller.currentTab == 1) {
              return const ForecastScreen();
            } else if (controller.currentTab == 2) {
              return const HistoryScreen();
            } else {
              return const MapScreen();
            }
          },
        ),
      ),
      bottomNavigationBar: const BottomBar(),
    );
  }
}
