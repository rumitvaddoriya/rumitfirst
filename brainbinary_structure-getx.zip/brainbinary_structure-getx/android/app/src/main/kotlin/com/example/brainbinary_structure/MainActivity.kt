package com.example.brainbinary_structure

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
